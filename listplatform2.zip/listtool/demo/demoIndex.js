import React, { Component } from 'react';
import ReactDOM from 'react-dom';
// import { WrappedListPage } from '../dist/index';
import WrappedListPage from '../src/innerContext';

// eslint-disable-next-line new-cap
let ListToolPage = null;

class DemoListPage extends Component {
  componentWillMount() {
    const context = {
      reqUrl: 'http://dlist.xyz.cn/api/listtool/1001',
      // searchQuery: {
      //   order: {
      //     APPID: 1,
      //   },
      // },
    };
    // eslint-disable-next-line new-cap
    ListToolPage = WrappedListPage(context);
  }

  render() {
    return (
      <div>
        <ListToolPage/>
      </div>
    );
  }
}

// eslint-disable-next-line no-undef
const root = document.createElement('app');
root.id = 'Demo';
// eslint-disable-next-line no-undef
document.body.appendChild(root);


ReactDOM.render(<DemoListPage/>, root);
