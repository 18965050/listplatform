import React from 'react';
import _ from 'lodash';
import ListToolPage from './ListToolPage';
import { context } from '../innerContext';

export default (outerContext) => class ListToolPageHOC extends React.Component {
  render() {
    const { request, interceptor, props } = context;
    const propContext = _.merge({}, { request, interceptor, props }, { ...outerContext }, { ...this.props });
    return <ListToolPage {...propContext} />;
  }
};
