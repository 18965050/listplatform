// eslint-disable-next-line max-classes-per-file
import React, { Component } from 'react';
import { Col, Input, Row, Select } from 'antd';
import _ from 'lodash';
import { isJSON, mainAntdVer } from '../utils';

const gutter = mainAntdVer() > 2 ? { md: 2, lg: 4, xl: 8 } : 8;

const handleChange = (onChange, value, changedValue) => {
  if (onChange) {
    onChange({
      ...value,
      ...changedValue,
    });
  }
};

const getMatchEle = (onChange, value) => {
  const { match, matchValue } = value;
  const matchKeys = _.keys(match);
  let matchEle = null;
  if (!_.isEmpty(match) && matchKeys.length > 1) {
    matchEle = (<Select value={matchValue}
                        onChange={(changedValue) => handleChange(onChange, value, { matchValue: changedValue })}>
      {_.map(match, (mv, mk) => {
        return (
          <Select.Option key={mk} value={mk}>{mv}</Select.Option>);
      })}
    </Select>);
  }
  return matchEle;
};


export class InputSearchField extends Component {
  render() {
    const { value: searchField, onChange } = this.props;
    const { value, placeHolder } = searchField;
    const matchEle = getMatchEle(onChange, searchField);
    return (
      <Row gutter={gutter}>
        <Col span={_.isEmpty(matchEle) ? 24 : 16}>
          <Input value={value}
                 onChange={(e) => handleChange(onChange, searchField, { value: e.target.value })}
                 placeholder={placeHolder}/></Col>
        <Col span={_.isEmpty(matchEle) ? 0 : 8}>{matchEle}</Col>
      </Row>);
  }
}

export class SelectSearchField extends Component {
  render() {
    const { value: searchField, onChange } = this.props;
    const { value, placeHolder, mapping } = searchField;
    const matchEle = getMatchEle(onChange, searchField);

    const optionVals = (_.isEmpty(mapping) || !isJSON(mapping)) ? {} : JSON.parse(mapping);
    // 注意: _.map会将对象key转换为字符串类型
    const optionEles = _.map(optionVals, (v, k) => {
      return (<Select.Option key={k}>{v}</Select.Option>);
    });

    return (
      <Row gutter={gutter}>
        <Col span={_.isEmpty(matchEle) ? 24 : 16}>
          <Select value={value || undefined}
                  onChange={(changedValue) => handleChange(onChange, searchField, { value: changedValue })}
                  placeholder={placeHolder}>{optionEles}</Select></Col>
        <Col span={_.isEmpty(matchEle) ? 0 : 8}>{matchEle}</Col>
      </Row>);
  }
}
