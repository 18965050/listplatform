// eslint-disable-next-line max-classes-per-file
import React, { Component } from 'react';
import { Button, Card, Col, DatePicker, Form, Icon, Pagination, Row, Spin, Table } from 'antd';
import { DownOutlined, ExportOutlined, UpOutlined } from '@ant-design/icons';
import 'antd/dist/antd.less';
import moment from 'moment';
import _ from 'lodash';
import { InputSearchField, SelectSearchField } from './SearchField';
import { exportData, listFetch } from '../request';
import { context, functionContext, pageContext, searchContext, tableContext } from '../innerContext';
import {
  fieldMatchSuffix,
  mainAntdVer,
  parseFunctionFields,
  parseSearchFields,
  parseTableColumns,
  parseTableData,
  parseTableRowkey,
} from '../utils';


class ListToolPage extends Component {
  constructor(props) {
    super(props);
    this.state = { ...context.state };
  }

  componentWillMount() {
    const { request: { reqUrl, reqMethod, searchQuery, debug, debugUrl, listRecord }, interceptor: { beforeListFetch, afterListFetch } } = this.props;
    const realReqUrl = debug ? debugUrl : reqUrl;
    const realQuery = debug ? listRecord : searchQuery;
    if (!_.isEmpty(realReqUrl)) {
      this.setState({ loading: true });
      listFetch(realReqUrl, reqMethod, realQuery, beforeListFetch, afterListFetch, (state) => {
        this.setState(state);
      }, (errData) => (this.setState({ loading: false })));
    }
  }

  /**
   * 这个方法用于外部组件触发列表查询,
   * 注意: 不能在render中更新state(render是纯函数),在react早期版本中, 使用componentWillReceiveProps
   * @param prevProps
   * @param prevState
   * @param snapshot
   */
  componentDidUpdate(prevProps, prevState, snapshot) {
    const { searchQuery } = this.state;
    const { request: { debug, reqUrl, reqMethod, debugUrl }, interceptor: { beforeListFetch, afterListFetch } } = this.props;

    const { request: { refreshCounter: prevRefreshCounter, listRecord: prevListRecord } } = prevProps;
    const { request: { refreshCounter: thisRefreshCounter, listRecord: thisListRecord } } = this.props;

    if (thisRefreshCounter > prevRefreshCounter || !_.isEqual(prevListRecord, thisListRecord)) {
      const realReqUrl = debug ? debugUrl : reqUrl;
      const realQuery = debug ? thisListRecord : searchQuery;
      // eslint-disable-next-line react/no-did-update-set-state
      this.setState({ loading: true });
      listFetch(realReqUrl, reqMethod, realQuery, beforeListFetch, afterListFetch, (state) => {
        this.setState(state);
      }, (errData) => (this.setState({ loading: false })));
    }
  }

  changeState = (state) => {
    this.setState({ ...state });
  };

  render() {
    const { request, interceptor, props } = this.props;
    const { reqUrl, reqMethod, debug, debugUrl, listRecord } = request;
    const { customSearchFields, customFunctions, customTableColumns, tableRowkey, tableProps, pageProps } = props;
    const { title, loading, searchQuery } = this.state;
    const searchRegionProps = {
      ...searchContext,
      request: {
        searchQuery,
        reqUrl,
        reqMethod,
        debug,
        debugUrl,
        listRecord,
      },
      interceptor,
      props: {
        customSearchFields,
      },
      state: this.state,
      changeParentState: this.changeState,
    };
    const functionRegionProps = {
      ...functionContext,
      request: {
        searchQuery,
        reqUrl,
        reqMethod,
        debug,
        debugUrl,
        listRecord,
      },
      interceptor,
      props: {
        customFunctions,
      },
      state: this.state,
      changeParentState: this.changeState,
    };
    const tableRegionProps = {
      ...tableContext,
      request: {
        searchQuery,
        reqUrl,
        reqMethod,
        debug,
        debugUrl,
        listRecord,
      },
      interceptor,
      props: {
        customTableColumns,
        tableRowkey,
        tableProps,
      },
      state: this.state,
      changeParentState: this.changeState,
    };
    const pageRegionProps = {
      ...pageContext,
      request: {
        searchQuery,
        reqUrl,
        reqMethod,
        debug,
        debugUrl,
        listRecord,
      },
      interceptor,
      props: {
        pageProps,
      },
      state: this.state,
      changeParentState: this.changeState,

    };
    return (
      <Spin spinning={loading}>
        <Card bordered={false}>
          <div style={{ fontWeight: 'bold', fontSize: 'x-large', marginBottom: 30 }}>{title}</div>
          <div>
            <SearchRegion {...searchRegionProps} />
            <FunctionRegion {...functionRegionProps} />
            <TableRegion {...tableRegionProps} />
            <PageRegion {...pageRegionProps} />
          </div>
        </Card>
      </Spin>
    );
  }
}

class InnerSearchRegion extends Component {
  formRef = React.createRef();

  getInitialValue = (searchField) => {
    // 只有input,select且不为自定义渲染情况下才传对象,否则传值
    const isFormItemValObj = _.includes(['input', 'select'], searchField.eleType) && !searchField.eleRender;
    let initialValue = searchField.value || undefined;
    switch (searchField.eleType) {
      case 'datePicker':
      case 'timePicker': {
        if (!_.isEmpty(searchField.value)) {
          const fieldVals = searchField.value.split(':::');
          const momentVals = [_.isEmpty(fieldVals[0]) ? null : moment(Number.parseInt(fieldVals[0], 10)),
            _.isEmpty(fieldVals[1]) ? null : moment(Number.parseInt(fieldVals[1], 10))];
          initialValue = momentVals;
        }
        break;
      }
      default:
      // do nothing
    }
    return isFormItemValObj ? searchField : initialValue;
  }

  renderOneSearchField = (searchField, form, isDisplay) => {
    let ele;
    if (searchField.eleRender && _.isFunction(searchField.eleRender)) {
      ele = searchField.eleRender(searchField);
    } else {
      switch (searchField.eleType) {
        case 'input': {
          ele = <InputSearchField/>;
          break;
        }
        case 'select': {
          ele = <SelectSearchField/>;
          break;
        }
        case 'datePicker': {
          const { RangePicker } = DatePicker;
          ele = <RangePicker format="YYYY-MM-DD" placeholder={['开始日期', '结束日期']}/>;
          break;
        }
        case 'timePicker': {
          const { RangePicker } = DatePicker;
          ele = <RangePicker showTime format="YYYY-MM-DD HH:mm:ss" placeholder={['开始时间', '结束时间']}/>;
          break;
        }
        default:
          ele = null;
      }
    }

    const fieldDecorator = _.merge({},
      searchField.fieldDecorator ? searchField.fieldDecorator.options : {});

    if (mainAntdVer() < 4) {
      _.set(fieldDecorator, 'initialValue', this.getInitialValue(searchField));
    }

    // const fieldDecorator = _.merge({},
    //   { initialValue: this.getInitialValue(searchField) },
    //   searchField.fieldDecorator ? searchField.fieldDecorator.options : {});

    const gutter = mainAntdVer() > 2 ? { md: 2, lg: 6, xl: 24 } : 24;

    return (<Col span={8} key={searchField.id} style={{ display: isDisplay ? 'block' : 'none' }}>
      <Row gutter={gutter}>
        <Col span={24}>
          {mainAntdVer() < 4 ? (<Form.Item label={searchField.label}
                                           labelCol={{ span: 6 }}
                                           wrapperCol={{ span: 18 }}>
            {form.getFieldDecorator(searchField.id, {
              ...fieldDecorator,
            })(ele)}
          </Form.Item>) : (<Form.Item name={searchField.id} label={searchField.label}
                                      labelCol={{ span: 6 }}
                                      wrapperCol={{ span: 18 }}
                                      {...fieldDecorator}>
            {ele}
          </Form.Item>)}
        </Col>
      </Row>
    </Col>);
  };

  renderSearchFields = (searchFields, collapseCount) => {
    const { state: { searchExpand } } = this.props;
    const form = mainAntdVer() < 4 ? this.props.form : this.formRef.current;
    const expandShreshHold = searchExpand ? searchFields.length : collapseCount;
    const children = [];
    for (let i = 0; i < searchFields.length; i += 1) {
      children.push(this.renderOneSearchField(searchFields[i], form, i < expandShreshHold));
    }
    return children;
  };

  toggleCollapse = (searchExpand) => {
    const { changeParentState } = this.props;
    changeParentState({ searchExpand: !searchExpand });
  };

  searchResetHander = (searchFields) => {
    const { request: { searchQuery }, interceptor: { searchResetHandler }, changeParentState } = this.props;
    const form = mainAntdVer() < 4 ? this.props.form : this.formRef.current;
    changeParentState({ searchQuery: { ...searchQuery, param: {} } });
    if (_.isFunction(searchResetHandler)) {
      searchResetHandler();
    }
    // antd 4中form.resetFields()方法不清空字段数据, 仅仅是还原到字段的initialValue. 因此需要区别对待
    if (mainAntdVer() >= 4) {
      const fieldsValue = form.getFieldsValue();
      if (!_.isEmpty(fieldsValue)) {
        const newFieldsValue = {};
        _.forEach(fieldsValue, (v, k) => {
          if (typeof (v) === 'object' && _.has(v, 'id')) {
            _.set(v, 'value', undefined);
            const fields = _.filter(searchFields, (searchField) => searchField.id === k);
            if (_.isEmpty(fields)) {
              _.set(v, 'matchValue', undefined);
            } else {
              _.set(v, 'matchValue', _.keys(fields[0].match)[0]);
            }
            _.set(newFieldsValue, k, v);
          } else if (k.endsWith(fieldMatchSuffix)) {
            const fieldK = k.substring(0, k.lastIndexOf(fieldMatchSuffix));
            const fields = _.filter(searchFields, (searchField) => searchField.id === fieldK);
            if (_.isEmpty(fields)) {
              _.set(newFieldsValue, k, undefined);
            } else {
              _.set(newFieldsValue, k, _.keys(fields[0].match)[0]);
            }
          } else {
            _.set(newFieldsValue, k, undefined);
          }
        });
        form.setFieldsValue(newFieldsValue);
      }
    } else {
      form.resetFields();
    }
  };

  finishSearchHandler = (fieldsValue) => {
    const {
      request: { reqUrl, reqMethod, debug, debugUrl, listRecord, searchQuery },
      interceptor: { beforeListFetch, afterListFetch },
      state: { spec }, changeParentState,
    } = this.props;
    const form = mainAntdVer() < 4 ? this.props.form : this.formRef.current;
    const param = {};
    // (1)过滤出search字段
    const searchFields = _.filter(spec.fields, (field) => (field.search));
    // (2)获取搜索字段值
    _.forEach(searchFields, (field, index) => {
      let val = form.getFieldValue(field.key);
      // (3)objValue=>value
      if (typeof (val) === 'object' && _.has(val, 'id')) {
        if (val.value) {
          _.set(param, `${field.key}.value`, val.value);
          _.set(param, `${field.key}.match`, val.matchValue);
        }
      } else if (val) {
        // 判断是否为日期控件
        if (_.includes(['datePicker', 'timePicker'], field.search.eleType)) {
          val = `${val[0] ? val[0].valueOf() : ''}:::${val[1] ? val[1].valueOf() : ''}`;
        }
        _.set(param, `${field.key}.value`, val);
        // 字段match设置,仅当存在时设置
        const matchVal = form.getFieldValue(`${field.key}${fieldMatchSuffix}`);
        if (!_.isNil(matchVal)) {
          _.set(param, `${field.key}.match`, matchVal);
        }
      }
    });
    const params = _.mapValues(fieldsValue, (v) => {
      if (_.isString(v)) {
        return _.isEmpty(v) ? undefined : v;
      }
      return _.isNil(v) ? undefined : v;
    });


    const query = { ...searchQuery, param: { ...param } };
    const realReq = debug ? debugUrl : reqUrl;
    const realQuery = debug ? { ...listRecord, queryDTO: query } : query;
    changeParentState({ loading: true });
    listFetch(realReq, reqMethod, realQuery, beforeListFetch, afterListFetch, (state) => {
      changeParentState(state);
    }, (errData) => (changeParentState({ loading: false })));
  }

  submitSearchHandler = (e) => {
    e.preventDefault();
    const form = mainAntdVer() < 4 ? this.props.form : this.formRef.current;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      this.finishSearchHandler(fieldsValue);
    });
  };

  renderSearchForm = (searchFields) => {
    const { state: { searchExpand } } = this.props;
    const searchCount = searchFields.length;
    // 搜索字段折叠门槛
    const collapseCount = 6;

    const gutter = mainAntdVer() > 2 ? { md: 16, lg: 48, xl: 96 } : 96;

    // 注意: 这里不能用React.Fragment, 这个功能在React 16.2中才引入
    const formChildren = (<div>
      <Row gutter={gutter} type="flex" justify="start">{this.renderSearchFields(searchFields, collapseCount)}</Row>
      <Row gutter={gutter} style={{ textAlign: 'right', marginBottom: '24px' }}>
        <Col span={24}>
          <Button type="primary" htmlType="submit">
            查询
          </Button>
          <Button style={{ marginLeft: 8 }} onClick={() => this.searchResetHander(searchFields)}>
            清除
          </Button>
          {searchCount > collapseCount
            ? <a style={{ marginLeft: 8, fontSize: 12 }}
                 onClick={() => (this.toggleCollapse(searchExpand))}>
              {searchExpand ? '收起' : '展开'} {mainAntdVer() < 4 ? (
              <Icon type={searchExpand ? 'up' : 'down'}/>) : (searchExpand ? <UpOutlined/> : <DownOutlined/>)}
            </a> : null}
        </Col>
      </Row>
    </div>);

    const initialValues = {};
    if (mainAntdVer() >= 4) {
      _.forEach(searchFields, (searchField) => {
        initialValues[searchField.id] = this.getInitialValue(searchField);
      });
    }
    if (mainAntdVer() < 4) {
      return (<Form onSubmit={this.submitSearchHandler}>
        {formChildren}
      </Form>);
    }
    if (!_.isEmpty(initialValues)) {
      return (<Form ref={this.formRef}
                    initialValues={initialValues}
                    onFinish={this.finishSearchHandler}>
        {formChildren}
      </Form>);
    }
    return null;
  };

  render() {
    const { request: { searchQuery }, props: { customSearchFields }, state: { spec } } = this.props;
    const specFields = (_.isEmpty(spec) || _.isEmpty(spec.fields)) ? [] : spec.fields;
    const searchFields = parseSearchFields(specFields, searchQuery, customSearchFields);
    return this.renderSearchForm(searchFields);
  }
}

const SearchRegion = mainAntdVer() < 4 ? Form.create()(InnerSearchRegion) : InnerSearchRegion;

class FunctionRegion extends Component {
  exportHandler = () => {
    const {
      request: { reqUrl, reqMethod, debug, debugUrl, listRecord, searchQuery },
      state: { title },
      changeParentState,
    } = this.props;
    const query = { ...searchQuery, oper: { ...searchQuery.oper, export: 1 } };
    const realReq = debug ? debugUrl : reqUrl;
    const realQuery = debug ? { ...listRecord, queryDTO: query } : query;
    changeParentState({ loading: true });
    exportData(realReq, reqMethod, realQuery, `${title}.xlsx`, () => (changeParentState({ loading: false })));
  };

  renderFunctionFields = (functionFields) => {
    const { state: { loading } } = this.props;
    let ele;
    const eles = [];
    // 暂时放置loading, 后续可能放其他context数据
    const renderContext = { loading };
    _.forEach(functionFields, (functionField) => {
      switch (functionField.comType) {
        case 'export': {
          ele = <Button key={functionField.key}
                        type="primary"
                        icon={mainAntdVer() < 4 ? 'export' : <ExportOutlined/>}
                        style={{ marginRight: 10 }}
                        onClick={this.exportHandler}
                        disabled={loading}>导出</Button>;
          break;
        }
        case 'custom': {
          if (functionField.eleRender && _.isFunction(functionField.eleRender)) {
            ele = functionField.eleRender(renderContext);
          } else {
            ele = <Button key={functionField.key}
                          type="primary"
                          style={{ marginRight: 10 }}
                          disabled={loading}>#{functionField.key}#</Button>;
          }
          break;
        }
        default:
          ele = null;
      }
      eles.push(ele);
    });
    return eles;
  };

  render() {
    const { state: { spec }, props: { customFunctions } } = this.props;
    const specFunctions = (_.isEmpty(spec) || _.isEmpty(spec.functions)) ? [] : spec.functions;
    const functionFields = parseFunctionFields(specFunctions, customFunctions);
    return _.isEmpty(functionFields) ? null : (
      <div style={{ margin: 10 }}>{this.renderFunctionFields(functionFields)}</div>);
  }
}

class TableRegion extends Component {
  tableChangeHandler = (pagination, filters, sorter) => {
    const {
      request: { reqUrl, reqMethod, debug, debugUrl, listRecord, searchQuery },
      interceptor: { beforeListFetch, afterListFetch },
      changeParentState,
    } = this.props;
    const order = {};
    if (sorter.order === 'ascend') {
      order[sorter.field] = 0;
    } else if (sorter.order === 'descend') {
      order[sorter.field] = 1;
    }
    const query = { ...searchQuery, order: { ...order } };
    const realReq = debug ? debugUrl : reqUrl;
    const realQuery = debug ? { ...listRecord, queryDTO: query } : query;
    changeParentState({ loading: true });
    listFetch(realReq, reqMethod, realQuery, beforeListFetch, afterListFetch, (state) => {
      changeParentState(state);
    }, (errData) => (changeParentState({ loading: false })));
  };

  render() {
    const {
      request: { debug, searchQuery },
      props: { customTableColumns, tableRowkey, tableProps },
      state: { spec, dataList },
    } = this.props;
    const specFields = (_.isEmpty(spec) || _.isEmpty(spec.fields)) ? [] : spec.fields;
    const tableColumns = parseTableColumns(specFields, searchQuery, customTableColumns);
    const rowKey = parseTableRowkey(tableRowkey, tableColumns);
    const tableData = parseTableData(dataList);
    return (<Table
      rowKey={rowKey}
      dataSource={tableData}
      columns={tableColumns}
      pagination={false}
      onChange={this.tableChangeHandler}
      {...tableProps}
    />);
  }
}

class PageRegion extends Component {
  pageChangeHandler = (page, pageSize) => {
    const {
      request: { reqUrl, reqMethod, debug, debugUrl, listRecord, searchQuery },
      interceptor: { beforeListFetch, afterListFetch },
      changeParentState,
    } = this.props;
    const query = { ...searchQuery, pagenator: { pageIndex: page, pageSize } };
    const realReq = debug ? debugUrl : reqUrl;
    const realQuery = debug ? { ...listRecord, queryDTO: query } : query;
    changeParentState({ loading: true });
    listFetch(realReq, reqMethod, realQuery, beforeListFetch, afterListFetch, (state) => {
      changeParentState(state);
    }, (errData) => (changeParentState({ loading: false })));
  };

  render() {
    const { props: { pageProps }, state: { pagenator } } = this.props;
    return _.isUndefined(pagenator) ? null : (<Pagination
      className="ant-table-pagination"
      showSizeChanger
      pageSize={pagenator.pageSize || 10}
      pageSizeOptions={[`${pagenator.pageSize}`]}
      total={pagenator.totalCount || 0}
      current={pagenator.pageIndex}
      onShowSizeChange={this.pageChangeHandler}
      onChange={this.pageChangeHandler}
      {...pageProps}
    />);
  }
}

export default ListToolPage;
export { SearchRegion, FunctionRegion, TableRegion, PageRegion };
