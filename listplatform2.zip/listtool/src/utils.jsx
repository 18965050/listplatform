import _ from 'lodash';
import { notification, version as antdVer } from 'antd';

const fieldMatchSuffix = '_$match$';

/**
 * 解析Table Column
 * @param specField
 * @param searchQuery
 * @returns {Array}
 */
const parseTableColumns = (specFields, searchQuery, customColumns) => {
  let columns = [];
  if (!_.isEmpty(specFields)) {
    // (1)过滤掉不展示的字段
    const showFields = _.filter(specFields, (field) => (field.result));
    // (2)解析出column数据
    _.forEach(showFields, (field) => {
      let sortDirections = '';
      if (field.result.order) {
        sortDirections = ['ascend', 'descend'];
      }
      let sortOrder = false;
      if (!_.isEmpty(searchQuery) && !_.isEmpty(searchQuery.order) && _.has(searchQuery.order, field.key)) {
        sortOrder = _.get(searchQuery.order, field.key) === 0 ? 'ascend' : 'descend';
      }
      const column = {
        title: field.label,
        dataIndex: field.key,
        align: 'center',
        sorter: !!field.result.order,
        sortDirections,
        sortOrder,
        index: field.result.index ? field.result.index : 0,
        render: (text, record, index) => {
          return _.isEmpty(text) || _.isEmpty(text.labelValue) ? '' : text.labelValue;
        },
      };
      columns.push(column);
    });
    // (3)排序
    columns = _.sortBy(columns, (column) => (column.index));
  }
  // (4)添加或覆盖customColumns
  if (!_.isEmpty(customColumns)) {
    _.forEach(customColumns, (cusCol, index) => {
      const filteredCols = _.filter(columns, (oriColumn) => {
        return _.includes([cusCol.dataIndex, cusCol.key], oriColumn.dataIndex);
      });
      if (_.isEmpty(filteredCols)) {
        columns.push(cusCol);
      } else {
        _.forEach(filteredCols, (filterCol) => {
          _.merge(filterCol, cusCol);
        });
      }
    });
  }
  return columns;
};

/**
 * 解析出table的rowKey.
 * @param columns : 函数parseTableColumns()的输出
 * @returns {string}
 */
const parseTableRowkey = (tableRowkey, columns) => {
  if (_.isFunction(tableRowkey)) {
    return tableRowkey;
  }
  if (!_.isEmpty(columns)) {
    const filterColumns = _.filter(columns, (column) => (column.dataIndex === tableRowkey));
    if (!_.isEmpty(filterColumns)) {
      return (record) => _.get(record, `${tableRowkey}.value`);
    }
    return '';
  }
  return '';
};

const mainAntdVer = () => (Number.parseInt(antdVer.split('.')[0], 10));

/**
 * 解析出table的dataSource
 * @param dataSource
 * @returns {Array}
 */
const parseTableData = (dataSource) => {
  return !dataSource ? [] : dataSource;
};

/**
 * 解析出search域数据
 * @param specFields
 * @param searchQuery
 * @returns {Array}
 */
const parseSearchFields = (specFields, searchQuery, customSearchFields) => {
  let searchs = [];
  if (!_.isEmpty(specFields)) {
    // (1) 过滤出搜索字段
    const searchFields = _.filter(specFields, (field) => (field.search));
    // (2) 解析search字段
    _.forEach(searchFields, (field) => {
      let value = '';
      let fieldItem = {};
      const { match } = field.search;
      let matchValue = _.isEmpty(match) ? '' : `${_.keys(match)[0]}`;
      if (!_.isEmpty(_.get(searchQuery, `param.${field.key}`))) {
        value = _.get(searchQuery.param, `${field.key}.value`);
        matchValue = `${_.get(searchQuery.param, `${field.key}.match`)}`;
      }
      // (3)解析出fieldDecorator
      if (!_.isEmpty(customSearchFields)) {
        const item = _.find(customSearchFields,
          (customSearchField) => (customSearchField.id && customSearchField.id === field.key));
        if (!_.isUndefined(item)) {
          fieldItem = _.omit(item, 'id') || {};
        }
      }
      const search = {
        id: field.key,
        value,
        matchValue,
        ...fieldItem,
        label: field.label,
        placeHolder: field.remark,
        match,
        eleType: field.search.eleType || 'input',
        dataType: field.search.dataType,
        mapping: field.mapping,
        index: field.search.index,
      };
      searchs.push(search);
    });
    // (4) 排序
    searchs = _.sortBy(searchs, (search) => (search.index));
  }
  return searchs;
};

/**
 * 解析出function域数据
 * @param specFunctions
 * @returns {Array}
 */
const parseFunctionFields = (specFunctions, customFunctions) => {
  let functions = [];
  // (1)放入specFunctions
  if (!_.isEmpty(specFunctions)) {
    _.assign(functions, specFunctions);
  }
  // (2)添加或覆盖customFunctions
  if (!_.isEmpty(customFunctions)) {
    _.forEach(customFunctions, (cusFunction) => {
      const filterComTypeFuncs = _.filter(specFunctions, (oriFunction) => {
        return cusFunction.key === oriFunction.key;
      });
      if (_.isEmpty(filterComTypeFuncs)) {
        functions.push(cusFunction);
      } else {
        _.forEach(filterComTypeFuncs, (filterKeyFunc) => {
          _.merge(filterKeyFunc, cusFunction);
        });
      }
    });
  }
  // (3)排序
  if (!_.isEmpty(functions)) {
    functions = _.sortBy(functions, (func) => (func.index));
  }
  return functions;
};

const notify = ({ message, description, placement = 'bottomRight', icon = undefined, duration = 2 }, level = 'info') => {
  let notifier = null;
  switch (level) {
    case 'success':
      notifier = notification.success;
      break;
    case 'info':
      notifier = notification.info;
      break;
    case 'warning':
      notifier = notification.warning;
      break;
    case 'error':
      notifier = notification.error;
      break;
    default:
      notifier = notification.info;
  }
  notifier({
    message,
    description,
    placement,
    icon,
    duration,
  });
}

const randomStr = (length) => {
  const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  let str = '';
  for (let i = 0; i < length; i += 1) {
    const rand = Math.floor(Math.random() * ALPHABET.length);
    str += ALPHABET.substring(rand, rand + 1);
  }
  return str;
};

const isJSON = (str) => {
  try {
    if (_.isObjectLike(JSON.parse(str))) {
      return true;
    }
  } catch (e) {
    return false;
  }
  return false;
};

export {
  mainAntdVer,
  parseTableColumns,
  parseTableRowkey,
  parseTableData,
  parseSearchFields,
  parseFunctionFields,
  randomStr,
  isJSON,
  fieldMatchSuffix,
  notify,
};
