import _ from 'lodash';
import { Icon } from 'antd';
import { CloseCircleOutlined } from '@ant-design/icons';
import React from 'react';
import { mainAntdVer, notify } from './utils';

const initReq = (reqMethod, data) => {
  return {
    headers: {
      'Content-Type': 'application/json;charset=UTF-8',
      'X-Requested-With': 'XMLHttpRequest',
    },
    cache: 'no-cache',
    mode: 'cors',
    credentials: 'include',
    method: reqMethod || 'POST',
    body: reqMethod === 'POST' ? (_.isEmpty(data) ? '{}' : JSON.stringify(data)) : undefined,
  };
};

const getCloseIcon = () => {
  const antdVer = mainAntdVer();
  switch (antdVer) {
    case 2:
      return <Icon type="close-circle"/>;
    case 3:
      return <Icon type="close-circle" theme="twoTone"/>;
    case 4:
      return <CloseCircleOutlined/>;
    default:
      return <Icon type="close-circle"/>;
  }
}

const getRealReqUrl = (reqUrl, reqMethod, data) => {
  const getReqUrl = reqUrl.indexOf('?') > 0
    ? `${reqUrl}&queryDTO=${JSON.stringify(data)}`
    : `${reqUrl}?queryDTO=${JSON.stringify(data)}`;
  return reqMethod === 'POST' ? reqUrl : encodeURI(`${getReqUrl}`);
}

export const listFetch = (reqUrl, reqMethod, data, beforeListFetch, afterListFetch, sucCallback, failCallback) => {
  let reqData = data;
  console.log('origin reqData:', reqData);
  if (_.isFunction(beforeListFetch)) {
    reqData = _.cloneDeep(reqData);
    beforeListFetch(reqData);
    console.log('beforeListFetch reqData:', reqData);
  }
  const realReqUrl = getRealReqUrl(reqUrl, reqMethod, data);
  // eslint-disable-next-line no-undef
  fetch(realReqUrl, initReq(reqMethod, reqData)).then((response) => response.json()).then((responseData) => {
    const { ret: retCode, msg: errMsg } = responseData;
    if (retCode && typeof retCode === 'number' && retCode !== 0) {
      const error = new Error('API请求错误');
      error.data = {
        message: `API请求错误(${retCode},${errMsg}):`,
        description: `${reqUrl}`,
        icon: getCloseIcon(),
      };
      throw error;
    }
    let resData = responseData.data;
    console.log('origin resData:', resData);
    if (_.isFunction(afterListFetch)) {
      // 由于console.log控制台打印, 当展开对象时会引用最新的对象, 因此这里clone一下
      resData = _.cloneDeep(resData);
      afterListFetch(resData);
      console.log('afterListFetch resData:', resData);
    }
    return resData;
  }).then((resData) => {
    if (sucCallback && typeof sucCallback === 'function') {
      sucCallback({
        title: resData.title,
        pagenator: resData.pagenator,
        searchQuery: resData.query,
        spec: resData.spec,
        dataList: resData.list,
        loading: false,
      });
    }
  }).catch((error) => {
    notify(error.data, 'error');
    failCallback(error.data);
  });
};

const exportDownload = (reqUrl, reqMethod, data, fileName) => {
  const realReqUrl = getRealReqUrl(reqUrl, reqMethod, data);
  // eslint-disable-next-line no-undef
  fetch(realReqUrl, initReq(reqMethod, data)).then((response) => response.blob()).then((body) => {
    // eslint-disable-next-line no-undef
    if (body instanceof Blob) {
      // eslint-disable-next-line no-undef
      const reader = new FileReader();
      reader.readAsText(body, 'utf-8');
      reader.onload = function (e) {
        try {
          const responseData = JSON.parse(reader.result);
          const { ret: retCode, msg: errMsg } = responseData;
          if (retCode && typeof retCode === 'number' && retCode !== 0) {
            notify({
              message: `文件下载失败(${retCode},${errMsg}):`,
              description: `${reqUrl}`,
              icon: getCloseIcon(),
            }, 'error');
          }
        } catch (ex) {
          // eslint-disable-next-line no-undef
          if (window.navigator.msSaveOrOpenBlob) {
            // eslint-disable-next-line no-undef
            navigator.msSaveBlob(body, fileName);
          } else {
            // eslint-disable-next-line no-undef
            const link = document.createElement('a');
            // eslint-disable-next-line no-undef
            const evt = document.createEvent('MouseEvents');
            link.style.display = 'none';
            // eslint-disable-next-line no-undef
            link.href = window.URL.createObjectURL(body);
            link.download = fileName;
            // eslint-disable-next-line no-undef
            document.body.appendChild(link); // 此写法兼容可火狐浏览器
            evt.initEvent('click', false, false);
            link.dispatchEvent(evt);
            // eslint-disable-next-line no-undef
            document.body.removeChild(link);
          }
        }
      };
    }
  });
};

export const exportData = (reqUrl, reqMethod, data, fileName, callback) => {
  const realReqUrl = getRealReqUrl(reqUrl, reqMethod, data);
  // eslint-disable-next-line no-undef
  fetch(realReqUrl, initReq(reqMethod, data)).then((response) => response.json()).then((responseData) => {
    const { ret: retCode, msg: errMsg } = responseData;
    if (retCode && typeof retCode === 'number' && retCode !== 0) {
      notify({
        message: `数据导出错误(${retCode},${_.join(errMsg, ',')}):`,
        description: `${reqUrl}`,
        icon: getCloseIcon(),
      }, 'error');
      return;
    }
    const { data: resData } = responseData;
    if (_.isEmpty(resData)) {
      // 导出进行中
      setTimeout(() => (exportData(reqUrl, reqMethod, data, fileName, null)), 3000);
    } else {
      const { exportToken, downloadUrl } = resData;
      if (!_.isEmpty(exportToken)) {
        notify({ message: '数据导出', description: '数据正在后台导出,请稍候...' });
        const reqUrlWithToken = `${reqUrl}?exportToken=${exportToken}`;
        setTimeout(() => (exportData(reqUrlWithToken, reqMethod, data, fileName, null)), 3000);
      } else if (!_.isEmpty(downloadUrl)) {
        exportDownload(downloadUrl, reqMethod, null, fileName);
      }
    }
  }).then(() => {
    if (callback && typeof callback === 'function') {
      callback();
    }
  });
};
