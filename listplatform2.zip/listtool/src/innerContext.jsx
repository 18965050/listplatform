const debugInfo = {
  /*  是否调试  */
  debug: false,
  /*  调试url */
  debugUrl: undefined,
  /* 列表配置对象 */
  listRecord: undefined,
};

const interceptor = {
  /* 列表请求前的处理函数 */
  beforeListFetch: undefined,
  /* 列表请求后渲染前的处理函数 */
  afterListFetch: undefined,
  /* 检索清除处理函数 */
  searchResetHandler: undefined,
};

const context = {
  request: {
    /*  列表请求url */
    reqUrl: undefined,

    reqMethod: 'POST',
    /*  请求参数对象  */
    searchQuery: {
      /*  请求参数  */
      param: undefined,
      /*  排序参数  */
      order: undefined,
      /*  ql模板参数  */
      placeHolder: undefined,
      /*  分页参数  */
      pagenator: {
        pageIndex: 1,
      },
      /*  操作参数(是否执行, 导出)  */
      oper: {
        exec: 1,
      },
    },
    /* 增加refreshCounter用于触发列表组件刷新 */
    refreshCounter: 0,
    ...debugInfo,
  },

  interceptor,

  props: {
    /*  分页属性, 请参考 https://ant.design/components/pagination-cn/#API  */
    pageProps: {},
    /* 表格行的key,一般定义为主键列, 避免出现警告 */
    tableRowkey: undefined,
    /* 表格属性, 请参考 https://ant.design/components/table/#Table */
    tableProps: {},
    /*  自定义表格column,会根据dataIndex或key覆盖对应列表字段配置. 格式:
    * customTableColumns[{
    *   请参考 https://ant.design/components/table/#Column
    * },] */
    customTableColumns: [],
    /* 功能区组件,会根据key覆盖对应功能字段配置 格式:
    * customFunctions:[{
    *   key: '',                      -- 组件标识
    *   comType: 'export|custom',     -- export为数据导出, 已经实现;custom为自定义组件
    *   eleRender(renderContext),     -- 用于绘制自定义组件
    *   props: {                      -- 用于非自定义组件
    *     label: '',                  -- 组件标签
    *     eleType: '',                -- 组件类型.'button'
    *   },
    * },] */
    customFunctions: [],
    /* 检索字段. 格式:
    * customSearchFields: [{
    *   id:''                             -- 字段标识,
    *   eleType: '',                      -- 用于非自定义组件.'input','select','datePicker'等
    *   eleRender(searchField),           -- 用于自定义组件,按照antd规范, 必须提供受控属性value和onChange事件,
    *   fieldDecorator: {}                -- 用于initialValue,字段校验等
    * },] */
    customSearchFields: [],
  },

  state: {
    /* 是否远程请求数据 */
    loading: false,
    /* 搜索域字段过多是是否折叠 */
    searchExpand: false,
    /* 列表标题 */
    title: '',
    /* 分页信息 */
    pagenator: {},
    /* 列表检索信息 */
    searchQuery: {},
    /* 列表规范信息 */
    spec: {},
    /* 列表数据 */
    dataList: [],
  },
};

/* ************************** 以下部分为子组件单独使用时需要传入的context ************************** */
const searchContext = {
  request: {
    searchQuery: context.state.searchQuery,
    reqUrl: context.request.reqUrl,
    // 非维护人员不要修改
    ...debugInfo,
  },
  interceptor,
  props: {
    customSearchFields: context.props.customSearchFields,
  },
  state: context.state,
  changeParentState: undefined,
};

const functionContext = {
  request: {
    searchQuery: context.state.searchQuery,
    reqUrl: context.request.reqUrl,
    // 非维护人员不要修改
    ...debugInfo,
  },
  interceptor,
  props: {
    customFunctions: context.props.customFunctions,
  },
  state: context.state,
  changeParentState: undefined,
};

const tableContext = {
  request: {
    searchQuery: context.state.searchQuery,
    reqUrl: context.request.reqUrl,
    // 非维护人员不要修改
    ...debugInfo,
  },
  interceptor,
  props: {
    tableRowkey: context.props.tableRowkey,
    customTableColumns: context.props.customTableColumns,
    tableProps: context.props.tableProps,
  },
  state: context.state,
  changeParentState: undefined,
};

const pageContext = {
  request: {
    searchQuery: context.state.searchQuery,
    reqUrl: context.request.reqUrl,
    // 非维护人员不要修改
    ...debugInfo,
  },
  interceptor,
  props: {
    pageProps: context.props.pageProps,
  },
  state: context.state,
  changeParentState: undefined,

};

export { context, searchContext, functionContext, tableContext, pageContext };
