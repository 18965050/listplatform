// eslint-disable-next-line no-undef
System.config({
  paths: {
    '@/*': './src/*',
  },
});
