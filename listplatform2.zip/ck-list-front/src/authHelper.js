/*
 * 认证配置集成
 */
import initAuth from '@xyz/auth';

/**
 * 认证参数
 * @type {{}}
 */
const authOptions = { // client config
  userInfoWebSocket: 'ws://auth.xyz.cn/api/auth/user',
  ssoServer: false,
  logoutUrl: '/api/__ajaxLogout',
  getUserInfoUrl: '/api/__ajaxGetUserInfo', // client
};

/**
 * 通过插件提供的 initAuth 方法生成各种认证相关配置
 */
export default initAuth(authOptions);
