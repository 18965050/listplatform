import React from 'react';
import DemoListPage from './DemoListPage';

export default () => (
  <div>
    <DemoListPage/>
  </div>
);
