import React, { Component } from 'react';
import _ from 'lodash';
import withRouter from 'umi/withRouter';
import { connect } from 'dva';
import { context, functionContext, pageContext, searchContext, tableContext } from '@xyz/listtool/src/innerContext';
import { listFetch } from '@xyz/listtool/src/request';
// import {FunctionRegion,SearchRegion,TableRegion,PageRegion} from '@xyz/listtool';
import { FunctionRegion, PageRegion, SearchRegion, TableRegion } from '@xyz/listtool/src/components/ListToolPage';
import { Button, Card, DatePicker, Divider, Input, Spin, Tabs } from 'antd';

const { RangePicker } = DatePicker;
const { TabPane } = Tabs;

const reqUrl = '/api/listtool/demo';
const reqMethod = 'GET';
const reqSearchQuery = {
  ...context.request.searchQuery,
  // param: {
  //   INSURE_NAME: {
  //     value: 'test01',
  //     match: 0,
  //   },
  // },
  placeHolder: {
    PARAMS: 'and POLICY_STATUS=1',
  },
};

const mapStateToProps = ({ policy, loading }) => ({
  ...policy,
  loading: loading.models.policy,
});

@withRouter
@connect(mapStateToProps)
class PolicyListPage1 extends Component {
  constructor(props) {
    super(props);
    this.state = { ...context.state };
  }

  changeState = (state) => {
    this.setState({ ...state });
  };

  customSearchFields = [
    {
      id: 'POLICY_NO',
      eleRender: (searchField) => {
        return <Input placeholder={`这是个自定义组件,${searchField.placeHolder}`}/>;
      },
      fieldDecorator: {
        options: {
          rules: [{ pattern: /^\S{1,50}$/, message: '只能输入1~50位非空字符' }],
        },
      },
    },
    {
      id: 'START_TIME',
      eleRender: (text, record, index) => {
        return (<RangePicker showTime placeholder="自定义组件,请输入保险起期"/>);
      },
    },
    {
      id: 'END_TIME',
      eleRender: (text, record, index) => {
        return (<RangePicker showTime placeholder="自定义组件,请输入保险止期"/>);
      },
    },
  ];

  interceptor = {
    beforeListFetch: (reqData) => {
      // if (_.isEmpty(_.get(reqData, 'param.INSURE_NAME.value'))) {
      //   _.set(reqData, 'oper.exec', 0);
      // } else {
      //   _.set(reqData, 'oper.exec', 1);
      // }
      const startTime = _.get(reqData, 'param.START_TIME.value');
      if (_.isArray(startTime)) {
        const newStartTime = [];
        _.forEach(startTime, (st) => {
          newStartTime.push(st.format('YYYY-MM-DD HH:mm:ss'));
        });
        _.set(reqData, 'param.START_TIME.value', newStartTime.join(':::'));
      }
      const endTime = _.get(reqData, 'param.END_TIME.value');
      if (_.isArray(endTime)) {
        const newEndTime = [];
        _.forEach(endTime, (et) => {
          newEndTime.push(et.format('YYYY-MM-DD HH:mm:ss'));
        });
        _.set(reqData, 'param.END_TIME.value', newEndTime.join(':::'));
      }
    },

    afterListFetch: (resData) => {
      const { activeKey } = this.props;
      const specFields = _.get(resData, 'spec.fields');
      switch (activeKey) {
        case '1': {
          const filteredFields = _.filter(specFields,
            (specField) => (_.includes(['APP_ID', 'APP_NAME', 'LOGIN_NAME'], specField.key)));
          _.forEach(filteredFields, field => (_.unset(field, 'result')));
          break;
        }
        case '2': {
          const filteredFields = _.filter(specFields,
            (specField) => (_.includes(['ENDORSE_TIMES', 'PROD_NAME', 'INS_COM_ID'], specField.key)));
          _.forEach(filteredFields, field => (_.unset(field, 'result')));
          break;
        }
        case '3': {
          const filteredFields = _.filter(specFields,
            (specField) => (_.includes(['POLICY_STATUS', 'ACCEPT_TIME', 'CARD_TYPE'], specField.key)));
          _.forEach(filteredFields, field => (_.unset(field, 'result')));
          break;
        }
        case '4': {
          const filteredFields = _.filter(specFields,
            (specField) => (_.includes(['PROD_KIND', 'FLAG', 'INSURE_NAME'], specField.key)));
          _.forEach(filteredFields, field => (_.unset(field, 'result')));
          break;
        }
        default:
      }
    },
  };

  searchRegionProps = {
    ...searchContext,
    ...{ request: { reqUrl, reqMethod } },
    ...{ props: { customSearchFields: this.customSearchFields } },
    changeParentState: this.changeState,
    interceptor: this.interceptor,
  };

  customFunctions = [
    {
      key: 'add',
      comType: 'custom',
      eleRender: () => {
        const { loading } = this.props;
        return (<Button key="add"
                        icon="plus"
                        type="primary"
                        style={{ marginRight: 10 }}
                        disabled={loading}
                        onClick={() => alert('新建')}>
          新建
        </Button>);
      },
    },
  ];

  functionRegionProps = {
    ...functionContext,
    ...{ request: { reqUrl, reqMethod } },
    ...{ props: { customFunctions: this.customFunctions } },
    changeParentState: this.changeState,
    interceptor: this.interceptor,
  };

  tableRowkey = 'POLICY_NO';

  customTableColumns = [
    {
      title: '操作',
      align: 'center',
      width: 50,
      dataIndex: '__OPER__',
      render: (text, record, index) => {
        return (<span>
        <a onClick={() => alert(`状态(${record.POLICY_STATUS.value})`)}>状态</a>
        <Divider type="vertical"/>
        <a onClick={() => alert(`保单(${record.POLICY_NO.value})的详情`)}>详情</a></span>);
      },
    },
    {
      dataIndex: 'POLICY_NO',
      render: (text, record, index) => {
        return <a onClick={() => alert(`保单号(${record.POLICY_NO.value})`)}>{record.POLICY_NO.value}</a>;
      },
    },
    {
      dataIndex: 'PROD_KEYWORD',
      width: 100,
    },
    {
      dataIndex: 'INS_COM_ID',
      width: 200,
    },
    {
      dataIndex: 'POLICY_NO',
      width: 100,
    },
    {
      dataIndex: 'APP_ID',
      width: 100,
    },
    {
      dataIndex: 'APP_CARD_NO',
      width: 100,
    },
    {
      dataIndex: 'LOGIN_NAME',
      width: 50,
    },
    {
      dataIndex: 'PROD_NAME',
      width: 50,
    },
  ];

  tableRegionProps = {
    ...tableContext,
    ...{ request: { reqUrl, reqMethod } },
    ...{
      props: {
        tableRowkey: this.tableRowkey,
        customTableColumns: this.customTableColumns
      }
    },
    changeParentState: this.changeState,
    interceptor: this.interceptor,
  };

  pageProps = {
    pageSizeOptions: ['10', '20', '30'],
  };

  pageRegionProps = {
    ...pageContext,
    ...{ request: { reqUrl, reqMethod } },
    ...{ props: { pageProps: this.pageProps } },
    changeParentState: this.changeState,
    interceptor: this.interceptor,
  };

  componentWillMount() {
    const { dispatch } = this.props;
    const { beforeListFetch, afterListFetch } = this.interceptor;
    dispatch({
      type: 'policy/ePolicyStatusCount',
    });
    this.setState({ loading: true });
    listFetch(reqUrl, reqMethod, reqSearchQuery, beforeListFetch, afterListFetch, (state) => {
      this.setState(state);
    }, (errData) => (this.setState({ loading: false })));
  }

  tabOnChange = (key) => {
    const { dispatch } = this.props;
    const { beforeListFetch, afterListFetch } = this.interceptor;
    dispatch({
      type: 'policy/rChangeActiveKey',
      payload: {
        activeKey: key,
      },
    });
    dispatch({
      type: 'policy/ePolicyStatusCount',
    });
    const { searchQuery } = this.state;
    if (!_.isEmpty(key)) {
      _.set(searchQuery, 'placeHolder.PARAMS', `and POLICY_STATUS=${key}`);
    } else {
      _.set(searchQuery, 'placeHolder.PARAMS', '');
    }
    this.setState({ loading: true });
    listFetch(reqUrl, reqMethod, searchQuery, beforeListFetch, afterListFetch, (state) => {
      this.setState(state);
    }, (errData) => (this.setState({ loading: false })));
  }


  render() {
    const { title, loading, searchQuery } = this.state;
    const { policyStatusCount } = this.props;
    const searchProps = { ...this.searchRegionProps };
    _.set(searchProps, 'request.searchQuery', searchQuery);
    _.set(searchProps, 'state', this.state);

    const functionProps = { ...this.functionRegionProps };
    _.set(functionProps, 'request.searchQuery', searchQuery);
    _.set(functionProps, 'state', this.state);

    const tableProps = { ...this.tableRegionProps };
    _.set(tableProps, 'request.searchQuery', searchQuery);
    _.set(tableProps, 'state', this.state);

    const pageProps = { ...this.pageRegionProps };
    _.set(pageProps, 'request.searchQuery', searchQuery);
    _.set(pageProps, 'state', this.state);

    return (
      <Spin spinning={loading}>
        <Card bordered={false}>
          <div style={{ marginBottom: 30, fontWeight: 'bold', fontSize: 'x-large' }}>{title}</div>
          <div>
            <SearchRegion {...searchProps}/>
            <FunctionRegion {...functionProps}/>
            <Tabs type="card" defaultActiveKey="1" onChange={this.tabOnChange}>
              <TabPane tab={`已出单(${policyStatusCount[1]})`} key="1"></TabPane>
              <TabPane tab={`已退保(${policyStatusCount[2]})`} key="2"></TabPane>
              <TabPane tab={`已批单(${policyStatusCount[3]})`} key="3"></TabPane>
              <TabPane tab={`出单中(${policyStatusCount[4]})`} key="4"></TabPane>
            </Tabs>
            <TableRegion {...tableProps}/>
            <PageRegion {...pageProps} />
          </div>
        </Card>
      </Spin>
    );
  }
}

export default PolicyListPage1;
