import request from '@/utils/request';

export async function policyStatusCount() {
  return request('/listtool/demo/policyStatusCount', {
    method: 'get',
  });
}
