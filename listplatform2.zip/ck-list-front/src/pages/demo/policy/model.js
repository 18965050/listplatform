import * as service from './service';

export default {
  namespace: 'policy',
  state: {
    refreshCounter: 0,
    activeKey: '1',
    policyStatusCount: {},
  },
  reducers: {
    rChangeActiveKey(state, { payload: { activeKey } }) {
      return { ...state, activeKey };
    },
    rPolicyStatusCount(state, { payload: { policyStatusCount } }) {
      return { ...state, policyStatusCount };
    },
  },
  effects: {
    * ePolicyStatusCount({ payload }, { call, put, select }) {
      const resData = yield call(service.policyStatusCount);
      yield put({
        type: 'rPolicyStatusCount',
        payload: {
          policyStatusCount: resData.data,
        },
      });
    },
  },
};
