import React from 'react';
// import PolicyListPage from './PolicyListPage';
import PolicyListPage1 from './PolicyListPage1';

// noinspection JSUnusedGlobalSymbols
export default () => (
  <div>
      {/* <PolicyListPage/> */}
    <PolicyListPage1/>
  </div>
);
