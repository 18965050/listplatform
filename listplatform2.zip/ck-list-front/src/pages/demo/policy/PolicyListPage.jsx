import React, { Component } from 'react';
import { Button, DatePicker, Divider, Input } from 'antd';
import { connect } from 'dva';
import _ from 'lodash';
// import { ListToolPageHOC } from '@xyz/listtool';
import ListToolPageHOC from '@xyz/listtool/src/components/ListToolPageHOC';

const { RangePicker } = DatePicker;

const mapStateToProps = ({ policy, loading }) => ({
  ...policy,
  loading: loading.models.policy,
});

const outContext = {
  request: {
    reqUrl: '/api/listtool/demo',
    reqMethod: 'GET',
  }
};

const ListToolPage = ListToolPageHOC(outContext);


@connect(mapStateToProps)
class PolicyListPage extends Component {
  getCustomProps = () => ({
    interceptor: {
      beforeListFetch: (reqData) => {
        const startTime = _.get(reqData, 'param.START_TIME.value');
        if (_.isArray(startTime)) {
          const newStartTime = [];
          _.forEach(startTime, (st) => {
            newStartTime.push(st.format('YYYY-MM-DD HH:mm:ss'));
          });
          _.set(reqData, 'param.START_TIME.value', newStartTime.join(':::'));
        }
        const endTime = _.get(reqData, 'param.END_TIME.value');
        if (_.isArray(endTime)) {
          const newEndTime = [];
          _.forEach(endTime, (et) => {
            newEndTime.push(et.format('YYYY-MM-DD HH:mm:ss'));
          });
          _.set(reqData, 'param.END_TIME.value', newEndTime.join(':::'));
        }
      },
      afterListFetch: (resData) => {
        const { activeKey } = this.props;
        const specFields = _.get(resData, 'spec.fields');
        switch (activeKey) {
          case '1': {
            const filteredFields = _.filter(specFields,
              (specField) => (_.includes(['APP_ID', 'APP_NAME', 'LOGIN_NAME'], specField.key)));
            _.forEach(filteredFields, field => (_.unset(field, 'result')));
            break;
          }
          case '2': {
            const filteredFields = _.filter(specFields,
              (specField) => (_.includes(['ENDORSE_TIMES', 'PROD_NAME', 'INS_COM_ID'], specField.key)));
            _.forEach(filteredFields, field => (_.unset(field, 'result')));
            break;
          }
          case '3': {
            const filteredFields = _.filter(specFields,
              (specField) => (_.includes(['POLICY_STATUS', 'ACCEPT_TIME', 'CARD_TYPE'], specField.key)));
            _.forEach(filteredFields, field => (_.unset(field, 'result')));
            break;
          }
          case '4': {
            const filteredFields = _.filter(specFields,
              (specField) => (_.includes(['PROD_KIND', 'FLAG', 'INSURE_NAME'], specField.key)));
            _.forEach(filteredFields, field => (_.unset(field, 'result')));
            break;
          }
          default:
        }
      },
    },
    props: {
      tableRowkey: 'POLICY_NO',
      customTableColumns: [
        {
          title: '操作',
          align: 'center',
          width: 50,
          dataIndex: '__OPER__',
          render: (text, record, index) => (<span>
              <a onClick={() => alert(`状态(${record.POLICY_STATUS.value})`)}>状态</a>
            <Divider type="vertical"/>
            <a onClick={() => alert(`保单(${record.POLICY_NO.value})的详情`)}>详情</a></span>),
        },
        {
          dataIndex: 'POLICY_NO',
          render: (text, record, index) =>
            <a onClick={() => alert(`保单号(${record.POLICY_NO.value})`)}>{record.POLICY_NO.value}</a>,
        },
        {
          dataIndex: 'PROD_KEYWORD',
          width: 100,
        },
        {
          dataIndex: 'INS_COM_ID',
          width: 200,
        },
        {
          dataIndex: 'POLICY_NO',
          width: 100,
        },
        {
          dataIndex: 'APP_ID',
          width: 100,
        },
        {
          dataIndex: 'APP_CARD_NO',
          width: 100,
        },
        {
          dataIndex: 'LOGIN_NAME',
          width: 50,
        },
        {
          dataIndex: 'PROD_NAME',
          width: 50,
        },
      ],
      pageProps: {
        pageSizeOptions: ['10', '20', '30'],
      },
      customFunctions: [
        {
          key: 'add',
          comType: 'custom',
          eleRender: () => {
            const { loading } = this.props;
            return (<Button key="add"
                            icon="plus"
                            type="primary"
                            style={{ marginRight: 10 }}
                            disabled={loading}
                            onClick={() => alert('新建')}>
              新建
            </Button>);
          },
        },
      ],

      customSearchFields: [
        {
          id: 'POLICY_NO',
          eleRender: (searchField) => <Input placeholder={`这是个自定义组件,${searchField.placeHolder}`}/>,
          fieldDecorator: {
            options: {
              rules: [{ pattern: /^\S{1,50}$/, message: '只能输入1~50位非空字符' }],
            },
          },
        },
        {
          id: 'START_TIME',
          eleRender: (text, record, index) => (<RangePicker showTime placeholder="自定义组件,请输入保险起期"/>),
        },
        {
          id: 'END_TIME',
          eleRender: (text, record, index) => (<RangePicker showTime placeholder="自定义组件,请输入保险止期"/>),
        },
      ],
    }
  });

  render() {
    return (
      <div>
        <ListToolPage {...this.getCustomProps()} />
      </div>
    );
  }
}

export default PolicyListPage;
