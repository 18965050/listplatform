import _ from 'lodash';

// noinspection JSUnusedGlobalSymbols
export default {
  namespace: 'demo',
  state: {
    funcId: undefined,
    searchQuery: undefined,
  },
  reducers: {
    listFetch(state, { payload: { funcId, params } }) {
      const searchQuery = _.isEmpty(params) ? {} : JSON.parse(params);
      return { ...state, funcId, searchQuery };
    },
  },
  effects: {},
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        const m = pathname.match(/^\/listtool\/(\d+)$/);
        if (m) {
          dispatch({
            type: 'listFetch',
            payload: { funcId: m[1], params: query.searchQuery }
          });
        }
      });
    },
  },
};
