import React, { Component } from 'react';
import withRouter from 'umi/withRouter';
import { connect } from 'dva';
// import { ListToolPageHOC } from '@xyz/listtool';
import ListToolPageHOC from '@xyz/listtool/src/components/ListToolPageHOC';
import { randomStr } from '@xyz/listtool/src/utils';


const mapStateToProps = ({ demo, loading }) => ({
  ...demo,
  loading: loading.models.demo,
});

let ListToolPage = null;

@withRouter
@connect(mapStateToProps)
class DemoListPage extends Component {
  componentWillMount() {
    const { funcId, searchQuery } = this.props;
    const context = {
      request: {
        reqUrl: `/api/listtool/${funcId}`,
        searchQuery,
      },
      props: {
        tableRowkey: (record) => (randomStr(20)),
      }
    };
    ListToolPage = ListToolPageHOC(context);
  }

  render() {
    return (
      <div>
        <ListToolPage/>
      </div>
    );
  }
}

export default DemoListPage;
