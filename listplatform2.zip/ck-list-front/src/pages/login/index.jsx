import React from 'react';
import authHelper from '@/authHelper';
import './index.less';

const { LoginView, loginEnterHOC } = authHelper;
const Login = loginEnterHOC(LoginView);

function MyLogin(props) {
  // auth 集成配置地址变更的方法
  authHelper.configChangeUrlHandler(props.history.push);

  authHelper.configHistory(props.history);

  return (
    <div className="loginContainer">
      <Login/>
    </div>
  );
}

export default MyLogin;
