import React from 'react';
import home from '@/assets/home.jpeg';

export default () => (
  <p style={{ textAlign: 'center' }}>
    <img src={home} alt="欢迎页"/>
  </p>
);
