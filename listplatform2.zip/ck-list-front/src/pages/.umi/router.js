import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import _dvaDynamic from 'dva/dynamic';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/auth/login',
    component: _dvaDynamic({
      component: () =>
        import(/* webpackChunkName: "p__login__index" */ '../login/index'),
      LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
        .default,
    }),
    exact: true,
  },
  {
    path: '/listtool/:funcId',
    name: '列表查询',
    component: _dvaDynamic({
      app: require('@tmp/dva').getApp(),
      models: () => [
        import(/* webpackChunkName: 'p__demo__model.js' */ 'E:/git/list/ck-list-front/src/pages/demo/model.js').then(
          m => {
            return { namespace: 'model', ...m.default };
          },
        ),
      ],
      component: () => import(/* webpackChunkName: "p__demo" */ '../demo'),
      LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
        .default,
    }),
    exact: true,
  },
  {
    path: '/',
    component: _dvaDynamic({
      component: () =>
        import(/* webpackChunkName: "layouts__AuthLayout" */ '../../layouts/AuthLayout'),
      LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
        .default,
    }),
    routes: [
      {
        path: '/',
        name: 'welcome',
        icon: 'smile',
        component: _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "p__Welcome" */ '../Welcome'),
          LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
            .default,
        }),
        exact: true,
      },
      {
        path: '/management/datasource',
        name: '数据源管理',
        routes: [
          {
            path: '/management/datasource/list',
            name: '数据源列表',
            component: _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__management__datasource__model.js' */ 'E:/git/list/ck-list-front/src/pages/management/datasource/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__management__datasource" */ '../management/datasource'),
              LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
                .default,
            }),
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('E:/git/list/ck-list-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        path: '/management/app',
        name: '应用管理',
        routes: [
          {
            path: '/management/app/list',
            name: '应用列表',
            component: _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__management__app__model.js' */ 'E:/git/list/ck-list-front/src/pages/management/app/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__management__app" */ '../management/app'),
              LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
                .default,
            }),
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('E:/git/list/ck-list-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        path: '/management/list',
        name: '配置列表管理',
        routes: [
          {
            path: '/management/list/list',
            name: '配置应用列表',
            component: _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__management__list__models__edit.js' */ 'E:/git/list/ck-list-front/src/pages/management/list/models/edit.js').then(
                  m => {
                    return { namespace: 'edit', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__management__list__models__list.js' */ 'E:/git/list/ck-list-front/src/pages/management/list/models/list.js').then(
                  m => {
                    return { namespace: 'list', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__management__list" */ '../management/list'),
              LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
                .default,
            }),
            exact: true,
          },
          {
            path: '/management/list/add',
            name: '新增应用列表',
            component: _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__management__list__models__edit.js' */ 'E:/git/list/ck-list-front/src/pages/management/list/models/edit.js').then(
                  m => {
                    return { namespace: 'edit', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__management__list__models__list.js' */ 'E:/git/list/ck-list-front/src/pages/management/list/models/list.js').then(
                  m => {
                    return { namespace: 'list', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__management__list__components__ListEditPage" */ '../management/list/components/ListEditPage.jsx'),
              LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
                .default,
            }),
            exact: true,
          },
          {
            path: '/management/list/update',
            name: '修改应用列表',
            component: _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__management__list__models__edit.js' */ 'E:/git/list/ck-list-front/src/pages/management/list/models/edit.js').then(
                  m => {
                    return { namespace: 'edit', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__management__list__models__list.js' */ 'E:/git/list/ck-list-front/src/pages/management/list/models/list.js').then(
                  m => {
                    return { namespace: 'list', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__management__list__components__ListEditPage" */ '../management/list/components/ListEditPage.jsx'),
              LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
                .default,
            }),
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('E:/git/list/ck-list-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        path: '/management/other',
        name: '其他管理',
        routes: [
          {
            path: '/management/other/cache',
            name: '清除缓存',
            component: _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__management__cache__model.js' */ 'E:/git/list/ck-list-front/src/pages/management/cache/model.js').then(
                  m => {
                    return { namespace: 'model', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__management__cache" */ '../management/cache'),
              LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
                .default,
            }),
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('E:/git/list/ck-list-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        path: '/management/doc',
        name: '接入文档',
        routes: [
          {
            path: '/management/doc/guide',
            name: '接入指南',
            component: _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__management__doc__guide" */ '../management/doc/guide'),
              LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
                .default,
            }),
            exact: true,
          },
          {
            path: '/management/doc/other',
            name: '其他说明',
            component: _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__management__doc__other" */ '../management/doc/other'),
              LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
                .default,
            }),
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('E:/git/list/ck-list-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        path: '/listtool/demo/policy',
        name: '保单列表查询',
        component: _dvaDynamic({
          app: require('@tmp/dva').getApp(),
          models: () => [
            import(/* webpackChunkName: 'p__demo__policy__model.js' */ 'E:/git/list/ck-list-front/src/pages/demo/policy/model.js').then(
              m => {
                return { namespace: 'model', ...m.default };
              },
            ),
            import(/* webpackChunkName: 'p__demo__model.js' */ 'E:/git/list/ck-list-front/src/pages/demo/model.js').then(
              m => {
                return { namespace: 'model', ...m.default };
              },
            ),
          ],
          component: () =>
            import(/* webpackChunkName: "p__demo__policy" */ '../demo/policy'),
          LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
            .default,
        }),
        exact: true,
      },
      {
        path: '/404',
        component: _dvaDynamic({
          component: () => import(/* webpackChunkName: "p__404" */ '../404'),
          LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
            .default,
        }),
        exact: true,
      },
      {
        path: '/403',
        component: _dvaDynamic({
          component: () => import(/* webpackChunkName: "p__403" */ '../403'),
          LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
            .default,
        }),
        exact: true,
      },
      {
        path: '/500',
        component: _dvaDynamic({
          component: () => import(/* webpackChunkName: "p__500" */ '../500'),
          LoadingComponent: require('E:/git/list/ck-list-front/src/components/PageLoading/index')
            .default,
        }),
        exact: true,
      },
      {
        component: () =>
          React.createElement(
            require('E:/git/list/ck-list-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: () =>
      React.createElement(
        require('E:/git/list/ck-list-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen = () => {};

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    routeChangeHandler(history.location);
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return <Router history={history}>{renderRoutes(routes, props)}</Router>;
  }
}
