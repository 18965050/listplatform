import React, { Component } from 'react';
import withRouter from 'umi/withRouter';
import { connect } from 'dva';
import { Button, Divider, Upload } from 'antd';
// import { ListToolPageHOC } from '@xyz/listtool';
import ListToolPageHOC from '@xyz/listtool/src/components/ListToolPageHOC';
import DsEditDrawer from './DsEditDrawer';
import DsDetailDrawer from './DsDetailDrawer';
import { exportCallback, timeFmt } from '@/utils/utils';


const mapStateToProps = ({ datasource, loading }) => ({
  ...datasource,
  loading: loading.models.datasource,
});

const context = {
  request: {
    reqUrl: '/api/listtool/1',
    searchQuery: {
      order: {
        modifyTime: 1,
      },
    },
  }
};

const ListToolPage = ListToolPageHOC(context);

@withRouter
@connect(mapStateToProps)
class DsListPage extends Component {
  checkDsId = (rule, searchField, callback) => {
    if (searchField.value && !searchField.value.match(/^\d{1,9}$/)) {
      return callback('只能输入1~9位数字');
    }
    return callback();
  }

  checkDsName = (rule, searchField, callback) => {
    if (searchField.value && !searchField.value.match(/^\S{1,100}$/)) {
      return callback('只能输入1~100位非空字符');
    }
    return callback();
  }

  getCustomProps = () => {
    const { refreshCounter } = this.props;
    return {
      request: { refreshCounter },
      props: {
        tableRowkey: 'dsId',
        customTableColumns: [
          {
            title: '操作',
            align: 'center',
            dataIndex: '__OPER__',
            render: (text, record, index) => {
              const statusDom = (record.status.value === 0 ? <a onClick={() => this.handleStatus(record)}>启用</a> :
                <a onClick={() => this.handleStatus(record)}>停用</a>);

              return (<span>
          {statusDom}
                <Divider type="vertical"/>
          <a onClick={() => this.handleEdit(record.dsId.value)}>修改</a>
        <Divider type="vertical"/>
          <a onClick={() => this.handleDetail(record.dsId.value)}>详情</a>
        </span>);
            },
          },
          {
            dataIndex: 'createTime',
            render: timeFmt,
          },
          {
            dataIndex: 'modifyTime',
            render: timeFmt,
          },
        ],
        pageProps: {
          pageSizeOptions: ['10', '20', '30'],
        },
        tableProps: {
          rowSelection: this.rowSelectionHandler(),
        },
        customFunctions: [
          {
            key: 'add',
            comType: 'custom',
            eleRender: (renderContext) => {
              const { loading } = renderContext;
              return (<Button key="add"
                              icon="plus"
                              type="primary"
                              style={{ marginRight: 10 }}
                              disabled={loading}
                              onClick={this.handleCreate}>
                新建
              </Button>);
            },
          },
          {
            key: 'exportData',
            comType: 'custom',
            eleRender: (renderContext) => {
              const { selectedRowKeys, loading } = this.props;
              const { loading: contextLoading } = renderContext;
              const hasSelected = selectedRowKeys.length > 0;
              return (<Button icon="export"
                              key="exportData"
                              type="primary"
                              style={{ marginRight: 10 }}
                              disabled={!hasSelected || loading || contextLoading}
                              onClick={() => this.exportSelectionRows(selectedRowKeys)}>
                导出
              </Button>);
            },
          },
          {
            key: 'importData',
            comType: 'custom',
            eleRender: (renderContext) => {
              const { loading } = this.props;
              const { loading: contextLoading } = renderContext;
              return (<Upload key="importData" accept=".txt" fileList={[]} action={this.importHandler}>
                <Button icon="import" type="primary" disabled={loading || contextLoading}>导入</Button>
              </Upload>);
            },
          },
        ],
        customSearchFields: [
          {
            id: 'dsId',
            fieldDecorator: {
              options: {
                rules: [{ validator: this.checkDsId }],
              },
            },
          },
          {
            id: 'dsName',
            fieldDecorator: {
              options: {
                rules: [{ validator: this.checkDsName }],
              },
            },
          },
        ],
      }
    }
  };

  rowSelectionHandler = () => {
    const { selectedRowKeys } = this.props;
    return {
      selectedRowKeys,
      onChange: this.rowSelectChange,
    };
  };

  rowSelectChange = (selectedRowKeys) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'datasource/rowSelectChange',
      payload: {
        selectedRowKeys
      },
    });
  };

  exportSelectionRows = (selectedRowKeys) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'datasource/export',
      payload: {
        dsIds: selectedRowKeys,
      },
      callback: ({ data }) => (exportCallback({ filename: 'listtool_datasource_info.txt', data })),
    });
  };

  importHandler = (file) => {
    const { dispatch, refreshCounter } = this.props;
    dispatch({
      type: 'datasource/importData',
      payload: {
        file,
        refreshCounter,
      },
    });
  };

  handleDetail = (dsId) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'datasource/initDetail',
      payload: {
        dsId,
      },
    });
  };

  handleEdit = (dsId) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'datasource/initEdit',
      payload: {
        dsId,
      },
    });
  };

  handleCreate = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'datasource/createModal',
    });
  };

  handleStatus = (record) => {
    const { dispatch, refreshCounter } = this.props;
    dispatch({
      type: 'datasource/changeStatus',
      payload: {
        record,
        refreshCounter,
      },
    });
  };

  render() {
    return (
      <div>
        <DsEditDrawer/>
        <DsDetailDrawer/>
        <ListToolPage {...this.getCustomProps()}/>
      </div>
    );
  }
}

export default DsListPage;
