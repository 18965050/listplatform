import React, { Component } from 'react';
import { connect } from 'dva';
import _ from 'lodash';
import { Button, Col, Divider, Drawer, Form, Input, Row, Select } from 'antd';
import withRouter from 'umi/withRouter';

const mapStateToProps = ({
                           datasource:
                             {
                               editModalVisible,
                               editRecord,
                               editType,
                               refreshCounter,
                             }
                         }) => ({
  visible: editModalVisible,
  record: editRecord,
  editType,
  refreshCounter,
});

@withRouter
@connect(mapStateToProps)
@Form.create()
class DsEditDrawer extends Component {
  onOk = () => {
    const { editType, record, dispatch, form, refreshCounter } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = { ...fieldsValue };
      dispatch({
        type: 'datasource/edit',
        payload: {
          editType,
          oldRecord: record,
          values,
          form,
          refreshCounter,
        },
      });
    });
  };

  onCancel = () => {
    const { dispatch, form } = this.props;
    dispatch({
      type: 'datasource/editModalVisible',
      payload: {
        visible: false,
      },
    });
    form.resetFields();
  };


  render() {
    const { form, editType, visible, record } = this.props;
    const title = editType === 'edit' ? '编辑' : '创建';
    const formItemLayout = { labelCol: { span: 8 }, wrapperCol: { span: 16 } };
    return (
      <Drawer
        title={title}
        visible={visible}
        onClose={this.onCancel}
        width="50%"
      >
        <Form {...formItemLayout}>
          <Row gutter={16}>
            <Col offset={4} span={16}>
              <Form.Item key="dsId" label="数据源ID">
                {form.getFieldDecorator('dsId', {
                  rules: [{ required: true, message: '请输入ID' }, { pattern: /^\d+$/, message: '请输入数字！' }],
                  initialValue: record.dsId,
                })(<Input placeholder="请输入" disabled={editType === 'edit'}/>)}
              </Form.Item>
              <Form.Item key="dsName" label="数据源名称">
                {form.getFieldDecorator('dsName', {
                  rules: [{ required: true, message: '请输入名称' }],
                  initialValue: record.dsName,
                })(<Input placeholder="请输入"/>)}
              </Form.Item>
              <Form.Item key="dsType" label="数据源类型">
                {form.getFieldDecorator('dsType', {
                  rules: [{ required: true, message: '请输入类型' }],
                  initialValue: _.isUndefined(record.dsType) ? undefined : `${record.dsType}`,
                })(<Select placeholder="请选择">
                  <Select.Option value="0">Oracle</Select.Option>
                  <Select.Option value="1">MySql</Select.Option>
                </Select>)}
              </Form.Item>
              <Form.Item key="dsDesc" label="备注信息">
                {form.getFieldDecorator('dsDesc', {
                  initialValue: record.dsDesc,
                })(<Input.TextArea rows={4} placeholder="请输入备注信息"/>)}
              </Form.Item>
              <Form.Item key="status" label="状态">
                {form.getFieldDecorator('status', {
                  rules: [{ required: true, message: '请输入状态' }],
                  initialValue: _.isUndefined(record.status) ? undefined : `${record.status}`,
                })(<Select placeholder="请选择">
                  <Select.Option value="0">停用</Select.Option>
                  <Select.Option value="1">启用</Select.Option>
                </Select>)}
              </Form.Item>
            </Col>
          </Row>
        </Form>
        <Divider/>
        <div
          style={{
            textAlign: 'right',
          }}
        >
          <Button onClick={this.onCancel} style={{ marginRight: 8 }}>
            取消
          </Button>
          <Button onClick={this.onOk} type="primary">
            提交
          </Button>
        </div>
      </Drawer>
    );
  }
}

export default DsEditDrawer;
