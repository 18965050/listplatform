import React from 'react';
import { connect } from 'dva';
import { Descriptions, Drawer } from 'antd';

const mapStateToProps = ({ datasource: { detailVisible, detailRecord } }) => ({
  visible: detailVisible,
  record: detailRecord,
});

function DsDetailDrawer({ dispatch, visible, record }) {
  const onClose = () => {
    dispatch({
      type: 'datasource/detailClose',
    });
  };

  return (
    <Drawer
      title="数据源详情"
      placement="right"
      visible={visible}
      onClose={onClose}
      width={1024}
    >
      <Descriptions title="基本信息" column={1} bordered>
        <Descriptions.Item label="数据源ID">{record.dsId}</Descriptions.Item>
        <Descriptions.Item label="数据源名称">{record.dsName}</Descriptions.Item>
        <Descriptions.Item label="数据源类型">{record.dsType === 0 ? 'Oracle' : 'Mysql'}</Descriptions.Item>
        <Descriptions.Item label="备注信息">
          {record.dsDesc}
        </Descriptions.Item>
        <Descriptions.Item label="状态">
          {record.status === 0 ? '停用' : '启用'}
        </Descriptions.Item>
      </Descriptions>
    </Drawer>
  );
}

export default connect(mapStateToProps)(DsDetailDrawer);
