import * as service from './service';

// noinspection JSUnusedGlobalSymbols
export default {
  namespace: 'datasource',
  state: {
    refreshCounter: 0,
    detailVisible: false,
    detailRecord: {},
    editModalVisible: false,
    editType: 'create',
    selectedRowKeys: [], // 选中的行
    editRecord: {},
  },
  reducers: {
    editModalVisible(state, { payload: { visible } }) {
      return { ...state, editModalVisible: visible };
    },
    detailClose(state) {
      return { ...state, detailRecord: {}, detailVisible: false };
    },
    showDetail(state, { payload: { record } }) {
      return { ...state, detailRecord: record, detailVisible: true };
    },
    createModal(state) {
      return {
        ...state,
        editType: 'create',
        editModalVisible: true,
        editRecord: {},
      };
    },
    editModal(state, { payload: { record } }) {
      return {
        ...state,
        editRecord: record,
        editType: 'edit',
        editModalVisible: true,
      };
    },
    rowSelectChange(state, { payload: { selectedRowKeys } }) {
      return { ...state, selectedRowKeys };
    },
    listFetch(state, { payload: { refreshCounter } }) {
      return {
        ...state,
        refreshCounter,
      };
    },
  },
  effects: {
    * edit({ payload: { editType, values, oldRecord, form, refreshCounter } }, { call, put, select }) {
      const serviceMethod = editType === 'edit' ? service.update : service.add;
      const postData = { ...oldRecord, ...values };
      yield call(serviceMethod, postData);
      yield put({
        type: 'editModalVisible',
        payload: {
          visible: false,
        },
      });
      form.resetFields();
      yield put({
        type: 'listFetch',
        payload: { refreshCounter: refreshCounter + 1 },
      });
    },

    * initDetail({ payload: { dsId } }, { call, put, select }) {
      const detailData = yield call(service.detail, dsId);
      yield put({
        type: 'showDetail',
        payload: {
          record: detailData.data,
        },
      });
    },

    * initEdit({ payload: { dsId } }, { call, put, select }) {
      const recordData = yield call(service.detail, dsId);
      yield put({
        type: 'editModal',
        payload: {
          record: recordData.data,
        },
      });
    },

    * changeStatus({ payload: { record, refreshCounter } }, { call, put, select }) {
      const status = (record.status.value === 0 ? 1 : 0);
      const postData = { dsId: record.dsId.value, status };
      yield call(service.changeStatus, postData);
      yield put({
        type: 'listFetch',
        payload: { refreshCounter: refreshCounter + 1 },
      });
    },

    * importData({ payload: { file, refreshCounter } }, { call, put, select }) {
      const data = new FormData();
      data.append('file', file);
      yield call(service.importData, data);
      yield put({
        type: 'listFetch',
        payload: { refreshCounter: refreshCounter + 1 },
      });
    },

    * export({ payload: { dsIds }, callback }, { call, put, select }) {
      yield call(service.exportData, { dsIds }, callback);
    },
  },

};
