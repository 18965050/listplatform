import request from '@/utils/request';

export async function detail(dsId) {
  return request('/management/datasource/detail', {
    method: 'get',
    params: { dsId },
  });
}

export async function add(data) {
  return request('/management/datasource/add', {
    method: 'post',
    data,
  });
}

export async function update(data) {
  return request('/management/datasource/update', {
    method: 'post',
    data,
  });
}

export async function changeStatus(data) {
  return request('/management/datasource/changeStatus', {
    method: 'post',
    data,
  });
}

export async function exportData(params, callback) {
  return request('/management/datasource/exportRows', {
    method: 'get',
    responseType: 'blob',
    params,
  }, callback);
}

export async function importData(data) {
  return request('/management/datasource/importData', {
    contentType: 'multipart/form-data',
    method: 'post',
    data,
  });
}
