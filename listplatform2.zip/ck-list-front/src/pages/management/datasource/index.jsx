import React from 'react';
import DsListPage from './components/DsListPage';

// noinspection JSUnusedGlobalSymbols
export default () => (
  <div>
    <DsListPage/>
  </div>
);
