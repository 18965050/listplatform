// noinspection JSUnusedGlobalSymbols
import * as service from '@/pages/management/cache/service';

export default {
  namespace: 'cache',
  state: {
    msg: '',
  },
  reducers: {
    showResult(state, { payload: { msg } }) {
      return { ...state, msg };
    },
  },
  effects: {
    * invalidate({ payload: { type } }, { call, put, select }) {
      const resData = yield call(service.invalidate, type);
      yield put({
        type: 'showResult',
        payload: {
          msg: resData.ret === 0 ? '缓存刷新成功' : '缓存刷新失败',
        },
      });
    },

  },
  subscriptions: {},
};
