import React, { Component } from 'react';
import { connect } from 'dva';
import { Button, message } from 'antd';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import styles from '@/pages/style.less';

const mapStateToProps = ({ cache, loading }) => ({
  ...cache,
  loading: loading.models.cache,
});

@connect(mapStateToProps)
class CachePage extends Component {
  componentWillUpdate(nextProps, nextState) {
    const { msg, loading } = nextProps;
    if (loading && msg) {
      message.info(msg, 1);
    }
  }

  render() {
    const { dispatch, loading } = this.props;
    return (
      <PageHeaderWrapper title="缓存管理">
        <div className={styles.tableListOperator}>
          <Button style={{ marginRight: 100 }}
                  icon="delete"
                  size="large"
                  type="primary"
                  disabled={loading}
                  onClick={() => {
                    dispatch({
                      type: 'cache/invalidate',
                      payload: {
                        type: '1',
                      },
                    });
                  }}>
            清除缓存
          </Button>

          <Button icon="delete" size="large" type="primary" disabled={loading} onClick={() => {
            dispatch({
              type: 'cache/invalidate',
              payload: {
                type: '2',
              },
            });
          }}>
            清除导出锁
          </Button>
        </div>
      </PageHeaderWrapper>
    );
  }
}

export default CachePage;
