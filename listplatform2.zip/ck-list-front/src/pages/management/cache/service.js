import request from '@/utils/request';

export async function invalidate(data) {
  return request('/management/cache/invalidate', {
    method: 'post',
    data,
  });
}
