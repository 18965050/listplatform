import React from 'react';
import CachePage from './components/CachePage';

// noinspection JSUnusedGlobalSymbols
export default () => (
  <div>
    <CachePage/>
  </div>
);
