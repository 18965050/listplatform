import request from '@/utils/request';

export async function detail(listId) {
  return request('/management/list/detail', {
    method: 'get',
    params: { listId },
  });
}

export async function add(data) {
  return request('/management/list/add', {
    method: 'post',
    data,
  });
}

export async function update(data) {
  return request('/management/list/update', {
    method: 'post',
    data,
  });
}

export async function pipelineDebug(data) {
  return request('/management/list/pipelineDebug', {
    method: 'post',
    data,
  });
}

export async function changeStatus(data) {
  return request('/management/list/changeStatus', {
    method: 'post',
    data,
  });
}

export async function getAppIds() {
  return request('/management/app/getAppIds', {
    method: 'get',
  });
}

export async function getDatasources() {
  return request('/management/datasource/getDatasources', {
    method: 'get',
  });
}

export async function getSearchMatch() {
  return request('/management/list/getSearchMatch', {
    method: 'get',
  });
}

export async function getPipelineType() {
  return request('/management/list/getPipelineType', {
    method: 'get',
  });
}

export async function getSearchDataType() {
  return request('/management/list/getSearchDataType', {
    method: 'get',
  });
}

export async function exportData(params, callback) {
  return request('/management/list/exportRows', {
    method: 'get',
    responseType: 'blob',
    params,
  }, callback);
}

export async function importData(data) {
  return request('/management/list/importData', {
    contentType: 'multipart/form-data',
    method: 'post',
    data,
  });
}
