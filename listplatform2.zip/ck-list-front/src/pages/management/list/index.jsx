import React from 'react';
import ListListPage from './components/ListListPage';

// noinspection JSUnusedGlobalSymbols
export default () => (
  <div>
    <ListListPage/>
  </div>
);
