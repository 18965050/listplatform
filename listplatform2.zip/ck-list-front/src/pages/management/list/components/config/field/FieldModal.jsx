import React, { Component } from 'react';
import { Button, Modal, Table } from 'antd';
import { connect } from 'dva';
import _ from 'lodash';
import EditableTable from './EditableTable';


const { Column, ColumnGroup } = Table;

const mapStateToProps = ({ editList: { fieldModalVisible, context, listRecord }, loading }) => ({
  fieldModalVisible,
  context,
  listRecord,
  loading: loading.models.editList,
});

@connect(mapStateToProps)
class FieldModal extends Component {
  modalOk = () => {
    const { dispatch, context, listRecord } = this.props;
    const { fields: specFields } = context;
    if (!_.isEmpty(specFields)) {
      _.set(listRecord, 'context.fields', specFields);
    } else {
      _.set(listRecord, 'context.fields', []);
    }
    dispatch({
      type: 'editList/rChangeListRecord',
      payload: {
        listRecord: { ...listRecord },
      },
    });
    this.modalCancel();
  }

  modalCancel = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'editList/rChangeFieldEditingKey',
      payload: {
        fieldEditingKey: '',
      }
    });
    dispatch({
      type: 'editList/rCloseFieldModal',
    });
  }

  render() {
    const { fieldModalVisible } = this.props;
    return (<Modal
      title="字段配置"
      visible={fieldModalVisible}
      width={1600}
      destroyOnClose
      maskClosable={false}
      onCancel={this.modalCancel}
      footer={[
        <Button key="ok" type="primary" onClick={this.modalOk}>确定</Button>,
        <Button key="cancel" type="primary" onClick={this.modalCancel}>取消</Button>
      ]}>
      <EditableTable/>

    </Modal>);
  }
}

export default FieldModal;
