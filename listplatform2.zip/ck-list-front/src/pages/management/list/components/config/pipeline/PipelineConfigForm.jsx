import React, { Component } from 'react';
import { Col, Form, Input, InputNumber, Row, Select } from 'antd';
import { connect } from 'dva';
import Link from 'umi/link';
import _ from 'lodash';
import MonacoEditor from 'react-monaco-editor';
import { ALL_FIELDS } from '@/utils/utils';

const mapStateToProps = ({ editList: { datasources, context, pipelineType }, loading }) => ({
  datasources,
  context,
  pipelineType,
  loading: loading.models.editList,
});

@connect(mapStateToProps)
@Form.create()
class PipelineConfigForm extends Component {
  componentDidMount() {
    this.props.onRef(this);
  }

  pipelineDataOnChange = (path, value) => {
    const { context, dispatch, specPipeline } = this.props;
    _.set(specPipeline, path, value);
    dispatch({
      type: 'editList/rChangeContext',
      payload: {
        context: { ...context },
      },
    });
  };

  onSave = (key) => {
    const { form, specPipeline } = this.props;
    const formVal = {};
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      _.extend(formVal, { name: fieldsValue.name, type: fieldsValue.type, index: fieldsValue.index });
      switch (specPipeline.type) {
        case 'script':
          _.set(formVal, 'data', _.get(specPipeline, 'data', ''));
          break;
        case 'execMapping':
          _.set(formVal, 'data.ds', fieldsValue.ds);
          _.set(formVal, 'data.mappingFields', fieldsValue.mappingFields);
          break;
        case 'execQl':
          _.set(formVal, 'data.ds', fieldsValue.ds);
          _.set(formVal, 'data.ql', _.get(specPipeline, 'data.ql', ''));
          _.set(formVal, 'data.placeHolder', _.get(specPipeline, 'data.placeHolder', ''));
          _.set(formVal, 'data.paging', fieldsValue.paging);
          _.set(formVal, 'data.queries', fieldsValue.queries);
          _.set(formVal, 'data.orders', fieldsValue.orders);
          break;
        case 'mergeTempRes':
          _.set(formVal, 'data.source', fieldsValue.source);
          _.set(formVal, 'data.target', fieldsValue.target);
          _.set(formVal, 'data.relateFields', _.split(fieldsValue.relateFields, ','));
          break;
        case 'generatorRes':
          _.unset(formVal, 'data');
          break;
        default:
      }
    });
    return formVal;
  }

  checkKeyDuplicate = (rule, value, callback) => {
    const { context, specPipeline } = this.props;
    const { pipelines: specPipelines } = context;
    const specPipelinesClone = _.clone(specPipelines);
    _.remove(specPipelinesClone, (specPipelineClone) => (specPipelineClone.name === specPipeline.name));
    if (!_.isEmpty(_.filter(specPipelinesClone, specPipelineClone => (specPipelineClone.name === value)))) {
      callback('名称重复, 请重新设置');
      return;
    }
    callback();
  }

  checkIndexDuplicate = (rule, value, callback) => {
    const { context, specPipeline } = this.props;
    const { pipelines: specPipelines } = context;
    const specPipelinesClone = _.clone(specPipelines);
    _.remove(specPipelinesClone, (specPipelineClone) => (specPipelineClone.name === specPipeline.name));
    if (!_.isEmpty(_.filter(specPipelinesClone, specPipelineClone => (specPipelineClone.index === value)))) {
      callback('权重重复, 请重新设置');
    }
    callback();
  }

  getAllMappingFields = () => {
    const { context } = this.props;
    const { fields: specFields } = context;
    const mappingFields = [ALL_FIELDS];
    _.forEach(specFields, (specField) => {
      if (specField.key && specField.mapping) {
        mappingFields.push(specField.key);
      }
    });
    return mappingFields;
  };

  getAllSearchFields = () => {
    const { context } = this.props;
    const { fields: specFields } = context;
    const searchFields = [ALL_FIELDS];
    _.forEach(specFields, (specField) => {
      if (specField.key && specField.search) {
        searchFields.push(specField.key);
      }
    });
    return searchFields;
  };

  getAllOrderFields = () => {
    const { context } = this.props;
    const { fields: specFields } = context;
    const orderFields = [ALL_FIELDS];
    _.forEach(specFields, (specField) => {
      if (specField.key && _.get(specField, 'result.order') === 1) {
        orderFields.push(specField.key);
      }
    });
    return orderFields;
  };

  render() {
    const { form, specPipeline, pipelineType, datasources } = this.props;
    const { type: curPipelineType } = specPipeline;
    const mappingFields = this.getAllMappingFields();
    const searchFields = this.getAllSearchFields();
    const orderFields = this.getAllOrderFields();
    const formItemLayout = { labelCol: { offset: 0, span: 4 }, wrapperCol: { span: 16 } };
    return (<Form {...formItemLayout}>
      <Row gutter={16}>
        <Col span={24}>
          <Form.Item key="name" label="名称">
            {form.getFieldDecorator('name', {
              rules: [{ required: true, message: '请输入名称' },
                { pattern: /^\w+$/, message: '请输入字母数字组合！' },
                { validator: this.checkKeyDuplicate }],
              initialValue: specPipeline.name,
            })(<Input placeholder="请输入"/>)}
          </Form.Item>
          <Form.Item key="type" label="类型">
            {form.getFieldDecorator('type', {
              rules: [{ required: true, message: '请输入类型' }],
              initialValue: specPipeline.type,
            })(<Select placeholder="请选择" onChange={(value) => this.pipelineDataOnChange('type', value)}>
              {_.map(pipelineType,
                (value, key) => (
                  <Select.Option key={key} value={key}>{value}</Select.Option>))}
            </Select>)}
          </Form.Item>
          {curPipelineType === 'script' && (<Form.Item key="script" label="脚本">
            <MonacoEditor
              width="830"
              height="300"
              onChange={(value) => (this.pipelineDataOnChange('data', value))}
              language="java"
              theme="vs-dark"
              value={_.isString(specPipeline.data) ? specPipeline.data : ''}
            />
            <div style={{ width: 1000, textAlign: 'right' }}>
              <Link to="/management/doc/function" target="_blank">引擎函数说明</Link>
            </div>
          </Form.Item>)}

          {curPipelineType === 'execMapping' && (
            <React.Fragment>
              <Form.Item key="ds" label="数据源">
                {form.getFieldDecorator('ds', {
                  rules: [{ required: true, message: '请输入数据源' }],
                  initialValue: _.get(specPipeline, 'data.ds', ''),
                })(<Select placeholder="请选择">
                  {_.map(datasources,
                    (datasource) => (
                      <Select.Option key={datasource} value={datasource}>{datasource}</Select.Option>))}
                </Select>)}
              </Form.Item>
              <Form.Item key="mappingFields" label="映射字段">
                {form.getFieldDecorator('mappingFields', {
                  initialValue: _.get(specPipeline, 'data.mappingFields', []),
                })(<Select mode="multiple" placeholder="请选择">
                  {_.map(mappingFields,
                    (value) => (
                      <Select.Option key={value} value={value}>{value}</Select.Option>))}
                </Select>)}
              </Form.Item>
            </React.Fragment>
          )}

          {curPipelineType === 'execQl' && (
            <React.Fragment>
              <Form.Item key="ds" label="数据源">
                {form.getFieldDecorator('ds', {
                  rules: [{ required: true, message: '请输入数据源' }],
                  initialValue: _.get(specPipeline, 'data.ds', ''),
                })(<Select placeholder="请选择">
                  {_.map(datasources,
                    (datasource) => (
                      <Select.Option key={datasource} value={datasource}>{datasource}</Select.Option>))}
                </Select>)}
              </Form.Item>
              <Form.Item key="ql" label="ql语句模板">
                <MonacoEditor
                  width="830"
                  height="300"
                  onChange={(value) => (this.pipelineDataOnChange('data.ql', value))}
                  language="sql"
                  theme="vs-dark"
                  value={_.get(specPipeline, 'data.ql', '')}
                />
              </Form.Item>
              <Form.Item key="placeHolder" label="placeHolder生成脚本">
                <MonacoEditor
                  width="830"
                  height="200"
                  onChange={(value) => (this.pipelineDataOnChange('data.placeHolder', value))}
                  language="java"
                  theme="vs-dark"
                  value={_.get(specPipeline, 'data.placeHolder', '')}
                />
              </Form.Item>
              <Form.Item key="paging" label="是否分页">
                {form.getFieldDecorator('paging', {
                  rules: [{ required: true, message: '请输入' }],
                  initialValue: _.get(specPipeline, 'data.paging', 1),
                })(<Select placeholder="请选择">
                  <Select.Option value={1}>是</Select.Option>
                  <Select.Option value={0}>否</Select.Option>
                </Select>)}
              </Form.Item>
              <Form.Item key="queries" label="检索字段">
                {form.getFieldDecorator('queries', {
                  initialValue: _.get(specPipeline, 'data.queries', []),
                })(<Select mode="multiple" placeholder="请选择">
                  {_.map(searchFields,
                    (value) => (
                      <Select.Option key={value} value={value}>{value}</Select.Option>))}
                </Select>)}
              </Form.Item>
              <Form.Item key="orders" label="排序字段">
                {form.getFieldDecorator('orders', {
                  initialValue: _.get(specPipeline, 'data.orders', []),
                })(<Select mode="multiple" placeholder="请选择">
                  {_.map(orderFields,
                    (value) => (
                      <Select.Option key={value} value={value}>{value}</Select.Option>))}
                </Select>)}
              </Form.Item>
            </React.Fragment>
          )}

          {curPipelineType === 'mergeTempRes' && (
            <React.Fragment>
              <Form.Item key="source" label="源名称">
                {form.getFieldDecorator('source', {
                  rules: [{ required: true, message: '请输入源名称' }],
                  initialValue: _.get(specPipeline, 'data.source', ''),
                })(<Input placeholder="请输入"/>)}
              </Form.Item>
              <Form.Item key="target" label="目标名称">
                {form.getFieldDecorator('target', {
                  rules: [{ required: true, message: '请输入目标名称' }],
                  initialValue: _.get(specPipeline, 'data.target', ''),
                })(<Input placeholder="请输入"/>)}
              </Form.Item>
              <Form.Item key="relateFields" label="关联字段">
                {form.getFieldDecorator('relateFields', {
                  rules: [{ required: true, message: '请输入关联字段' }],
                  initialValue: _.join(_.get(specPipeline, 'data.relateFields', [])),
                })(<Input placeholder="请输入,多字段以逗号分隔"/>)}
              </Form.Item>
            </React.Fragment>
          )}

          {curPipelineType === 'generatorRes' && (
            <React.Fragment>
            </React.Fragment>
          )}

          <Form.Item key="index" label="权重">
            {form.getFieldDecorator('index', {
              rules: [{ required: true, message: '请输入' },
                { validator: this.checkIndexDuplicate }],
              initialValue: specPipeline.index || 0,
            })(<InputNumber min={0} max={100}/>)}
          </Form.Item>
        </Col>
      </Row></Form>);
  }
}

export default PipelineConfigForm;
