import React, { Component } from 'react';
import { Button, Collapse, Divider, Modal } from 'antd';
import { connect } from 'dva';
import _ from 'lodash';

import { randomStr } from '@xyz/listtool';
import FunctionForm from './FunctionForm';

const { Panel } = Collapse;

const mapStateToProps = ({ editList: { functionModalVisible, panelFuncActiveKey, context, listRecord }, loading }) => ({
  functionModalVisible,
  panelFuncActiveKey,
  context,
  listRecord,
  loading: loading.models.editList,
});

@connect(mapStateToProps)
class FunctionModal extends Component {
  genExtra = (key) => {
    return (<div>
      <a onClick={(e) => this.onPanelSave(e, key)}>保存</a>
      <Divider type="vertical"/>
      <a onClick={(e) => this.onPanelDelete(e, key)}>删除</a>
    </div>);
  }

  onPanelChange = (key) => {
    const { dispatch } = this.props;
    const panelFuncActiveKey = _.isEmpty(key) ? '' : key;
    dispatch({
      type: 'editList/rChangePanelFuncActiveKey',
      payload: {
        panelFuncActiveKey,
      },
    });
  }

  onPanelSave = (e, key) => {
    e.stopPropagation();
    const { dispatch, context } = this.props;
    const { functions: specFuncs } = context;
    const curFunc = _.filter(specFuncs, (specFunc) => (specFunc.key === key))[0];
    if (!_.isEmpty(curFunc)) {
      const { formRef } = curFunc;
      const formVal = formRef.onSave(key);
      if (!_.isEmpty(formVal)) {
        _.merge(curFunc, formVal);
        dispatch({
          type: 'editList/rChangeContext',
          payload: {
            context: { ...context },
          },
        });
        dispatch({
          type: 'editList/rChangePanelFuncActiveKey',
          payload: {
            panelFuncActiveKey: '',
          },
        });
      }
    }
  }

  onPanelDelete = (e, key) => {
    e.stopPropagation();
    const { dispatch, context } = this.props;
    const { functions: specFuncs } = context;
    _.remove(specFuncs, (specFunc) => (specFunc.key === key));
    dispatch({
      type: 'editList/rChangeContext',
      payload: {
        context: { ...context },
      },
    });
  }

  modalOk = () => {
    const { dispatch, context, listRecord } = this.props;
    const { functions: specFuncs } = context;
    if (!_.isEmpty(specFuncs)) {
      _.forEach(specFuncs, (specFunc) => {
        _.unset(specFunc, 'formRef');
      });
      _.set(listRecord, 'context.functions', specFuncs);
    } else {
      _.set(listRecord, 'context.functions', []);
    }

    dispatch({
      type: 'editList/rChangeListRecord',
      payload: {
        listRecord: { ...listRecord },
      },
    });
    this.modalCancel();
  }

  modalCancel = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'editList/rCloseFunctionModal',
    });
  }

  onAdd = () => {
    const { context, dispatch } = this.props;
    const { functions: specFuncs } = context;
    const panelFuncActiveKey = randomStr(10);
    const curMaxIndex = _.get(_.maxBy(specFuncs, (specFunc) => (specFunc.index)), 'index', -1);
    const newFunc = { key: panelFuncActiveKey, comType: '', index: curMaxIndex + 1 };
    if (_.isEmpty(specFuncs)) {
      _.set(context, 'functions', [newFunc]);
    } else {
      specFuncs.push(newFunc);
    }
    dispatch({
      type: 'editList/rChangeContext',
      payload: {
        context: { ...context },
      },
    });
    dispatch({
      type: 'editList/rChangePanelFuncActiveKey',
      payload: {
        panelFuncActiveKey,
      },
    });
  }

  render() {
    const { context, functionModalVisible, panelFuncActiveKey } = this.props;
    const panels = [];
    const specFuncs = _.get(context, 'functions');
    if (!_.isEmpty(specFuncs)) {
      _.forEach(specFuncs, (specFunc, index) => {
        const panel = (<Panel header={specFunc.key} key={specFunc.key} extra={this.genExtra(specFunc.key)}>
          <FunctionForm specFunc={specFunc} onRef={(ref) => (_.set(specFunc, 'formRef', ref))}/>
        </Panel>);
        panels.push(panel);
      });
    }
    return (<Modal
      title="功能域配置"
      visible={functionModalVisible}
      destroyOnClose
      maskClosable={false}
      onCancel={this.modalCancel}
      footer={[
        <Button key="ok" type="primary" onClick={this.modalOk}>确定</Button>,
        <Button key="cancel" type="primary" onClick={this.modalCancel}>取消</Button>
      ]}>
      <Button type="primary" onClick={this.onAdd}>添加</Button>
      <Collapse style={{ marginTop: 10 }}
                accordion
                onChange={this.onPanelChange}
                activeKey={`${panelFuncActiveKey}`}>
        {panels}
      </Collapse>
    </Modal>);
  }
}

export default FunctionModal;
