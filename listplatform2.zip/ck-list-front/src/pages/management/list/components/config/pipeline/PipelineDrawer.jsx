import { connect } from 'dva';
import React, { Component } from 'react';
import { Button, Col, Collapse, Divider, Drawer, Form, Row, Spin, } from 'antd';
import MonacoEditor from 'react-monaco-editor';
import _ from 'lodash';
import { randomStr } from '@xyz/listtool';

import PipelineConfigForm from './PipelineConfigForm';
import { isEmptyOrJSON, jsonBeautify } from '@/utils/utils';


const { Panel } = Collapse;

const mapStateToProps = ({
                           editList: {
                             context,
                             debugParam,
                             debugParamCheck,
                             debugLog,
                             listRecord,
                             pipelineDrawerVisible,
                             panelPipelineActiveKey
                           }, loading
                         }) => ({
  context,
  debugParam,
  debugParamCheck,
  debugLog,
  listRecord,
  pipelineDrawerVisible,
  panelPipelineActiveKey,
  loading: loading.models.editList,
});


@connect(mapStateToProps)
class PipelineDrawer extends Component {
  genExtra = (key) => {
    return (<div>
      <a onClick={(e) => this.onPanelSave(e, key)}>保存</a>
      <Divider type="vertical"/>
      <a onClick={(e) => this.onPanelDelete(e, key)}>删除</a>
    </div>);
  }

  onPanelSave = (e, key) => {
    e.stopPropagation();
    const { dispatch, context } = this.props;
    const { pipelines: specPipelines } = context;
    const curPipeline = _.filter(specPipelines, (specPipeline) => (specPipeline.name === key))[0];
    if (!_.isEmpty(curPipeline)) {
      const { configRef } = curPipeline;
      const formVal = configRef.onSave(key);
      if (!_.isEmpty(formVal)) {
        _.merge(curPipeline, formVal);
        dispatch({
          type: 'editList/rChangeContext',
          payload: {
            context: { ...context },
          },
        });
        dispatch({
          type: 'editList/rChangePanelPipelineActiveKey',
          payload: {
            panelPipelineActiveKey: '',
          },
        });
      }
    }
  }

  onPanelDelete = (e, key) => {
    e.stopPropagation();
    const { dispatch, context } = this.props;
    const { pipelines: specPipelines } = context;
    _.remove(specPipelines, (specPipeline) => (specPipeline.name === key));
    dispatch({
      type: 'editList/rChangeContext',
      payload: {
        context: { ...context },
      },
    });
  }

  onPanelChange = (key) => {
    const { dispatch } = this.props;
    const panelPipelineActiveKey = _.isEmpty(key) ? '' : key;
    dispatch({
      type: 'editList/rChangePanelPipelineActiveKey',
      payload: {
        panelPipelineActiveKey,
      },
    });
  }

  onOk = () => {
    const { dispatch, context, listRecord, debugParam } = this.props;
    const { pipelines: specPipelines } = context;
    if (!_.isEmpty(specPipelines)) {
      _.forEach(specPipelines, (specPipeline) => {
        _.unset(specPipeline, 'configRef');
      });
      _.set(listRecord, 'context.pipelines', specPipelines);
    } else {
      _.set(listRecord, 'context.pipelines', []);
    }
    _.set(listRecord, 'debugParam', debugParam);
    dispatch({
      type: 'editList/rChangeListRecord',
      payload: {
        listRecord: { ...listRecord },
      },
    });
    this.onCancel();
  }

  onCancel = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'editList/rClosePipelineDrawer',
    });
  }

  onAdd = () => {
    const { context, dispatch } = this.props;
    const panelPipelineActiveKey = randomStr(10);
    const { pipelines: specPipelines } = context;
    const curMaxIndex = _.get(_.maxBy(specPipelines, (specPipeline) => (specPipeline.index)), 'index', -1);
    const newPipeline = { name: panelPipelineActiveKey, type: '', data: {}, index: curMaxIndex + 1 };
    if (_.isEmpty(specPipelines)) {
      _.set(context, 'pipelines', [newPipeline]);
    } else {
      specPipelines.push(newPipeline);
    }
    dispatch({
      type: 'editList/rChangeContext',
      payload: {
        context: { ...context },
      },
    });
    dispatch({
      type: 'editList/rChangePanelPipelineActiveKey',
      payload: {
        panelPipelineActiveKey,
      },
    });
  }

  debugParamChange = (value) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'editList/rChangeDebugParam',
      payload: {
        debugParam: jsonBeautify(value),
      },
    });

    const debugParamCheck = isEmptyOrJSON(value) ? {
      validateStatus: 'success',
      errorMsg: null
    } : { validateStatus: 'error', errorMsg: '非JSON格式数据' };
    dispatch({
      type: 'editList/rChangeDebugParamCheck',
      payload: {
        debugParamCheck,
      },
    });
  }

  onDebug = () => {
    const { listRecord, context, debugParam, debugParamCheck: { validateStatus }, dispatch } = this.props;
    if (validateStatus !== 'success') {
      return;
    }
    this.onPanelChange('');
    const listRecordClone = _.cloneDeep(listRecord);
    const contextClone = _.cloneDeep(context);
    const { pipelines: specPipelines } = contextClone;
    if (!_.isEmpty(specPipelines)) {
      _.forEach(specPipelines, (specPipeline) => {
        _.unset(specPipeline, 'configRef');
      });
    }
    _.set(listRecordClone, 'context', JSON.stringify(contextClone));
    _.set(listRecordClone, 'queryDTO', _.isEmpty(debugParam) ? {} : JSON.parse(debugParam));

    dispatch({
      type: 'editList/ePipelineDebug',
      payload: {
        listRecord: { ...listRecordClone },
      },
    });
  }

  render() {
    const {
      context, debugParam, pipelineDrawerVisible,
      panelPipelineActiveKey, debugParamCheck, debugLog, loading
    } = this.props;
    const panels = [];
    const { pipelines: specPipelines } = context;
    if (!_.isEmpty(specPipelines)) {
      _.forEach(specPipelines, (specPipeline) => {
        const panel = (
          <Panel header={specPipeline.name} key={specPipeline.name} extra={this.genExtra(specPipeline.name)}>
            {/* eslint-disable-next-line no-return-assign,no-param-reassign */}
            <PipelineConfigForm onRef={(ref) => (specPipeline.configRef = ref)}
                                specPipeline={specPipeline}/>
          </Panel>);
        panels.push(panel);
      });
    }
    const formItemLayout = { labelCol: { offset: 0, span: 4 }, wrapperCol: { span: 16 } };
    return (
      <Drawer
        title="Pipeline配置"
        placement="right"
        width="70%"
        maskClosable={false}
        visible={pipelineDrawerVisible}
        onClose={this.onCancel}
      >
        <Spin spinning={loading}>
          <Button type="primary" onClick={this.onAdd}>添加</Button>
          <Collapse style={{ marginTop: 10 }}
                    accordion
                    onChange={this.onPanelChange}
                    activeKey={`${panelPipelineActiveKey}`}>
            {panels}
          </Collapse>
          <Divider/>

          {panels.length > 0 && (<div><Button type="primary" onClick={this.onDebug}>调试</Button>
            <Form {...formItemLayout}>
              <Row gutter={16}>
                <Col span={24}>
                  <Form.Item key="debugParam"
                             label="请求参数"
                             validateStatus={debugParamCheck.validateStatus}
                             help={debugParamCheck.errorMsg}>
                    <MonacoEditor
                      width="1000"
                      height="200"
                      language="json"
                      theme="vs-dark"
                      onChange={this.debugParamChange}
                      value={debugParam}
                    />
                  </Form.Item>
                  {!_.isEmpty(debugLog) && (<Form.Item key="debugOutput"
                                                       label="结果输出">
                    <MonacoEditor
                      width="1000"
                      height="350"
                      options={{ readOnly: true, folding: true }}
                      language="json"
                      theme="vs-dark"
                      value={JSON.stringify(debugLog, null, 2)}
                    />
                  </Form.Item>)}
                </Col>
              </Row>
            </Form></div>)}

          <Divider/>
          <div style={{ textAlign: 'right' }}>
            <Button key="ok" type="primary" style={{ marginRight: 10 }} onClick={this.onOk}>确定</Button>
            <Button key="cancel" type="primary" onClick={this.onCancel}>取消</Button>
          </div>
        </Spin>
      </Drawer>
    );
  }
}

export default PipelineDrawer;
