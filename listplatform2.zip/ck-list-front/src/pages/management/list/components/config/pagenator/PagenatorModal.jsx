import React, { Component } from 'react';
import { Button, Col, Form, InputNumber, Modal, Row } from 'antd';
import { connect } from 'dva';
import _ from 'lodash';

const mapStateToProps = ({ editList: { pagenatorModalVisible, context, listRecord }, loading }) => ({
  pagenatorModalVisible,
  context,
  listRecord,
  loading: loading.models.editList,
});

@connect(mapStateToProps)
@Form.create()
class PagenatorModal extends Component {
  modalOk = () => {
    const { listRecord, dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      _.set(listRecord, 'context.pagenator.pageSize', fieldsValue.pageSize);
      dispatch({
        type: 'editList/rChangeListRecord',
        payload: {
          listRecord: { ...listRecord },
        },
      });
      this.modalCancel();
    });
  }

  modalCancel = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'editList/rClosePagenatorModal',
    });
  }

  render() {
    const { pagenatorModalVisible, context, form } = this.props;
    const formItemLayout = { labelCol: { offset: 4, span: 8 }, wrapperCol: { span: 8 } };
    return (<Modal
      title="分页配置"
      visible={pagenatorModalVisible}
      destroyOnClose
      maskClosable={false}
      onCancel={this.modalCancel}
      footer={[
        <Button key="ok" type="primary" onClick={this.modalOk}>确定</Button>,
        <Button key="cancel" type="primary" onClick={this.modalCancel}>取消</Button>
      ]}>
      <Form {...formItemLayout}>
        <Row gutter={16}>
          <Col span={24}>
            <Form.Item key="pageSize" label="每页记录数">
              {form.getFieldDecorator('pageSize', {
                rules: [{ required: true, message: '请输入！' }, { pattern: /^\d+$/, message: '请输入！' }],
                initialValue: _.get(context, 'pagenator.pageSize', 10),
              })(<InputNumber min={1}/>)}
            </Form.Item>
          </Col>
        </Row></Form>
    </Modal>);
  }
}

export default PagenatorModal;
