import React, { Component } from 'react';
import { Button, Checkbox, Divider, Form, Input, InputNumber, Select, Table } from 'antd';
import _ from 'lodash';
import { connect } from 'dva';
import MonacoEditor from 'react-monaco-editor';

import { randomStr } from '@xyz/listtool';

const { Column, ColumnGroup } = Table;

class EditableCell extends Component {
  checkboxChange = (e, dataIndex) => {
    const { form } = this.props;
    switch (dataIndex) {
      case 'isSearch':
        form.setFieldsValue({
          isSearch: e.target.checked,
        });
        break;
      case 'isResult':
        form.setFieldsValue({
          isResult: e.target.checked,
        });
        break;
      default:
    }
  };

  getInput = () => {
    const { dataIndex, searchMatch, searchDataType, form } = this.props;
    switch (dataIndex) {
      case 'key':
      case 'label':
      case 'remark':
        return <Input/>;
      case 'search_eleType':
        return <Input disabled={!form.getFieldValue('isSearch')}/>;
      case 'isSearch':
      case 'isResult':
        return <Checkbox onChange={(e) => this.checkboxChange(e, dataIndex)}/>;
      case 'search_match':
        return (
          <Select mode="multiple" style={{ width: 120 }} disabled={!form.getFieldValue('isSearch')} placeholder="请选择">
            {_.map(searchMatch,
              (value, key) => (<Select.Option key={key} value={Number.parseInt(key, 10)}>{value}</Select.Option>)
            )}
          </Select>);
      case 'search_dataType':
        return (<Select style={{ width: 120 }} disabled={!form.getFieldValue('isSearch')} placeholder="请选择">
          {_.map(searchDataType,
            (value, key) => (<Select.Option key={key} value={Number.parseInt(key, 10)}>{value}</Select.Option>)
          )}
        </Select>);
      case 'search_index':
        return <InputNumber min={0} max={100} disabled={!form.getFieldValue('isSearch')}/>;
      case 'result_index':
        return <InputNumber min={0} max={100} disabled={!form.getFieldValue('isResult')}/>;
      case 'result_order':
        return (<Select style={{ width: 80 }} disabled={!form.getFieldValue('isResult')} placeholder="请选择">
          <Select.Option value={0}>不排序</Select.Option>
          <Select.Option value={1}>排序</Select.Option>
        </Select>);
      case 'result_export':
        return (<Select style={{ width: 80 }} disabled={!form.getFieldValue('isResult')} placeholder="请选择">
          <Select.Option value={0}>不导出</Select.Option>
          <Select.Option value={1}>导出</Select.Option>
        </Select>);
      default:
        return <Input/>;
    }
  }

  checkKeyDuplicate = (rule, value, callback) => {
    const { context, record } = this.props;
    const { fields: specFields } = context;
    const specFieldsClone = _.clone(specFields);
    _.remove(specFieldsClone, (specFieldClone) => (specFieldClone.key === record.key));
    if (!_.isEmpty(_.filter(specFieldsClone, specFieldClone => (specFieldClone.key === value)))) {
      callback('key重复, 请重新设置');
    }
    callback();
  }

  checkSearchIndexDuplicate = (rule, value, callback) => {
    const { context, record } = this.props;
    const { fields: specFields } = context;
    const specFieldsClone = _.clone(specFields);
    _.remove(specFieldsClone, (specFieldClone) => (specFieldClone.key === record.key));
    if (!_.isEmpty(_.filter(specFieldsClone,
      specFieldClone => (!_.isEmpty(specFieldClone.search) && specFieldClone.search.index === value)))) {
      callback('搜索域排序字段重复, 请重新设置');
    }
    callback();
  }

  checkResultIndexDuplicate = (rule, value, callback) => {
    const { context, record } = this.props;
    const { fields: specFields } = context;
    const specFieldsClone = _.clone(specFields);
    _.remove(specFieldsClone, (specFieldClone) => (specFieldClone.key === record.key));
    if (!_.isEmpty(_.filter(specFieldsClone,
      specFieldClone => (!_.isEmpty(specFieldClone.result) && specFieldClone.result.index === value)))) {
      callback('结果域排序字段重复, 请重新设置');
    }
    callback();
  }

  render() {
    const {
      editing,
      dataIndex,
      title,
      record,
      children,
      form,
      searchMatch,
      searchDataType
    } = this.props;
    const fieldDecoratorOption = {};
    let nonEditingDisplay = children;
    switch (dataIndex) {
      case 'key':
        _.extend(fieldDecoratorOption, {
          rules: [
            {
              required: true,
              message: `请输入${title}!`,
            },
            { pattern: /^\w+$/, message: '请输入字母数字组合！' },
            { validator: this.checkKeyDuplicate }
          ],
          initialValue: record[dataIndex],
        });
        break;
      case 'label':
        _.extend(fieldDecoratorOption, {
          rules: [
            {
              required: true,
              message: `请输入${title}!`,
            },
          ],
          initialValue: record[dataIndex],
        });
        break;
      case 'search_index':
        _.extend(fieldDecoratorOption, {
          rules: [
            {
              required: form.getFieldValue('isSearch') && true,
              message: `请输入${title}!`,
            },
            // 允许index重复
            // { validator: this.checkSearchIndexDuplicate }
          ],
          initialValue: record[dataIndex],
        });
        break;
      case 'result_index':
        _.extend(fieldDecoratorOption, {
          rules: [
            {
              required: form.getFieldValue('isResult') && true,
              message: `请输入${title}!`,
            },
            // 允许index可以重复
            // { validator: this.checkResultIndexDuplicate }
          ],
          initialValue: record[dataIndex],
        });
        break;
      case 'search_match': {
        const matchKeys = _.keys(record[dataIndex]);
        nonEditingDisplay = '';
        if (!_.isEmpty(matchKeys)) {
          _.forEach(matchKeys, (matchKey) => {
            nonEditingDisplay = `${nonEditingDisplay} ${searchMatch[matchKey]}`;
          })
        }
        _.extend(fieldDecoratorOption, {
          rules: [
            {
              required: form.getFieldValue('isSearch') && true,
              message: `请输入${title}!`,
            },
          ],
          initialValue: _.map(_.keys(record[dataIndex]), (key) => (Number.parseInt(key, 10))),
        });
        break;
      }
      case 'search_dataType':
        nonEditingDisplay = searchDataType[record[dataIndex]];
        _.extend(fieldDecoratorOption, {
          rules: [
            {
              required: form.getFieldValue('isSearch') && true,
              message: `请输入${title}!`,
            },
          ],
          initialValue: record[dataIndex],
        });
        break;
      case 'result_order':
        nonEditingDisplay = record[dataIndex] === 0 ? '不排序' : '排序';
        _.extend(fieldDecoratorOption, {
          rules: [
            {
              required: form.getFieldValue('isResult') && true,
              message: `请输入${title}!`,
            },
          ],
          initialValue: record[dataIndex],
        });
        break;
      case 'result_export':
        nonEditingDisplay = record[dataIndex] === 0 ? '不导出' : '导出';
        _.extend(fieldDecoratorOption, {
          rules: [
            {
              required: form.getFieldValue('isResult') && true,
              message: `请输入${title}!`,
            },
          ],
          initialValue: record[dataIndex],
        });
        break;
      case 'remark':
        _.extend(fieldDecoratorOption, {
          initialValue: record[dataIndex],
        });
        break;
      case 'isSearch':
      case 'isResult':
        nonEditingDisplay = record[dataIndex] ? '是' : '否';
        _.extend(fieldDecoratorOption, {
          valuePropName: 'checked',
          initialValue: record[dataIndex],
        });
        break;
      case 'search_eleType':
        _.extend(fieldDecoratorOption, {
          rules: [
            { pattern: /^\w+$/, message: '请输入字母数字组合！' },
          ],
          initialValue: record[dataIndex],
        });
        break;
      default:
    }
    return (
      <td style={{ textAlign: 'center' }}>
        {editing ? (
          <Form.Item key={dataIndex} style={{ margin: 0 }}>
            {form.getFieldDecorator(dataIndex, fieldDecoratorOption)(this.getInput())}
          </Form.Item>
        ) : (
          nonEditingDisplay
        )}
      </td>);
  }
}

const mapStateToProps = ({ editList: { context, fieldEditingKey, searchMatch, searchDataType }, loading }) => ({
  context,
  fieldEditingKey,
  searchMatch,
  searchDataType,
  loading: loading.models.editList,
});

@connect(mapStateToProps)
@Form.create()
class EditableTable extends Component {
  columns = [
    {
      title: 'key',
      dataIndex: 'key',
      width: 120,
      align: 'center',
      editable: true,
    },
    {
      title: '名称',
      dataIndex: 'label',
      width: 120,
      align: 'center',
      editable: true,
    },
    {
      title: '备注',
      dataIndex: 'remark',
      width: 120,
      align: 'center',
      editable: true,
    },
    {
      title: '是否检索字段',
      dataIndex: 'isSearch',
      width: 60,
      align: 'center',
      editable: true,
    },
    {
      title: '是否结果字段',
      dataIndex: 'isResult',
      width: 60,
      align: 'center',
      editable: true,
    },
    {
      title: '检索',
      children: [
        {
          title: '匹配类型',
          dataIndex: 'search_match',
          width: 100,
          align: 'center',
          editable: true,
        }, {
          title: '前端组件类型',
          dataIndex: 'search_eleType',
          width: 100,
          align: 'center',
          editable: true,
        }, {
          title: '数据类型',
          dataIndex: 'search_dataType',
          width: 100,
          align: 'center',
          editable: true,
        }, {
          title: '权重',
          dataIndex: 'search_index',
          width: 30,
          align: 'center',
          editable: true,
        }],
    }, {
      title: '结果',
      children: [
        {
          title: '排序',
          dataIndex: 'result_order',
          width: 100,
          align: 'center',
          editable: true,
        }, {
          title: '导出字段',
          dataIndex: 'result_export',
          width: 100,
          align: 'center',
          editable: true,
        }, {
          title: '权重',
          dataIndex: 'result_index',
          width: 30,
          align: 'center',
          editable: true,
        }],
    },
    {
      title: '操作',
      dataIndex: 'operation',
      width: 120,
      align: 'center',
      render: (text, record) => {
        const { fieldEditingKey } = this.props;
        const editable = this.isEditing(record);
        return editable ? (
          <span><a onClick={() => this.editSave(record.key)}>保存</a><Divider type="vertical"/>
            <a onClick={() => this.editCancel(record.key)}>取消</a>
          </span>
        ) : (
          <span>
          <a disabled={!_.isEmpty(fieldEditingKey)}
             onClick={() => this.editOk(record.key)}>编辑</a><Divider type="vertical"/>
             <a disabled={!_.isEmpty(fieldEditingKey)} onClick={() => this.onDelete(record.key)}>删除</a>
          </span>
        );
      },
    }
  ];

  isEditing = (record) => {
    const { fieldEditingKey } = this.props;
    return record.key === fieldEditingKey;
  }

  editCancel = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'editList/rChangeFieldEditingKey',
      payload: {
        fieldEditingKey: '',
      }
    });
  }

  editSave = (key) => {
    const { form, dispatch, searchMatch, context } = this.props;
    form.validateFields((error, fieldsValue) => {
      if (error) {
        return;
      }
      // 校验数据是否重复
      const { isSearch, isResult } = fieldsValue;
      const { fields: specFields } = context;

      const curField = _.filter(specFields, (specField) => (specField.key === key))[0];
      const curIndex = _.findIndex(specFields, (specField) => (specField.key === key));
      if (curIndex !== -1) {
        const newField = {
          key: fieldsValue.key,
          label: fieldsValue.label,
          remark: fieldsValue.remark,
          mapping: _.get(curField, 'mapping'),
        };
        if (isSearch) {
          const fieldMatch = {};
          _.forEach(fieldsValue.search_match, (oneMatch) => {
            fieldMatch[oneMatch] = searchMatch[oneMatch]
          });
          _.set(newField,
            'search.match', fieldMatch);
          _.set(newField, 'search.eleType', fieldsValue.search_eleType);
          _.set(newField, 'search.dataType', fieldsValue.search_dataType);
          _.set(newField, 'search.index', fieldsValue.search_index);
        }
        if (isResult) {
          _.set(newField, 'result.order', fieldsValue.result_order);
          _.set(newField, 'result.export', fieldsValue.result_export);
          _.set(newField, 'result.format', _.get(curField, 'result.format'));
          _.set(newField, 'result.index', fieldsValue.result_index);
        }
        specFields.splice(curIndex, 1, newField);
        dispatch({
          type: 'editList/rChangeContext',
          payload: {
            context: { ...context },
          },
        });
        dispatch({
          type: 'editList/rChangeFieldEditingKey',
          payload: {
            fieldEditingKey: '',
          },
        });
      }
    });
  }

  editOk = (key) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'editList/rChangeFieldEditingKey',
      payload: {
        fieldEditingKey: key,
      }
    });
  }

  columnsMap = (columns) => {
    const { form, context, searchMatch, searchDataType, dispatch } = this.props;
    return columns.map(col => {
      const { children } = col;
      if (!_.isEmpty(children)) {
        const newChildren = this.columnsMap(children);
        return { ...col, children: newChildren };
      }
      if (!col.editable) {
        return col;
      }
      return {
        ...col,
        onCell: (record) => {
          return ({
            record,
            context,
            dataIndex: col.dataIndex,
            title: col.title,
            editing: this.isEditing(record),
            form,
            searchMatch,
            searchDataType,
            dispatch
          });
        }
      };
    });
  }

  convertRecord2Data = (context) => {
    const data = [];
    const { fields: specFields } = context;
    if (!_.isEmpty(specFields)) {
      _.forEach(specFields, (specField) => {
        const oneData = {
          key: specField.key,
          label: specField.label,
          remark: specField.remark,
          mapping: specField.mapping
        };
        if (specField.search) {
          _.extend(oneData, {
            isSearch: true,
            search_match: _.get(specField, 'search.match'),
            search_eleType: _.get(specField, 'search.eleType'),
            search_dataType: _.get(specField, 'search.dataType'),
            search_index: _.get(specField, 'search.index')
          });
        } else {
          _.extend(oneData, { isSearch: false });
        }
        if (specField.result) {
          _.extend(oneData, {
            isResult: true,
            result_order: _.get(specField, 'result.order'),
            result_export: _.get(specField, 'result.export'),
            result_format: _.get(specField, 'result.format'),
            result_index: _.get(specField, 'result.index')
          });
        } else {
          _.extend(oneData, { isResult: false });
        }
        data.push(oneData);
      });
    }
    return data;
  }

  mappingOnChange = (key, value) => {
    const { context, dispatch } = this.props;
    const { fields: specFields } = context;
    const curField = _.filter(specFields, (specField) => (specField.key === key))[0];
    _.set(curField, 'mapping', value);
    dispatch({
      type: 'editList/rChangeContext',
      payload: {
        context: { ...context },
      },
    });
  }

  formatOnChange = (key, value) => {
    const { context, dispatch } = this.props;
    const { fields: specFields } = context;
    const curField = _.filter(specFields, (specField) => (specField.key === key))[0];
    _.set(curField, 'result.format', value);
    dispatch({
      type: 'editList/rChangeContext',
      payload: {
        context: { ...context },
      },
    });
  }

  expandedRowRender = (record) => {
    const { form } = this.props;
    if (!this.isEditing(record)) {
      return (<div><b>mapping:</b> {record.mapping}<br/><br/><b>format:</b> {record.result_format}</div>);
    }
    return (
      <div>
        <Form.Item key="mapping" label="字段映射">
          <MonacoEditor
            width="1000"
            height="100"
            language="sql"
            theme="vs-dark"
            onChange={(value) => (this.mappingOnChange(record.key, value))}
            value={record.mapping}
          />
        </Form.Item>
        <Form.Item key="result_format" label="字段转换">
          <MonacoEditor
            width="1000"
            height="100"
            language="sql"
            theme="vs-dark"
            onChange={(value) => (this.formatOnChange(record.key, value))}
            value={record.result_format}
          />
        </Form.Item>
      </div>
    );
  }

  onDelete = (key) => {
    const { context, dispatch } = this.props;
    const { fields: specFields } = context;
    const curIndex = _.findIndex(specFields, (specField) => (specField.key === key));
    if (curIndex !== -1) {
      specFields.splice(curIndex, 1);
      dispatch({
        type: 'editList/rChangeContext',
        payload: {
          context: { ...context },
        },
      });
      dispatch({
        type: 'editList/rChangeFieldEditingKey',
        payload: {
          fieldEditingKey: '',
        },
      });
    }
  }

  onAdd = () => {
    const { context, dispatch } = this.props;
    const { fields: specFields } = context;
    // 计算search.index和result.index
    const curMaxSearchIndex = _.get(_.maxBy(specFields, (specField) => (specField.search && specField.search.index)),
      'search.index', -1);
    const curMaxResultIndex = _.get(_.maxBy(specFields, (specField) => (specField.result && specField.result.index)),
      'result.index', -1);
    const newField = {
      key: randomStr(10),
      label: '',
      remark: '',
      mapping: '',
      search: {
        match: 0,
        eleType: 'input',
        dataType: 4,
        index: curMaxSearchIndex + 1,
      },
      result: {
        order: 0,
        export: 1,
        format: '',
        index: curMaxResultIndex + 1,
      }
    };
    if (_.isEmpty(specFields)) {
      _.set(context, 'fields', [newField]);
    } else {
      specFields.push(newField);
    }
    dispatch({
      type: 'editList/rChangeContext',
      payload: {
        context: { ...context },
      },
    });
  }

  render() {
    const { context } = this.props;
    const tableComponents = {
      body: {
        cell: EditableCell,
      },
    };

    const tableColumns = this.columnsMap(this.columns);
    return (
      <Table
        bordered
        pagination={false}
        components={tableComponents}
        columns={tableColumns}
        expandedRowRender={this.expandedRowRender}
        dataSource={this.convertRecord2Data(context)}
        title={() => (
          <Button type="primary" icon="plus" onClick={this.onAdd} style={{ marginBottom: 16 }}>添加字段</Button>)}
      />);
  }
}

export default EditableTable;
