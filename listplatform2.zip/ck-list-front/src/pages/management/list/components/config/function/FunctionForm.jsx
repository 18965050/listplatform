import React, { Component } from 'react';
import { Col, Form, Input, InputNumber, Row, Select } from 'antd';
import { connect } from 'dva';
import _ from 'lodash';

const mapStateToProps = ({ editList: { context }, loading }) => ({
  context,
  loading: loading.models.editList,
});

/**
 * 注意: 原先想去除父组件Panel的'保存'操作, 后来发现不太好实现. 也就是说:
 * 这里不能将Form做成受控组件 (https://3x.ant.design/components/form-cn/#components-form-demo-global-state)
 * 这是由于表单中的key还会反映到父组件(Panel)的title.
 * 1. 如果表单字段绑定 context prop, 由于表单是动态生成的, 会导致field onchange后字段失去焦点
 * 2. 同时, Collapse下面只能放Panel, 也不可以将Panel放入这个自定义组件中,放入collapsse下面
 */
@connect(mapStateToProps)
@Form.create()
class FunctionForm extends Component {
  componentDidMount() {
    this.props.onRef(this);
  }

  onSave = (key) => {
    const { form } = this.props;
    let formVal = {};
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      formVal = fieldsValue;
    });
    return formVal;
  }

  checkKeyDuplicate = (rule, value, callback) => {
    const { context, specFunc } = this.props;
    const { functions: specFuncs } = context;
    const specFuncsClone = _.clone(specFuncs);
    _.remove(specFuncsClone, (specFuncClone) => (specFuncClone.key === specFunc.key));
    if (!_.isEmpty(_.filter(specFuncsClone, specFuncClone => (specFuncClone.key === value)))) {
      callback('key重复, 请重新设置');
    }
    callback();
  }

  checkIndexDuplicate = (rule, value, callback) => {
    const { context, specFunc } = this.props;
    const { functions: specFuncs } = context;
    const specFuncsClone = _.clone(specFuncs);
    _.remove(specFuncsClone, (specFuncClone) => (specFuncClone.key === specFunc.key));
    if (!_.isEmpty(_.filter(specFuncsClone, specFuncClone => (specFuncClone.index === value)))) {
      callback('index重复, 请重新设置');
    }
    callback();
  }

  render() {
    const { form, specFunc } = this.props;
    const formItemLayout = { labelCol: { offset: 4, span: 4 }, wrapperCol: { span: 8 } };
    return (<Form {...formItemLayout}>
      <Row gutter={16}>
        <Col span={24}>
          <Form.Item key="key" label="Key">
            {form.getFieldDecorator('key', {
              rules: [{ required: true, message: '请输入Key' },
                { pattern: /^\w+$/, message: '请输入字母数字组合！' },
                { validator: this.checkKeyDuplicate }],
              initialValue: specFunc.key,
            })(<Input placeholder="请输入"/>)}
          </Form.Item>
          <Form.Item key="comType" label="组件类型">
            {form.getFieldDecorator('comType', {
              rules: [{ required: true, message: '请输入组件类型' }],
              initialValue: specFunc.comType,
            })(<Select placeholder="请选择">
              <Select.Option value="export">数据导出</Select.Option>
              <Select.Option value="custom">自定义</Select.Option>
            </Select>)}
          </Form.Item>
          <Form.Item key="index" label="权重">
            {form.getFieldDecorator('index', {
              rules: [{ required: true, message: '请输入权重' },
                { validator: this.checkIndexDuplicate }],
              initialValue: specFunc.index || 0,
            })(<InputNumber min={0} max={100}/>)}
          </Form.Item>
        </Col>
      </Row></Form>);
  }
}

export default FunctionForm;
