import React from 'react';
import { connect } from 'dva';
import { Descriptions, Drawer } from 'antd';
import MonacoEditor from 'react-monaco-editor';
import { jsonBeautify } from '@/utils/utils';

const mapStateToProps = ({ listList: { detailVisible, detailRecord, appIds } }) => ({
  visible: detailVisible,
  record: detailRecord,
  appIds,
});

function ListDetailDrawer({ dispatch, visible, record, appIds }) {
  const onClose = () => {
    dispatch({
      type: 'listList/detailClose',
    });
  };

  const authTypeRender = (text) => {
    if (text === 0) {
      return 'none';
    }
    if (text === 1) {
      return 'medusa';
    }
    if (text === 2) {
      return 'custom';
    }
    return 'Unknown';
  };


  return (
    <Drawer
      title="列表详情"
      placement="right"
      visible={visible}
      onClose={onClose}
      width="70%"
    >
      <Descriptions title="基本信息" column={1} bordered>
        <Descriptions.Item label="列表ID">{record.listId}</Descriptions.Item>
        <Descriptions.Item label="应用ID">{appIds[record.appId]}</Descriptions.Item>
        <Descriptions.Item label="列表名称">{record.listName}</Descriptions.Item>
        <Descriptions.Item label="列表描述">{record.listDesc}</Descriptions.Item>
        <Descriptions.Item label="认证类型">
          {authTypeRender(record.authType)}
        </Descriptions.Item>
        <Descriptions.Item label="认证表达式">{record.authExpr}</Descriptions.Item>
        <Descriptions.Item label="状态">
          {record.status === 0 ? '停用' : '启用'}
        </Descriptions.Item>
        <Descriptions.Item label="调试参数">
          <MonacoEditor
            width="1000"
            height="200"
            language="java"
            theme="vs-dark"
            options={{ readOnly: true }}
            value={record.debugParam}
          />
        </Descriptions.Item>
        <Descriptions.Item label="配置上下文">
          <MonacoEditor
            width="1000"
            height="800"
            language="json"
            theme="vs-dark"
            options={{ readOnly: true }}
            value={jsonBeautify(record.context)}
          />
        </Descriptions.Item>
      </Descriptions>
    </Drawer>
  );
}

export default connect(mapStateToProps)(ListDetailDrawer);
