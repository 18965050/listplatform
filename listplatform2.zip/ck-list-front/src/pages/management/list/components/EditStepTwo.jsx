import React, { Component } from 'react';
import { Button, Col, Divider, Form, Row } from 'antd';
// import { ListToolPageHOC } from '@xyz/listtool';
import ListToolPageHOC from '@xyz/listtool/src/components/ListToolPageHOC';
import { randomStr } from '@xyz/listtool/src/utils';
import { connect } from 'dva';
import _ from 'lodash';
import { isJSON } from '@/utils/utils';

import PagenatorModal from './config/pagenator/PagenatorModal';
import FunctionModal from './config/function/FunctionModal'
import FieldModal from './config/field/FieldModal';
import PipelineDrawer from './config/pipeline/PipelineDrawer';

const listToolContext = {
  request: {
    debug: true,
    debugUrl: '/api/management/list/debug',
  },
  props: {
    tableRowkey: (record) => (randomStr(20)),
  }
};

const ListToolPage = ListToolPageHOC(listToolContext);

const mapStateToProps = ({ editList: { listRecord }, loading }) => ({
  listRecord,
  loading: loading.models.editList,
});

@connect(mapStateToProps)
@Form.create()
class EditStepTwo extends Component {
  openConf = (modelMethod) => {
    const { dispatch, listRecord } = this.props;
    const listRecordClone = _.cloneDeep(listRecord);
    const { context } = listRecordClone;
    dispatch({
      type: `editList/${modelMethod}`,
      payload: {
        context,
      },
    });
  }

  render() {
    const { listRecord } = this.props;
    // listRecord调整
    const listRecordClone = _.cloneDeep(listRecord);
    if (!_.isEmpty(listRecordClone.debugParam) && isJSON(listRecordClone.debugParam)) {
      _.set(listRecordClone, 'queryDTO', JSON.parse(listRecordClone.debugParam));
    }
    // 确保每页记录数修改生效
    const pagSize = _.get(listRecordClone, 'context.pagenator.pageSize');
    if (!_.isUndefined(pagSize)) {
      _.set(listRecordClone, 'queryDTO.pagenator.pageSize', pagSize);
    }
    _.set(listRecordClone, 'context', JSON.stringify(listRecordClone.context));
    return <div>
      <Row gutter={[16, 16]} style={{ textAlign: 'center' }}>
        <Col className="gutter-row" span={6}>
          <Button type="primary" icon="appstore" onClick={() => this.openConf('rOpenPagenatorModal')}>分页配置</Button>
        </Col>
        <Col className="gutter-row" span={6}>
          <Button type="primary" icon="gift" onClick={() => this.openConf('rOpenFunctionModal')}>功能域配置</Button>
        </Col>
        <Col className="gutter-row" span={6}>
          <Button type="primary" icon="table" onClick={() => this.openConf('rOpenFieldModal')}>字段配置</Button>
        </Col>
        <Col className="gutter-row" span={6}>
          <Button type="primary" icon="build" onClick={() => this.openConf('rOpenPipelineDrawer')}>Pipeline配置</Button>
        </Col>
      </Row>
      <PagenatorModal/>
      <FunctionModal/>
      <FieldModal/>
      <PipelineDrawer/>
      <Divider/>
      <ListToolPage {...{ request: { listRecord: listRecordClone } }} />
    </div>;
  }
}

export default EditStepTwo;
