import React, { Component } from 'react';
import withRouter from 'umi/withRouter';
import { connect } from 'dva';
import { Button, Divider, Upload } from 'antd';
import router from 'umi/router';
// import { ListToolPageHOC } from '@xyz/listtool';
import ListToolPageHOC from '@xyz/listtool/src/components/ListToolPageHOC';
import { exportCallback, timeFmt } from '@/utils/utils';
import ListDetailDrawer from './ListDetailDrawer';


const mapStateToProps = ({ listList, loading }) => ({
  ...listList,
  loading: loading.models.listList,
});

const context = {
  request: {
    reqUrl: '/api/listtool/3',
    searchQuery: {
      order: {
        modifyTime: 1,
      },
    },
  }
};

const ListToolPage = ListToolPageHOC(context);

@withRouter
@connect(mapStateToProps)
class ListListPage extends Component {
  checkListId = (rule, searchField, callback) => {
    if (searchField.value && !searchField.value.match(/^\d{1,9}$/)) {
      return callback('只能输入1~9位数字');
    }
    return callback();
  }

  checkListName = (rule, searchField, callback) => {
    if (searchField.value && !searchField.value.match(/^\S{1,100}$/)) {
      return callback('只能输入1~100位非空字符');
    }
    return callback();
  }

  getCustomProps = () => {
    const { refreshCounter } = this.props;
    return {
      request: { refreshCounter },
      props: {
        tableRowkey: 'listId',
        customTableColumns: [
          {
            title: '操作',
            align: 'center',
            dataIndex: '__OPER__',
            render: (text, record, index) => {
              const statusDom = (record.status.value === 0 ? <a onClick={() => this.handleStatus(record)}>启用</a> :
                <a onClick={() => this.handleStatus(record)}>停用</a>);

              return (<span>
          {statusDom}
                <Divider type="vertical"/>
          <a onClick={() => this.handleEdit(record.listId.value)}>修改</a>
        <Divider type="vertical"/>
          <a onClick={() => this.handleDetail(record.listId.value)}>详情</a>
        </span>);
            },
          },
          {
            dataIndex: 'createTime',
            render: timeFmt,
          },
          {
            dataIndex: 'modifyTime',
            render: timeFmt,
          },
        ],
        pageProps: {
          pageSizeOptions: ['10', '20', '30'],
        },
        tableProps: {
          rowSelection: this.rowSelectionHandler(),
        },
        customFunctions: [
          {
            key: 'add',
            comType: 'custom',
            eleRender: (renderContext) => {
              const { loading } = this.props;
              const { loading: contextLoading } = renderContext;
              return (<Button key="add"
                              icon="plus"
                              type="primary"
                              style={{ marginRight: 10 }}
                              disabled={loading || contextLoading}
                              onClick={this.handleCreate}>
                新建
              </Button>);
            },
          },
          {
            key: 'exportData',
            comType: 'custom',
            eleRender: (renderContext) => {
              const { loading, selectedRowKeys } = this.props;
              const { loading: contextLoading } = renderContext;
              const hasSelected = selectedRowKeys.length > 0;
              return (<Button icon="export"
                              key="exportData"
                              type="primary"
                              style={{ marginRight: 10 }}
                              disabled={!hasSelected || loading || contextLoading}
                              onClick={() => this.exportSelectionRows(selectedRowKeys)}>
                导出
              </Button>);
            },
          },
          {
            key: 'importData',
            comType: 'custom',
            eleRender: (renderContext) => {
              const { loading } = this.props;
              const { loading: contextLoading } = renderContext;
              return (<Upload key="importData" accept=".txt" fileList={[]} action={this.importHandler}>
                <Button icon="import" type="primary" disabled={loading || contextLoading}>导入</Button>
              </Upload>);
            },
          },
        ],
        customSearchFields: [
          {
            id: 'listId',
            fieldDecorator: {
              options: {
                rules: [{ validator: this.checkListId }],
              },
            },
          },
          {
            id: 'listName',
            fieldDecorator: {
              options: {
                rules: [{ validator: this.checkListName }],
              },
            },
          },
        ]
      }
    };
  };


  rowSelectionHandler = () => {
    const { selectedRowKeys } = this.props;
    return {
      selectedRowKeys,
      onChange: this.rowSelectChange,
    };
  };

  rowSelectChange = (selectedRowKeys) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'listList/rowSelectChange',
      payload: {
        selectedRowKeys
      },
    });
  };

  exportSelectionRows = (selectedRowKeys) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'listList/export',
      payload: {
        listIds: selectedRowKeys,
      },
      callback: ({ data }) => (exportCallback({ filename: 'listtool_list_info.txt', data })),
    });
  };

  importHandler = (file) => {
    const { dispatch, refreshCounter } = this.props;
    dispatch({
      type: 'listList/importData',
      payload: {
        file,
        refreshCounter,
      },
    });
  };

  handleDetail = (listId) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'listList/initDetail',
      payload: {
        listId,
      },
    });
  };

  handleEdit = (listId) => {
    router.push(`/management/list/update?listId=${listId}`);
  };

  handleCreate = () => {
    router.push('/management/list/add');
  };

  handleStatus = (record) => {
    const { dispatch, refreshCounter } = this.props;
    dispatch({
      type: 'listList/changeStatus',
      payload: {
        record,
        refreshCounter,
      },
    });
  };

  render() {
    return (
      <div>
        <ListDetailDrawer/>
        <ListToolPage {...this.getCustomProps()}/>
      </div>
    );
  }
}

export default ListListPage;
