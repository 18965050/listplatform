import React, { Component } from 'react';
import { Button, Divider, Steps } from 'antd';
import withRouter from 'umi/withRouter';
import router from 'umi/router';
import { connect } from 'dva';
import _ from 'lodash';

import EditStepOne from './EditStepOne';
import EditStepTwo from './EditStepTwo';

const { Step } = Steps;


const mapStateToProps = ({ editList: { editType, editStep, listRecord, debugParam }, loading }) => ({
  editType,
  editStep,
  listRecord,
  debugParam,
  loading: loading.models.editList,
});

@withRouter
@connect(mapStateToProps)
class ListEditPage extends Component {
  steps = [
    {
      key: 'basicConfig',
      title: '基本配置',
      // eslint-disable-next-line no-return-assign
      content: <EditStepOne onRef={(ref) => (this.stepOneRef = ref)}/>,
    },
    {
      key: 'specConfig',
      title: 'Spec配置',
      content: <EditStepTwo/>,
    },
  ];

  returnList = () => {
    const { dispatch } = this.props;
    // 先修改editStep,防止警告
    dispatch({
      type: 'editList/rInitPage',
      payload: {},
    });
    router.push('/management/list/list');
  };

  nextPage = () => {
    const { dispatch, editStep, listRecord } = this.props;
    if (editStep === 0) {
      const stepOneRecord = this.stepOneRef.onSave();
      if (!_.isEmpty(stepOneRecord)) {
        dispatch({
          type: 'editList/rChangePageStep',
          payload: {
            editStep: (editStep < this.steps.length - 1) ? editStep + 1 : this.steps.length - 1,
            listRecord: { ...listRecord, ...stepOneRecord },
          },
        });
      }
    }
  };

  prevPage = () => {
    const { dispatch, editStep, listRecord } = this.props;
    dispatch({
      type: 'editList/rChangePageStep',
      payload: {
        editStep: (editStep > 0) ? editStep - 1 : 0,
        listRecord,
      },
    });
  };

  onSave = () => {
    const { listRecord, editType, editStep, dispatch } = this.props;
    let canSave = true;
    const newListRecord = { ...listRecord };
    if (editStep === 0) {
      const stepOneRecord = this.stepOneRef.onSave();
      if (_.isEmpty(stepOneRecord)) {
        canSave = false;
      } else {
        _.extend(newListRecord, stepOneRecord);
      }
    }
    const context = _.isEmpty(listRecord.context) ? '' : JSON.stringify(listRecord.context);
    _.set(newListRecord, 'context', context);
    if (canSave) {
      // 先修改editStep,防止警告
      dispatch({
        type: 'editList/rInitPage',
        payload: {},
      });
      dispatch({
        type: 'editList/eSave',
        payload: {
          editType,
          listRecord: newListRecord,
        },
      });
    }
  };

  render() {
    const { editStep } = this.props;
    return (
      <div>
        <Steps current={editStep}>
          {this.steps.map(item => (
            <Step key={item.key} title={item.title}/>
          ))}
        </Steps>
        <div className="steps-content">{this.steps[editStep].content}</div>
        <Divider/>
        <div className="steps-action">
          {editStep < this.steps.length - 1 && (
            <Button type="primary" onClick={this.nextPage}>
              下一页
            </Button>
          )}
          {editStep > 0 && (
            <Button type="primary" style={{ marginLeft: 12 }} onClick={this.prevPage}>
              上一页
            </Button>
          )}
          <Button type="primary" style={{ marginLeft: 12 }} onClick={this.onSave}>
            保存
          </Button>
          <Button type="primary" style={{ marginLeft: 12 }} onClick={this.returnList}>
            返回列表
          </Button>

        </div>
      </div>
    );
  }
}

export default ListEditPage;
