import React, { Component } from 'react';
import { Col, Form, Input, Row, Select } from 'antd';
import _ from 'lodash';
import { connect } from 'dva';

const mapStateToProps = ({ editList: { editType, listRecord, appIds }, loading }) => ({
  editType,
  listRecord,
  appIds,
  loading: loading.models.editList,
});

@connect(mapStateToProps)
@Form.create()
class EditStepOne extends Component {
  componentDidMount() {
    this.props.onRef(this);
  }

  authTypeOnChange = (newVal) => {
    const { dispatch, listRecord } = this.props;
    dispatch({
      type: 'editList/rChangeListRecord',
      payload: {
        listRecord: { ...listRecord, authType: newVal },
      },
    });
  };

  onSave = () => {
    const { form } = this.props;
    const stepOneRecord = {};
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      _.extend(stepOneRecord, fieldsValue)
    });
    return stepOneRecord;
  };

  render() {
    const { editType, listRecord, appIds, form } = this.props;
    const formItemLayout = { style: { marginTop: 20 }, labelCol: { offset: 4, span: 4 }, wrapperCol: { span: 8 } };
    return <Form {...formItemLayout}>
      <Row gutter={16}>
        <Col span={24}>
          <Form.Item key="listId" label="列表ID">
            {form.getFieldDecorator('listId', {
              rules: [{ required: true, message: '请输入ID' }, { pattern: /^\d+$/, message: '请输入数字！' }],
              initialValue: listRecord.listId,
            })(<Input placeholder="请输入" disabled={editType === 'update'}/>)}
          </Form.Item>
          <Form.Item key="listName" label="列表名称">
            {form.getFieldDecorator('listName', {
              rules: [{ required: true, message: '请输入名称' }],
              initialValue: listRecord.listName,
            })(<Input placeholder="请输入"/>)}
          </Form.Item>
          <Form.Item key="listDesc" label="列表描述">
            {form.getFieldDecorator('listDesc', {
              initialValue: listRecord.listDesc,
            })(<Input.TextArea autoSize={{ minRows: 2, maxRows: 3 }} allowClear placeholder="请输入"/>)}
          </Form.Item>
          <Form.Item key="authType" label="认证类型">
            {form.getFieldDecorator('authType', {
              rules: [{ required: true, message: '请输入类型' }],
              initialValue: listRecord.authType,
            })(<Select onChange={this.authTypeOnChange}>
              <Select.Option value={0}>none</Select.Option>
              <Select.Option value={1}>medusa</Select.Option>
              <Select.Option value={2}>custom</Select.Option>
            </Select>)}
          </Form.Item>
          <Form.Item
            key="appId"
            label="应用ID">
            {form.getFieldDecorator('appId', {
              rules: [{ required: true, message: '请输入应用ID' }],
              initialValue: _.isUndefined(listRecord.appId) ? undefined : listRecord.appId,
            })(<Select placeholder="请选择">
              {_.map(appIds,
                (value, key) => (
                  <Select.Option key={key} value={Number.parseInt(key, 10)}>{value}</Select.Option>))}
            </Select>)}
          </Form.Item>

          {listRecord.authType === 1 ?
            <Form.Item
              key="authExpr"
              label="认证表达式(medusa认证使用)">
              {form.getFieldDecorator('authExpr', {
                initialValue: listRecord.authExpr,
              })(<Input placeholder="请输入"/>)}
            </Form.Item> : null}

          <Form.Item key="status" label="状态">
            {form.getFieldDecorator('status', {
              rules: [{ required: true, message: '请输入状态' }],
              initialValue: _.isUndefined(listRecord.status) ? undefined : listRecord.status,
            })(<Select placeholder="请选择">
              <Select.Option value={0}>停用</Select.Option>
              <Select.Option value={1}>启用</Select.Option>
            </Select>)}
          </Form.Item>
        </Col>
      </Row>
    </Form>
  }
}

export default EditStepOne;
