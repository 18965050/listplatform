import router from 'umi/router';
import _ from 'lodash';
import * as service from '../service';
import { isEmptyOrJSON } from '@/utils/utils';


// noinspection JSUnusedGlobalSymbols
export default {
  namespace: 'editList',
  state: {
    editStep: 0,
    appIds: {},
    datasources: {},
    searchDataType: {},
    searchMatch: {},
    pipelineType: {},
    editType: 'create',
    context: {}, // 用于spec配置
    listRecord: {}, // 后端返回的列表配置信息, context会从json str转换为obj
    pagenatorModalVisible: false,
    functionModalVisible: false,
    fieldModalVisible: false,
    pipelineDrawerVisible: false,
    panelFuncActiveKey: '',
    panelPipelineActiveKey: '',
    fieldEditingKey: '', // field modal中表格正在编辑的行key
    debugParam: '', // 用于调试参数配置
    debugLog: {},
    debugParamCheck: {}, // debugParam 参数校验
  },
  reducers: {
    rInitPage(state, { payload }) {
      return { ...state, ...payload, editStep: 0 };
    },

    rChangePageStep(state, { payload: { editStep, listRecord } }) {
      return { ...state, editStep, listRecord };
    },

    rOpenPagenatorModal(state, { payload: { context } }) {
      return { ...state, context, pagenatorModalVisible: true };
    },

    rClosePagenatorModal(state) {
      return { ...state, context: {}, pagenatorModalVisible: false };
    },

    rOpenFunctionModal(state, { payload: { context } }) {
      return { ...state, context, functionModalVisible: true };
    },

    rCloseFunctionModal(state) {
      return { ...state, context: {}, functionModalVisible: false };
    },

    rOpenFieldModal(state, { payload: { context } }) {
      return { ...state, context, fieldModalVisible: true };
    },

    rCloseFieldModal(state) {
      return { ...state, context: {}, fieldModalVisible: false };
    },

    rOpenPipelineDrawer(state, { payload: { context } }) {
      const { listRecord } = state;
      const debugParam = _.isEmpty(listRecord.debugParam) ? '' : listRecord.debugParam;
      const debugParamCheck = isEmptyOrJSON(debugParam) ? {
        validateStatus: 'success',
        errorMsg: null
      } : { validateStatus: 'error', errorMsg: '非JSON格式数据' };
      return { ...state, context, debugParam, debugParamCheck, pipelineDrawerVisible: true };
    },

    rClosePipelineDrawer(state) {
      return {
        ...state,
        context: {},
        debugParam: '',
        debugParamCheck: {},
        debugLog: {},
        pipelineDrawerVisible: false
      };
    },

    rChangeContext(state, { payload: { context } }) {
      return { ...state, context };
    },

    rChangeListRecord(state, { payload: { listRecord } }) {
      return { ...state, listRecord };
    },

    rChangePanelFuncActiveKey(state, { payload: { panelFuncActiveKey } }) {
      return { ...state, panelFuncActiveKey };
    },

    rChangeFieldEditingKey(state, { payload: { fieldEditingKey } }) {
      return { ...state, fieldEditingKey };
    },

    rChangePanelPipelineActiveKey(state, { payload: { panelPipelineActiveKey } }) {
      return { ...state, panelPipelineActiveKey };
    },

    rChangeDebugParam(state, { payload: { debugParam } }) {
      return { ...state, debugParam };
    },

    rChangeDebugParamCheck(state, { payload: { debugParamCheck } }) {
      return { ...state, debugParamCheck };
    },

    rChangeDebugLog(state, { payload: { debugLog } }) {
      return { ...state, debugLog };
    },
  },
  effects: {
    * eInitCreate(__, { call, put, select }) {
      const appIdsData = yield call(service.getAppIds);
      const dsData = yield call(service.getDatasources);
      const searchDataTypeData = yield call(service.getSearchDataType);
      const searchMatchData = yield call(service.getSearchMatch);
      const pipelineTypeData = yield call(service.getPipelineType);
      yield put({
        type: 'rInitPage',
        payload: {
          editType: 'create',
          appIds: appIdsData.data,
          datasources: dsData.data,
          searchMatch: searchMatchData.data,
          searchDataType: searchDataTypeData.data,
          pipelineType: pipelineTypeData.data,
          listRecord: { context: { pagenator: { pageSize: 10 } } },
        },
      });
    },

    * eInitUpdate({ payload: { listId } }, { call, put, select }) {
      const recordData = yield call(service.detail, listId);
      const appIdsData = yield call(service.getAppIds);
      const dsData = yield call(service.getDatasources);
      const searchDataTypeData = yield call(service.getSearchDataType);
      const searchMatchData = yield call(service.getSearchMatch);
      const pipelineTypeData = yield call(service.getPipelineType);
      const listRecord = recordData.data;
      // 不存在直接跳转到创建页面
      if (_.isEmpty(listRecord)) {
        router.push('/management/list/add');
      } else {
        const context = { pagenator: { pageSize: 10 } };
        _.extend(context, _.isEmpty(listRecord.context) ? {} : JSON.parse(listRecord.context));
        _.set(listRecord, 'context', context);
        yield put({
          type: 'rInitPage',
          payload: {
            editType: 'update',
            appIds: appIdsData.data,
            datasources: dsData.data,
            searchMatch: searchMatchData.data,
            searchDataType: searchDataTypeData.data,
            pipelineType: pipelineTypeData.data,
            listRecord,
          },
        });
      }
    },

    * eSave({ payload: { editType, listRecord } }, { call, put, select }) {
      const serviceMethod = editType === 'update' ? service.update : service.add;
      const retData = yield call(serviceMethod, listRecord);
      if (retData.ret === 0) {
        router.push('/management/list/list');
      }
    },

    * ePipelineDebug({ payload: { listRecord } }, { call, put, select }) {
      const logData = yield call(service.pipelineDebug, listRecord);
      yield put({
        type: 'rChangeDebugLog',
        payload: {
          debugLog: logData.data,
        },
      });
    },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        if (pathname === '/management/list/add') {
          dispatch({ type: 'eInitCreate' });
        } else if (pathname === '/management/list/update') {
          dispatch({ type: 'eInitUpdate', payload: { listId: query.listId } });
        }
      });
    },
  },
};
