import * as service from '../service';

// noinspection JSUnusedGlobalSymbols
export default {
  namespace: 'listList',
  state: {
    refreshCounter: 0,
    detailVisible: false,
    detailRecord: {},
    authType: 0,
    appIds: {},
    selectedRowKeys: [], // 选中的行
  },
  reducers: {
    detailClose(state) {
      return { ...state, detailRecord: {}, detailVisible: false };
    },
    showDetail(state, { payload: { record, appIds } }) {
      return { ...state, detailRecord: record, appIds, detailVisible: true };
    },
    authTypeChange(state, { payload: { authType } }) {
      return { ...state, authType };
    },
    rowSelectChange(state, { payload: { selectedRowKeys } }) {
      return { ...state, selectedRowKeys };
    },
    saveAppIds(state, { payload: { appIds } }) {
      return { ...state, appIds };
    },
    listFetch(state, { payload: { refreshCounter } }) {
      return {
        ...state,
        refreshCounter,
      };
    },
  },
  effects: {
    * queryAppIds(_, { call, put, select }) {
      const appIdsData = yield call(service.getAppIds);
      yield put({
        type: 'saveAppIds',
        payload: {
          appIds: appIdsData.data,
        },
      });
    },

    * initDetail({ payload: { listId } }, { call, put, select }) {
      const detailData = yield call(service.detail, listId);
      const appIdsData = yield call(service.getAppIds);
      yield put({
        type: 'showDetail',
        payload: {
          record: detailData.data,
          appIds: appIdsData.data,
        },
      });
    },

    * changeStatus({ payload: { record, refreshCounter } }, { call, put, select }) {
      const status = (record.status.value === 0 ? 1 : 0);
      const postData = { listId: record.listId.value, status };
      yield call(service.changeStatus, postData);
      yield put({
        type: 'listFetch',
        payload: { refreshCounter: refreshCounter + 1 },
      });
    },

    * importData({ payload: { file, refreshCounter } }, { call, put, select }) {
      const data = new FormData();
      data.append('file', file);
      yield call(service.importData, data);
      yield put({
        type: 'listFetch',
        payload: { refreshCounter: refreshCounter + 1 },
      });
    },

    * export({ payload: { listIds }, callback }, { call, put, select }) {
      yield call(service.exportData, { listIds }, callback);
    },
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        if (pathname === '/management/list/list') {
          dispatch({ type: 'queryAppIds' });
        }
      });
    },
  },
};
