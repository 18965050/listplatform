import React from 'react';
import { connect } from 'dva';
import { Descriptions, Drawer } from 'antd';

const mapStateToProps = ({ app: { detailVisible, detailRecord } }) => ({
  visible: detailVisible,
  record: detailRecord,
});

function AppDetailDrawer({ dispatch, visible, record }) {
  const onClose = () => {
    dispatch({
      type: 'app/detailClose',
    });
  };

  return (
    <Drawer
      title="应用详情"
      placement="right"
      visible={visible}
      onClose={onClose}
      width={1024}
    >
      <Descriptions title="基本信息" column={1} bordered>
        <Descriptions.Item label="应用ID">{record.appId}</Descriptions.Item>
        <Descriptions.Item label="应用名称">{record.appName}</Descriptions.Item>
        <Descriptions.Item label="应用key">
          {record.appKey}
        </Descriptions.Item>
        <Descriptions.Item label="应用密钥">
          {record.appSecret}
        </Descriptions.Item>
        <Descriptions.Item label="状态">
          {record.status === 0 ? '停用' : '启用'}
        </Descriptions.Item>
      </Descriptions>
    </Drawer>
  );
}

export default connect(mapStateToProps)(AppDetailDrawer);
