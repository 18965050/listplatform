import React, { Component } from 'react';
import withRouter from 'umi/withRouter';
import { connect } from 'dva';
import { Button, Divider, Input, Upload } from 'antd';
// import { ListToolPageHOC } from '@xyz/listtool';
import ListToolPageHOC from '@xyz/listtool/src/components/ListToolPageHOC';
import { exportCallback, timeFmt } from '@/utils/utils';
import AppEditDrawer from './AppEditDrawer';
import AppDetailDrawer from './AppDetailDrawer';


const mapStateToProps = ({ app, loading }) => ({
  ...app,
  loading: loading.models.app,
});

const context = {
  request: {
    reqUrl: '/api/listtool/2',
    searchQuery: {
      order: {
        modifyTime: 1,
      },
    },
  }
};

const ListToolPage = ListToolPageHOC(context);

@withRouter
@connect(mapStateToProps)
class AppListPage extends Component {
  checkAppName = (rule, searchField, callback) => {
    if (searchField.value && !searchField.value.match(/^\S{1,100}$/)) {
      return callback('只能输入1~100位非空字符');
    }
    return callback();
  }

  getCustomProps = () => {
    const { refreshCounter } = this.props;
    return {
      request: { refreshCounter },
      props: {
        tableRowkey: 'appId',
        customTableColumns: [
          {
            title: '操作',
            align: 'center',
            dataIndex: '__OPER__',
            render: (text, record, index) => {
              const statusDom = (record.status.value === 0 ? <a onClick={() => this.handleStatus(record)}>启用</a> :
                <a onClick={() => this.handleStatus(record)}>停用</a>);

              return (<span>
          {statusDom}
                <Divider type="vertical"/>
          <a onClick={() => this.handleEdit(record.appId.value)}>修改</a>
        <Divider type="vertical"/>
          <a onClick={() => this.handleDetail(record.appId.value)}>详情</a>
        </span>);
            },
          },
          {
            dataIndex: 'createTime',
            render: timeFmt,
          },
          {
            dataIndex: 'modifyTime',
            render: timeFmt,
          },
        ],
        pageProps: {
          pageSizeOptions: ['10', '20', '30'],
        },
        tableProps: {
          rowSelection: this.rowSelectionHandler(),
        },
        customFunctions: [
          {
            key: 'add',
            comType: 'custom',
            eleRender: (renderContext) => {
              const { loading } = this.props;
              const { loading: contextLoading } = renderContext;
              return (<Button key="add"
                              icon="plus"
                              type="primary"
                              style={{ marginRight: 10 }}
                              disabled={loading || contextLoading}
                              onClick={this.handleCreate}>
                新建
              </Button>);
            },
          },
          {
            key: 'exportData',
            comType: 'custom',
            eleRender: (renderContext) => {
              const { selectedRowKeys, loading } = this.props;
              const { loading: contextLoading } = renderContext;
              const hasSelected = selectedRowKeys.length > 0;
              return (<Button icon="export"
                              key="exportData"
                              type="primary"
                              style={{ marginRight: 10 }}
                              disabled={!hasSelected || loading || contextLoading}
                              onClick={() => this.exportSelectionRows(selectedRowKeys)}>
                导出
              </Button>);
            },
          },
          {
            key: 'importData',
            comType: 'custom',
            eleRender: (renderContext) => {
              const { loading } = this.props;
              const { loading: contextLoading } = renderContext;
              return (<Upload key="importData" accept=".txt" fileList={[]} action={this.importHandler}>
                <Button icon="import" type="primary" disabled={loading || contextLoading}>导入</Button>
              </Upload>);
            },
          },
        ],
        customSearchFields: [
          {
            id: 'appId',
            eleRender: (searchField) => {
              return <Input placeholder={searchField.placeHolder}/>;
            },
            fieldDecorator: {
              options: {
                rules: [{ pattern: /^\d{1,9}$/, message: '只能输入1~9位数字' }],
              },
            },
          },
          {
            id: 'appName',
            fieldDecorator: {
              options: {
                rules: [{ validator: this.checkAppName }],
              },
            },
          },
        ],
      }
    };
  };


  rowSelectionHandler = () => {
    const { selectedRowKeys } = this.props;
    return {
      selectedRowKeys,
      onChange: this.rowSelectChange,
    };
  };

  rowSelectChange = (selectedRowKeys) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'app/rowSelectChange',
      payload: {
        selectedRowKeys
      },
    });
  };

  exportSelectionRows = (selectedRowKeys) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'app/export',
      payload: {
        appIds: selectedRowKeys,
      },
      callback: ({ data }) => (exportCallback({ filename: 'listtool_app_info.txt', data })),
    });
  };

  importHandler = (file) => {
    const { dispatch, refreshCounter } = this.props;
    dispatch({
      type: 'app/importData',
      payload: {
        file,
        refreshCounter,
      },
    });
  };

  handleDetail = (appId) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'app/initDetail',
      payload: {
        appId,
      },
    });
  };

  handleEdit = (appId) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'app/initEdit',
      payload: {
        appId,
      },
    });
  };

  handleCreate = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'app/createModal',
    });
  };

  handleStatus = (record) => {
    const { dispatch, refreshCounter } = this.props;
    dispatch({
      type: 'app/changeStatus',
      payload: {
        record,
        refreshCounter,
      },
    });
  };

  render() {
    return (
      <div>
        <AppEditDrawer/>
        <AppDetailDrawer/>
        <ListToolPage {...this.getCustomProps()}/>
      </div>
    );
  }
}

export default AppListPage;
