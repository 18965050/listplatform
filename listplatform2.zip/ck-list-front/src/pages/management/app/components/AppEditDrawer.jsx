import React, { Component } from 'react';
import { connect } from 'dva';
import _ from 'lodash';
import { Button, Col, Divider, Drawer, Form, Input, Row, Select } from 'antd';
import withRouter from 'umi/withRouter';

const mapStateToProps = ({
                           app:
                             {
                               editModalVisible,
                               editRecord,
                               editType,
                               refreshCounter,
                             }
                         }) => ({
  visible: editModalVisible,
  record: editRecord,
  editType,
  refreshCounter,
});

@withRouter
@connect(mapStateToProps)
@Form.create()
class AppEditDrawer extends Component {
  onOk = () => {
    const { editType, record, dispatch, form, refreshCounter } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = { ...fieldsValue };
      dispatch({
        type: 'app/edit',
        payload: {
          editType,
          oldRecord: record,
          values,
          form,
          refreshCounter,
        },
      });
    });
  };

  onCancel = () => {
    const { dispatch, form } = this.props;
    dispatch({
      type: 'app/editModalVisible',
      payload: {
        visible: false,
      },
    });
    form.resetFields();
  };


  render() {
    const { form, editType, visible, record } = this.props;
    const title = editType === 'edit' ? '编辑' : '创建';
    const formItemLayout = { labelCol: { span: 8 }, wrapperCol: { span: 16 } };

    return (
      <Drawer
        title={title}
        visible={visible}
        onClose={this.onCancel}
        width="50%"
      >
        <Form {...formItemLayout}>
          <Row gutter={16}>
            <Col offset={4} span={16}>
              <Form.Item key="appId" label="应用ID">
                {form.getFieldDecorator('appId', {
                  rules: [{ required: true, message: '请输入ID' }, { pattern: /^\d+$/, message: '请输入数字！' }],
                  initialValue: record.appId,
                })(<Input placeholder="请输入" disabled={editType === 'edit'}/>)}
              </Form.Item>
              <Form.Item key="appName" label="应用名称">
                {form.getFieldDecorator('appName', {
                  rules: [{ required: true, message: '请输入名称' }],
                  initialValue: record.appName,
                })(<Input placeholder="请输入名称"/>)}
              </Form.Item>
              <Form.Item key="appKey" label="应用key">
                {form.getFieldDecorator('appKey', {
                  rules: [{ max: 100, message: '字段长度不能超过100' }],
                  initialValue: record.appKey,
                })(<Input placeholder="请输入key"/>)}
              </Form.Item>
              <Form.Item key="appSecret" label="应用密钥">
                {form.getFieldDecorator('appSecret', {
                  rules: [{ max: 100, message: '字段长度不能超过100' }],
                  initialValue: record.appSecret,
                })(<Input.Password visibilityToggle placeholder="请输入密钥"/>)}
              </Form.Item>
              <Form.Item key="status" label="状态">
                {form.getFieldDecorator('status', {
                  rules: [{ required: true, message: '请输入状态' }],
                  initialValue: _.isUndefined(record.status) ? undefined : `${record.status}`,
                })(<Select placeholder="请选择">
                  <Select.Option value="0">停用</Select.Option>
                  <Select.Option value="1">启用</Select.Option>
                </Select>)}
              </Form.Item>
            </Col>
          </Row>
        </Form>
        <Divider/>
        <div
          style={{
            textAlign: 'right',
          }}
        >
          <Button onClick={this.onCancel} style={{ marginRight: 8 }}>
            取消
          </Button>
          <Button onClick={this.onOk} type="primary">
            提交
          </Button>
        </div>
      </Drawer>
    );
  }
}

export default AppEditDrawer;
