import React from 'react';
import AppListPage from './components/AppListPage';

// noinspection JSUnusedGlobalSymbols
export default () => (
  <div>
    <AppListPage/>
  </div>
);
