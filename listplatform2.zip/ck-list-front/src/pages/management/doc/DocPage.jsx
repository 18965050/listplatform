import React, { Component } from 'react';
import { Anchor, Col, Collapse, Divider, Row } from 'antd';
import withRouter from 'umi/withRouter';
import ReactMarkdown from 'react-markdown';
import _ from 'lodash';
import style from './style.less';

const { Link } = Anchor;
const { Panel } = Collapse;

@withRouter
class DocPage extends Component {
  constructor(props) {
    super(props);
    this.state = { panelActiveKey: '' };
  }

  componentWillMount() {
    const url = window.location.href
    const panelActiveKey = url.indexOf('#') > 0 ? url.substring(url.indexOf('#') + 1) : '';
    this.setState({ panelActiveKey });
  }

  genCollapse = (collapseDatas) => {
    const { panelActiveKey } = this.state;
    const collapses = [];
    _.forEach(collapseDatas, (collapseData) => {
      const { children } = collapseData;
      const panels = [];
      if (!_.isEmpty(children)) {
        _.forEach(children, (child) => {
          let panel;
          const { children: grandsons } = child;
          if (!_.isEmpty(grandsons)) {
            panel = (<Panel header={<a name={child.id}>{child.name}</a>} key={child.id}>{this.genCollapse(grandsons)}
            </Panel>)
          } else {
            panel = (<Panel header={<a name={child.id}>{child.name}</a>} key={child.id}>
              <ReactMarkdown className={style.markdownStyle} source={child.content} escapeHtml={false}/>
            </Panel>);
          }
          panels.push(panel);
        });
      }
      collapses.push(
        <div key={collapseData.id} className={style.markdownStyle}>
          <a name={collapseData.id}><h2>{collapseData.name}</h2></a>
          <Collapse
            className={style.markdownStyle}
            activeKey={panelActiveKey}
            onChange={this.collapseChange}
            accordion>
            {panels}
          </Collapse>
          <Divider/>
        </div>);
    });
    return collapses;
  }

  collapseChange = (key) => {
    this.setState({ panelActiveKey: key });
    // const { location } = this.props;
    // window.location.href = _.isEmpty(key) ? `${location.pathname}` : `${location.pathname}#${key}`;
  }

  genAnchorLink = (anchorDatas) => {
    const anchorLinks = [];
    _.forEach(anchorDatas, (anchorData) => {
      let anchorLink;
      const { children } = anchorData;
      if (!_.isEmpty(children)) {
        anchorLink = (<Link key={anchorData.id}
                            href={`#${anchorData.id}`}
                            title={anchorData.name}>{this.genAnchorLink(children)}</Link>);
      } else {
        anchorLink = (<Link key={anchorData.id} href={`#${anchorData.id}`} title={anchorData.name}></Link>);
      }
      anchorLinks.push(anchorLink);
    });
    return anchorLinks;
  }

  render() {
    const { datas } = this.props;
    const rowLayout = { type: 'flex', gutter: { xs: 8, sm: 16, md: 24 }, justify: 'space-between' };
    return (
      <Row {...rowLayout}>
        <Col span={20}>
          {this.genCollapse(datas)}
        </Col>
        <Col span={4}>
          <Anchor className={style.markdownStyle}
                  onClick={(e, link) => (this.setState({ panelActiveKey: link.href.substring(1) }))}
                  offsetTop={100}>
            {this.genAnchorLink(datas)}
          </Anchor>
        </Col>
      </Row>
    );
  }
}

export default DocPage;
