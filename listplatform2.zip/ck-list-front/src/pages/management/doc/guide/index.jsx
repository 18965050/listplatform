import React from 'react';
import DocPage from '../DocPage';
import datas from './content';

export default () => (
  <div>
    <DocPage datas={datas}/>
  </div>
);
