import { docOtherBaseUrl, docPicGuideBaseUrl } from '@/utils/utils';

const datas = [{
  id: 'userGuide',
  name: '接入指南',
  children: [{
    id: 'configDS',
    name: '配置数据源',
    content: `
### 说明
  配置列表使用的数据源

### 步骤
  * **请在[配置中心](http://config.xyz.cn)->ck-list->application namespace中进行数据源的配置. 配置格式为\`ds.$dsName.param\`.配置项说明如下:**
  <table border="1" cellpadding="5px">
    <tr>
      <th>配置项</th>
      <th>是否必配</th>
      <th>说明</th>
    </tr>
    <tr>
      <td>ds.$dsName.connurl</td>
      <td>Y</td>
      <td>JDBC连接URL</td>
    </tr>
    <tr>
      <td>ds.$dsName.driver</td>
      <td>Y</td>
      <td>JDBC连接驱动</td>
    </tr>
    <tr>
      <td>ds.$dsName.user</td>
      <td>Y</td>
      <td>用户名</td>
    </tr>
    <tr>
      <td>ds.$dsName.pwd</td>
      <td>Y</td>
      <td>密码</td>
    </tr>
    <tr>
      <td>ds.$dsName.initialSize</td>
      <td>N</td>
      <td>初始化建立的连接数. 默认1</td>
    </tr>
    <tr>
      <td>ds.$dsName.maxActive</td>
      <td>N</td>
      <td>最大活跃连接数. 默认8</td>
    </tr>  
    <tr>
      <td>ds.$dsName.minIdle</td>
      <td>N</td>
      <td>最小空闲连接数. 默认1</td>
    </tr>             
    <tr>
      <td>ds.$dsName.maxWait</td>
      <td>N</td>
      <td>获取连接时最大等待时间. 默认10s</td>
    </tr>        
  </table>   
  <p /><p />
  示例图:

  ![配置中心配置数据源](${docPicGuideBaseUrl}/confDS-1.png)
  
  * **在[列表平台](/management/datasource/list)进行数据源关联配置.**
  
  ![列表平台数据源关联](${docPicGuideBaseUrl}/confDS-2.png)
  
### 备注
  **强烈建议针对使用同一数据源的不同应用, 不要共用数据源配置, 而应该独立配置, 防止连接通道被挤占**  
    `
  }, {
    id: 'configApp',
    name: '配置应用',
    content: `
### 说明
  每个列表都有其对应的应用, 这样可以方便配置列表的管理

### 步骤
  * **在[列表平台](/management/app/list)进行应用配置.**
  
  ![配置App](${docPicGuideBaseUrl}/confApp-1.png)
    `
  }, {
    id: 'configList',
    name: '配置列表',
    content: `
### 说明
  所见即所得(WYSIWYG), 强大的多Pipeline分步骤列表配置方式, 能极大的提升您的开发效率! 

### 步骤
  * **在[列表平台](/management/list/list)配置列表基本信息.**
  
  ![配置基本信息](${docPicGuideBaseUrl}/confList-1.png)
  
  * **点击下一页, 进行配置信息配置**
  
  ![配置列表配置信息](${docPicGuideBaseUrl}/confList-2.png)
  
  * **点击分页配置, 进行分页信息配置**
  
  ![配置分页](${docPicGuideBaseUrl}/confList-3.png)
  
  * **点击确定, 可以看到配置页面的分页信息已经发生变化. 这就是强大的所见即所得功能, 后面功能配置, 字段配置, Pipeline配置,都是配置完成就能立即看到结果**
  
  ![分页信息变化](${docPicGuideBaseUrl}/confList-4.png)
  
  * **点击功能域配置->添加, 进行功能域配置. 可配置多个功能, 每配置完成一个功能请点击"保存"**
  
  ![配置功能域](${docPicGuideBaseUrl}/confList-5.png)
  
  * **[字段配置](#configField)**
  
  * **[Pipeline配置](#configPipeline)**
    `
  }, {
    id: 'configField',
    name: '字段配置',
    content: `
### 步骤    
  * **点击字段配置->添加->编辑->保存, 进行列表字段配置.**
  
  ![配置字段](${docPicGuideBaseUrl}/confList-6.png)
  
### 说明
  - 如果字段不是检索字段, 请取消勾选"是否检索字段"
  - 如果字段不是列表结果字段, 请取消勾选"是否结果字段"
  - 字段映射可参见[execMapping](${docOtherBaseUrl}#execMapping)的说明. 目前支持下列配置方式: 
  
  <table border="1" cellpadding="5px">
    <tr>
      <th width="10%">配置方式</th>
      <th>示例</th>
      <th>说明</th>
    </tr>
    <tr>
      <td>json</td>
      <td>json://{0:"无效",1:"有效"}</td>
      <td>以 "json://" 开头, 后面遵循map的数据结构</td>
    </tr>
    <tr>
      <td>ql</td>
      <td>ql://select 0,'无效' from dual union select 1,'有效' from dual</td>
      <td>以 "ql://" 开头, 只能有两个结果字段,第一个表示实际值, 第二个表示字面值</td>
    </tr>
    <tr>
      <td>dubbo</td>
      <td>dubbo://{"service":"cn.xyz.io.lion.listtool.FieldFormatProvider#dateTime","groupName":"io-lion"}</td>
      <td>以 "dubbo://" 开头, 后接json数据结构. 参考注一</td>
    </tr>
  </table> 
  <p />
  
  - 字段转换用于根据当前记录重新获取字段的值. 目前支持下列配置方式: 
  
  <table border="1" cellpadding="5px">
    <tr>
      <th width="10%">配置方式</th>
      <th>示例</th>
      <th>说明</th>
    </tr>
    <tr>
      <td>ql</td>
      <td>ql://select count(1),count(1) from ins.app_group_endorse_sunshine t where t.ENDORSE_STATUS=4 and t.POLICY_ID=#POLICY_ID#</td>
      <td>以 "ql://" 开头, 只能有两个结果字段,第一个表示实际值, 第二个表示字面值</td>
    </tr>
    <tr>
      <td>dubbo</td>
      <td>dubbo://{"service":"cn.xyz.io.lion.listtool.FieldMappingProvider#prodStatus","groupName":"io-lion"}</td>
      <td>以 "dubbo://" 开头, 后接json数据结构. 参考注二</td>
    </tr>
  </table>  
  <p />
  
### 备注
#### 注一 
  - **json数据结构中service和groupName必填. server格式: className#methodName; groupName为dubbo service group属性**
  
  - **业务应用需要接入FieldFormatProviderImpl服务实现:**
  \`\`\`xml
      <bean name="fieldFormatProvider" class="cn.xyz.listtool.api.impl.FieldFormatProviderImpl" />
      <dubbo:service interface="cn.xyz.listtool.api.FieldFormatProvider" ref="fieldFormatProvider" group="io-lion"/>  
  \`\`\`  
  
  - **业务方法实现签名:**
  \`\`\`java
      public Pair<Object, String> $methodName(FormatContext context, Map<String, ResultDTO.FieldValueDTO> row);
  \`\`\`  
  
#### 注二 
  - **json数据结构中service和groupName必填. server格式: className#methodName; groupName为dubbo service group属性**
  
  - **业务应用需要接入FieldMappingProviderImpl服务实现:**
  \`\`\`xml
      <bean name="fieldMappingProvider" class="cn.xyz.listtool.api.impl.FieldMappingProviderImpl" />
      <dubbo:service interface="cn.xyz.listtool.api.FieldMappingProvider" ref="fieldMappingProvider" group="io-lion"/>  
  \`\`\`  
  
  - **业务方法实现签名:**
  \`\`\`java
      public String $methodName(MappingContext mappingContext);
  \`\`\`       
    `,
  }, {
    id: 'configPipeline',
    name: 'Pipeline配置',
    content: `
### 步骤  
  * **点击Pipeline配置->添加, 进行Pipeline配置. 可配置多个Pipeline, 每配置完成一个Pipeline请点击"保存".**
  
  ![配置Pipeline](${docPicGuideBaseUrl}/confList-7.png)
  
  目前,系统中已经预置了多个Pipeline类型,按配置顺序说明如下:
  - **字段映射执行([execMapping](${docOtherBaseUrl}#execMapping))**
  
  ![execMapping](${docPicGuideBaseUrl}/confList-8.png)
  
  - **ql语句执行([execQl](${docOtherBaseUrl}#execQl))**
  
  ![execQl](${docPicGuideBaseUrl}/confList-9.png)  
  
  ql语句模板遵循Apache Velocity的[VTL](http://velocity.apache.org/engine/devel/vtl-reference.html)规范.同时, 平台集成了[velocity-tools 2.0](http://velocity.apache.org/tools/2.0/generic.html),可供模板编写使用
  
  - **合并执行结果([mergeTempRes](${docOtherBaseUrl}#mergeTempRes))**
  
  ![mergeTempRes](${docPicGuideBaseUrl}/confList-10.png)
  
  - **生成列表数据([generateRes](${docOtherBaseUrl}#generateRes))**
  
  ![generateRes](${docPicGuideBaseUrl}/confList-11.png) 
  
  - **当然, 如果你没找到上述预设的模板, 也可以自己通过脚本编写的方式来实现业务逻辑** 
  
  ![nativeScript](${docPicGuideBaseUrl}/confList-12.png) 
  
  * **列表平台支持对当前已经配置的Pipeline进行调试, 来验证配置是否正确**
  
  ![调试Pipeline](${docPicGuideBaseUrl}/confList-13.png)    

### 备注
   脚本编写和placeHolder脚本编写均支持dubbo服务化调用, 以方便对于qlExpress脚本不熟悉的开发人员进行业务编写. 步骤如下:
   - **脚本中通过dubboCall($groupName,$serviceName,\\__CONTEXT)方式进行服务化调用. 其中, $groupName为dubbo group属性; $serviceName格式: className#methodName; \\__CONTEXT是个map数据结构, 为列表上下文对象**
   
   - **业务应用需要接入ScriptProviderImpl服务实现:**
  \`\`\`xml
      <bean name="listtoolScriptProvider" class="cn.xyz.listtool.api.impl.ScriptProviderImpl" />
      <dubbo:service interface="cn.xyz.listtool.api.ScriptProvider" ref="listtoolScriptProvider" group="io-lion"/> 
  \`\`\` 
  
  - **业务方法实现签名:**
  \`\`\`java
      public Object $methodName(Map<String, Object> context) ;
  \`\`\`      
    `,
  }],
}, {
  id: 'backendAccess',
  name: '后端接入',
  children: [{
    id: 'authExplain',
    name: '权限说明',
    content: `
### 说明
  列表数据返回需要有权限控制. 列表平台中提供了三种权限控制方式, 方便业务应用接入.
  
  <table border="1" cellpadding="5px">
    <tr>
      <th>方式</th>
      <th>说明</th>
    </tr>
    <tr>
      <td>none</td>
      <td>没有权限控制, 只要配置列表状态为有效即可访问</td>
    </tr>  
    <tr>
      <td>medusa</td>
      <td>新一站认证权限控制. 需在列表配置中配置medusa认证表达式, 参见<a href="http://doc.xyz.cn/docs/medusa/authorization.md">medusa权限管理</a>的菜单鉴权部分</td>
    </tr> 
    <tr>
      <td>custom</td>
      <td>业务应用实现列表鉴权. 需在应用配置中配置"应用key"和"应用密钥",由此生成token供业务应用访问列表</td>
    </tr>             
  </table>    
    `,
  }, {
    id: 'clientJarExplain',
    name: 'ck-list-client-java依赖包',
    content: `
### 说明
  为方便业务后端应用接入, 列表平台提供了client端java接入包, 方便后端接入.

### 引入
  - **升级 chaos-web 版本到 \`1.2.3-SNAPSHOT\`**
  
  - **引入依赖:**
  \`\`\`xml
  <dependency>
      <groupId>cn.xyz</groupId>
      <artifactId>ck-list-client-java</artifactId>
      <version>\${ck-list-client.version}</version>
  </dependency>  
  \`\`\`  
  
### 参数说明
  请参考[ListReqDTO](http://git.xyz.cn/dream/ck-list/-/blob/master/client-java/src/main/java/cn/xyz/listtool/ListReqDTO.java) 
  
### 使用示例
  [DemoController.java](http://git.xyz.cn/dream/ck-list/blob/master/ck-list-server/src/main/java/cn/xyz/listtool/web/controller/DemoController.java)  
    `,
  }],
}, {
  id: 'frontendAccess',
  name: '前端接入',
  children: [{
    id: 'listtool',
    name: 'listtool组件',
    content: `
### 说明
  列表页面渲染有很多业务上的要求, 难以统一. 因此列表平台提供了基础列表组件, 供前端开发人员在此基础上扩展. 
  同时, 列表页面中各个域的子组件也已开放出来, 可以更加灵活的进行列表页渲染
  
  **列表组件依赖ant design, 目前已适配2,3,4版本; React支持15,16版本**

### 引入
  \`\`\`shell
  yarn add @xyz/listtool -S
  \`\`\` 
  
### 扩展点说明
  参见[innerContext](http://git.xyz.cn/front-end/listtool/-/blob/master/src/innerContext.jsx)
  
### 使用示例
  [使用ListToolPage组件](http://git.xyz.cn/dream/ck-list-front/-/blob/master/src/pages/demo/policy/PolicyListPage.jsx)    
  [使用ListToolPage子组件1](http://git.xyz.cn/dream/ck-list-front/-/blob/master/src/pages/demo/policy/PolicyListPage1.jsx)    
  [使用ListToolPage子组件2](http://git.xyz.cn/ck/ck-lion-front/-/blob/listtool/src/feature/customer/customerInfo/list/Customer1ListContainer.jsx)
  
### 备注
  input和select组件类型如果不是业务自己渲染,则其是个[自定义的表单控件](https://ant.design/components/form-cn/#components-form-demo-customized-form-controls),传入的value为searchField类型; 否则传入的value为字符串类型,需注意校验规则的不同写法
  \`\`\`js
    // 检索组件为自定义的表单控件
    checkAppName = (rule, searchField, callback) => {
    if (searchField.value && !searchField.value.match(/^\\S{1,100}$/)) {
        return callback('只能输入1~100位非空字符');
      }
      return callback();
    }
    
    {
      id: 'appName',
      fieldDecorator: {
        options: {
          rules: [{ validator: this.checkAppName }],
        },
      },
    },
    
    // 检索组件为业务自己渲染
    {
      id: 'appId',
      eleRender: (searchField) => {
        return <Input placeholder={searchField.placeHolder}/>;
      },
      fieldDecorator: {
        options: {
          rules: [{ pattern: /^\\d{1,9}$/, message: '只能输入1~9位数字' }],
        },
      },
    },    
  \`\`\`  
    `,
  }],
}, {
  id: 'deploy',
  name: '部署',
  children: [{
    id: 'envDeploy',
    name: '环境部署',
    content: `
### 说明
  列表配置会写入数据库中, 不同的环境有不同的数据库. 列表平台提供了配置数据导入导出功能,方便一套配置快速部署到不同的数据库中.
  
### 步骤
  * **数据源列表, 应用列表, 配置列表列表中勾选需要导出的数据,点击"导出", 导出数据到文件**     
  
  ![配置导出](${docPicGuideBaseUrl}/deploy-1.png)
  
  * **在需要导入的环境中, 针对上述列表, 点击"导入", 并选择刚刚导出的文件, 即可实现数据插入新数据库中**  
  
  ![配置导入](${docPicGuideBaseUrl}/deploy-2.png)  
    `,
  }],
}, {
  id: 'monitor',
  name: '监控',
  children: [{
    id: 'monitorGuide',
    name: '监控指南',
    content: `
### 说明
  列表平台已经接入Prometheus监控体系. 开发人员可以在[Grafana数据展示平台](http://grafana.xyz.cn/)中查看列表执行性能
  
### 步骤
  * **选择Dashborad->Manage->业务看板->ck list, 打开列表监控页面**
  
  ![选择ck-list](${docPicGuideBaseUrl}/monitor-1.png)    
  
  * **选择不同的环境, 部署节点和数据源名称, 可查看列表执行性能**
  
  ![性能查看](${docPicGuideBaseUrl}/monitor-2.png)  
    `,
  }],
}, {
  id: 'other',
  name: '其他',
  children: [{
    id: 'qa',
    name: '问答集',
    content: `
### **listtool组件refreshCounter属性有什么作用?**
refreshCounter属性用作非列表查询请求(检索查询,排序,分页)时的列表数据刷新.比如: 产品列表页面中修改产品状态后需要刷新列表页面.
这个属性为Number类型, 当当前值比以前值大, 就会触发列表刷新

### **列表数据导出是怎么使用的?**
列表数据导出在列表平台已经实现, 使用注意如下:
- 列表功能域配置中选择组件类型为"数据导出"

- 和数据导出相关的配置见下图:
  ![导出配置](${docPicGuideBaseUrl}/qa-1.png)
  
- 需导出哪些字段可以在列表字段配置中勾选:
  ![导出字段配置](${docPicGuideBaseUrl}/qa-2.png)

### **使用ListtoolUtils工具包时,如何控制连接超时(CONN_TIMEOUT)和响应超时(SO_TIMEOUT)?**
在请求参数ListReqDTO中设置httpConnTimeout(连接超时,默认3s)和httpSoTimeout(响应超时, 默认60s)

### **列表平台的缓存刷新是干嘛的?**
列表数据查询需要到数据库中查询列表配置, 而列表配置上线后基本不会修改. 为减轻大量列表查询操作对配置数据库的压力, 列表平台对列表配置进行了缓存.
如发现数据库中数据和缓存数据不一致, 请在列表平台中手动刷新下缓存

### **如果只接入列表后端, 前端不接入,该怎么做?**
参考[context结构](${docOtherBaseUrl}#context), 前端接入步骤为:
- 按context.query进行请求数据组装
- reqUrl为\`http://list.xyz.cn/api/listtool/$listId\`,请求方式: POST. 注意不同环境域名不同
- 前后端请求响应已经封装到[request.jsx](http://git.xyz.cn/front-end/listtool/-/blob/master/src/request.jsx)的listFetch方法, 可以直接使用, 无需自己实现
- 响应数据结构参考context.result

### **listtool组件的interceptor干什么用?**
listtool的interceptor包含: beforeListFetch, afterListFetch和searchResetHandler.作用分别为:
- beforeListFetch(reqData): 用于列表请求前的请求数据处理
- afterListFetch(resData): 用于后端列表返回,前端页面渲染前的响应数据处理
- searchResetHandler(): 由于检索域字段是放在form中的, 如果自定义的组件不受antd form控制, 可通过此函数进行检索数据清除


### **列表平台支持几种接入方式?**
目前, 列表平台支持:
- 直接列表前台访问(http://list.xyz.cn/listtool/$listId)
- 业务前端接入列表平台后端访问(http://list.xyz.cn/api/listtool/$listId)
- 业务前端通过业务后端, 业务后端通过[ListtoolUtils](http://git.xyz.cn/dream/ck-list/-/blob/master/client-java/src/main/java/cn/xyz/listtool/ListtoolUtils.java)访问列表平台后端

注意不同环境列表平台域名的区别

### **如何调试列表组件?**
为了方便列表组件调试, 特地将源码打入listtool lib包. 需要调试时, 只需从源码目录引入组件即可.
\`\`\`javascript
//从编译文件引入组件
import { ListToolPageHOC } from '@xyz/listtool';

//从源码目录引入组件
import ListToolPageHOC from '@xyz/listtool/src/components/ListToolPageHOC';
\`\`\`
    `,
  }],
}];

export default datas;
