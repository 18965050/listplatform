const datas = [{
  id: 'apiDesc',
  name: 'API说明',
  children: [{
    id: 'context',
    name: 'context结构',
    content: `
  \`\`\`json
  {
    query:{                                         //请求对象
      param:{                                       //检索
        value: [string]                             //检索值
        match: [int]                                //检索模式
      },
      order:{                                       //排序
        $fieldKey: [0|1]                            //0:升序, 1:降序
      },
      placeHolder:{                                 //ql模板变量
        $tmplVar: [object]                          //模板变量值                            
      },
      pagenator:{                                   //分页
        pageIndex: [int]                            //第几页.默认1
        pageSize: [int]                             //每页记录数
      },
      oper: {                                       //操作
        exec: [0|1]                                 //是否实际列表查询. 0: 否; 1: 是
        export: [0|1]                               //是否列表数据导出. 0: 否; 1: 是
      }
    },
    spec: {                                         //列表配置对象
      pagenator:{                                   //分页配置, 会被query.pagenator覆盖
        pageSize: [int]                             //每页记录数
      },
      functions: [{                                 //功能配置.会被listtool组件中customFunctions覆盖
        key: [string]                               
        comType: ['export'|'custom']                //export: 导出列表数据,无需业务实现功能; custom: 需要业务组件渲染及逻辑实现
        index: [int]                                //排序
      }],
      pipelines:[{                                  //pipeline配置
        name: [string],                             //名称  
        type: [string],                             //类型
        data: [object],                             //内容取决于type  
        index: [int]                                //排序
      }],
      fields: [{                                    //字段配置. 会被listtool组件中customSearchFields, customTableColumns覆盖
        key: [string],
        label: [string],                            //标签, 用于检索域的label和结果域的标题  
        remark: [string],                           //用于检索域的提示信息
        mapping: [string],                          //字段映射.支持ql://和dubbo://配置
        search: {                                   //是否为检索字段
          match: {                                  //检索方式
            $[key:int]: $[desc:string]              //参考"备注 match属性含义"
          },
          eleType: [string],                        //前端组件类型.目前实现有input,select
          dataType: [int],                          //数据类型. 参考"备注 dataType属性含义" 
          index: [int],                             //检索域排序
        },
        result: {                                   //是否为列表显示字段
          order: [0|1],                             //是否支持排序检索. 0: 不支持; 1: 支持
          format: [string],                         //字段转换. 支持json://, ql://和dubbo://配置
          export: [0|1],                            //是否为导出字段.  0: 不导出; 1: 导出
          index: [int]                              //结果域排序
        }
      }],
    },
    temps: {                                        //pipeline临时结果保存
      currentPipelineDTO: [pipelineDTO]             //当前执行的pipeline
      tempDTOMap: {
        $pipelineName: [tempDTO]                     
      }
    },
    result: {                                       //结果输出
      title: [string],                              //列表名称
      query: [#query],                              //上面context.query部分
      spec: [#spec],                                //上面context.spec部分,不包括pipelines和pagenator
      pagenator: {                                  //分页信息
        pageIndex: [int],
        pageSize: [int],
        pageCount: [int],
        totalCount: [int]
      },
      list: [{                                      //结果集
        $fieldName:{                                //字段名
          value: [object],                          //实际值
          labelValue: [string]                      //字面值
        }
      }]
    },
    id: [int]                                       //列表ID
    qlPlaceHolder: {                                //ql velocity模板变量
      $tmplVal:[object]
    }
  }
  \`\`\`    
    `,
  }],
}, {
  id: 'funcDesc',
  name: '函数说明',
  children: [{
    id: 'execMapping',
    name: 'execMapping',
    content: `
### 说明
  对所有配置mapping的字段执行字段映射. 映射结果用于列表检索域和数据展示域
  - 检索域: 生成下拉框中选项
  - 数据展示域: 用于字面值和实际值的映射
  <p />
  
### 输入
  <table border="1" cellpadding="5px">
    <tr>
      <th>参数</th>
      <th>说明</th>
    </tr>
    <tr>
      <td>context</td>
      <td>脚本引擎执行上下文. 统一写作"__CONTEXT"</td>
    </tr>
    <tr>
      <td>execMappingParam</td>
      <td>参见<a href="http://git.xyz.cn/dream/ck-list/-/blob/master/ck-list-server/src/main/java/cn/xyz/listtool/pipeline/ExecMappingParam.java" target="_blank">execMappingParam</a></td>
    </tr>
  </table> 
  <p />

### 输出  
  无. 执行结果放入context的FieldDTO中的mapping属性中.
  <p />  
    `,
  }, {
    id: 'execQl',
    name: 'execQl',
    content: `
### 说明
  对原始ql语句的列表组装(检索, 分页, 排序等)并执行. 其执行流程分为如下步骤:
  - 执行placeHolder生成脚本, 生成ql模板语句的参数
  - 带入模板参数到模板脚本, 生成原始ql语句
  - 组装检索,排序,分页条件,生成待执行的ql语句
  - ql语句执行,生成临时结果
  - 如果字段配置有format属性, 执行字段format转换
  - 如果字段配置有mapping属性, 执行字段mapping转换

### 输入
  <table border="1" cellpadding="5px">
    <tr>
      <th>参数</th>
      <th>说明</th>
    </tr>
    <tr>
      <td>context</td>
      <td>脚本引擎执行上下文. 统一写作"__CONTEXT"</td>
    </tr>
    <tr>
      <td>execQlParam</td>
      <td>参见<a href="http://git.xyz.cn/dream/ck-list/-/blob/master/ck-list-server/src/main/java/cn/xyz/listtool/pipeline/ExecQlParam.java" target="_blank">execQlParam</a></td>
    </tr>
  </table> 
  <p />

### 输出  
  执行结果放入context的TempDTO中.结构如下
  \`\`\`json
  {
    pagenator: {              //分页信息
      pageIndex:              //当前页
      pageSize:               //每页记录数
      pageCount:              //总页数
      totalCount:             //总记录数
    },
    list: [{                  //结果集
      $fieldKey:{             //结果字段
        value:                //实际值
        labelValue:           //字面值
      }
    }]
  }
  \`\`\` 
  <p />
    `,
  }, {
    id: 'mergeTempRes',
    name: 'mergeTempRes',
    content: `
### 说明
  用于合并source pipeline执行结果到target pipeline结果中

### 输入
  <table border="1" cellpadding="5px">
    <tr>
      <th>参数</th>
      <th>说明</th>
    </tr>
    <tr>
      <td>context</td>
      <td>脚本引擎执行上下文. 统一写作"__CONTEXT"</td>
    </tr>
    <tr>
      <td>mergeResultParam</td>
      <td>参见<a href="http://git.xyz.cn/dream/ck-list/-/blob/master/ck-list-server/src/main/java/cn/xyz/listtool/pipeline/MergeTempResParam.java" target="_blank">mergeResultParam</a></td>
    </tr>      
  </table> 
  <p />

### 输出  
  无. 结果合并到目标pipeline的结果集中
    `,
  }, {
    id: 'generateRes',
    name: 'generateRes',
    content: `
### 说明
  最后一个pipeline执行, 用于处理,合并每个pipeline执行结果到ResultDTO中  
  
### 输入
  无. 从context的各个pipeline执行结果TempDTO中获取输入数据

### 输出  
  无. 处理结果放在context的[ResultDTO](http://git.xyz.cn/dream/ck-list/-/blob/master/client-java/src/main/java/cn/xyz/listtool/dto/ResultDTO.java?_blank)中.  
    `,
  }],
}, {
  id: 'comment',
  name: '备注',
  children: [{
    id: 'fieldMatch',
    name: '字段match属性含义',
    content: `
### 说明
  match属性表示字段检索匹配类型.
  
  <table border="1" cellpadding="5px">
    <tr>
      <th>值</th>
      <th>含义</th>
    </tr>
    <tr>
      <td>0</td>
      <td>精确匹配</td>
    </tr>
    <tr>
      <td>1</td>
      <td>模糊匹配</td>
    </tr>
    <tr>
      <td>2</td>
      <td>不等于</td>
    </tr>
    <tr>
      <td>3</td>
      <td>连续范围(between...and...)</td>
    </tr>
    <tr>
      <td>4</td>
      <td>不连续范围(in...)</td>
    </tr>    
  </table>   
    `,
  }, {
    id: 'fieldDataType',
    name: '字段dataType属性含义',
    content: `
### 说明
  dataType属性表示字段数据类型.和java.sql.JDBCType中定义保持一致
  
  <table border="1" cellpadding="5px">
    <tr>
      <th>值</th>
      <th>含义</th>
    </tr>
    <tr>
      <td>4</td>
      <td>INT</td>
    </tr>
    <tr>
      <td>-5</td>
      <td>BIGINT</td>
    </tr>
    <tr>
      <td>6</td>
      <td>FLOAT</td>
    </tr>
    <tr>
      <td>8</td>
      <td>DOUBLE</td>
    </tr>
    <tr>
      <td>12</td>
      <td>VARCHAR</td>
    </tr>   
    <tr>
      <td>91</td>
      <td>DATE</td>
    </tr> 
    <tr>
      <td>92</td>
      <td>TIME</td>
    </tr> 
    <tr>
      <td>93</td>
      <td>TIMESTAMP</td>
    </tr>        
  </table>     
    `,
  }],
}];

export default datas;
