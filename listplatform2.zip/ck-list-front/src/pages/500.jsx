import React from 'react';
import Link from 'umi/link';
import { Button, Result } from 'antd';

// noinspection JSUnusedGlobalSymbols
export default () => (
  <Result
    status="500"
    title="500"
    subTitle="Sorry, 服务端貌似出了点问题。"
    extra={
      <Link to="/">
        <Button type="primary">返回首页</Button>
      </Link>
    }
  />
);
