import React from 'react';
import Link from 'umi/link';
import { Button, Result } from 'antd';

// noinspection JSUnusedGlobalSymbols
export default () => (
  <Result
    status="404"
    title="404"
    subTitle="Sorry, 您访问的页面不存在。"
    extra={
      <Link to="/">
        <Button type="primary">返回首页</Button>
      </Link>
    }
  />
);
