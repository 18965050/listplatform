/**
 * 格式化
 *
 * @param obj
 */
const toJSONString = obj => {
  const type = typeof obj;
  let str = 'null';
  switch (type) {
    case 'undefined':
      str = 'undefined';
      break;
    case 'boolean':
      str = String(obj);
      break;
    case 'string':
      try {
        const jsonObj = JSON.parse(obj);
        str = typeof jsonObj === 'object' ? JSON.stringify(jsonObj, null, '\t') : obj;
      } catch (e) {
        str = obj;
      }
      break;
    case 'number':
      str = String(obj);
      break;
    case 'object':
      str = JSON.stringify(obj, null, '\t');
      break;
    default:
      break;
  }
  return str;
};

const parseObject = str => {
  const type = typeof str;
  let obj = null;
  switch (type) {
    case 'undefined':
      obj = { info: str, message: 'info property must be a valid json object! ' };
      break;
    case 'string':
      try {
        obj = JSON.parse(str);
      } catch (e) {
        obj = { info: str, message: 'info property must be a valid json object! ' };
      }
      break;
    case 'object':
      if (str === null) {
        obj = { info: str, message: 'info property must be a valid json object! ' };
      } else {
        obj = str;
      }
      break;
    default:
      obj = { info: str, message: 'info property must be a valid json object! ' };
      break;
  }
  return obj;
}

const getJsonField = (obj, field) => {
  if (!obj) {
    return null;
  }
  if (Array.isArray(obj)) {
    const fo = obj.find((o) => o && o[field])
    return fo && fo[field];
  }
  return obj[field];
}

export { toJSONString, parseObject, getJsonField };
