/* eslint no-useless-escape:0 import/prefer-default-export:0 */
import _ from 'lodash';
import moment from 'moment';

const reg = /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+(?::\d+)?|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/;

const isUrl = (path) => reg.test(path);

const isAntDesignPro = () => {
  if (ANT_DESIGN_PRO_ONLY_DO_NOT_USE_IN_YOUR_PRODUCTION === 'site') {
    return true;
  }

  return window.location.hostname === 'preview.pro.ant.design';
}; // 给官方演示站点用，用于关闭真实开发环境不需要使用的特性

const isAntDesignProOrDev = () => {
  const { NODE_ENV } = process.env;

  if (NODE_ENV === 'development') {
    return true;
  }

  return isAntDesignPro();
};

const ALL_FIELDS = '_@_';

/**
 * 数据导出
 * @param paramObj
 */
const exportCallback = (paramObj) => {
  if (window.navigator.msSaveOrOpenBlob) {
    navigator.msSaveBlob(paramObj.data, paramObj.filename);
  } else {
    const link = document.createElement('a');
    const evt = document.createEvent('MouseEvents');
    link.style.display = 'none';
    link.href = window.URL.createObjectURL(paramObj.data);
    link.download = paramObj.filename;
    document.body.appendChild(link); // 此写法兼容可火狐浏览器
    evt.initEvent('click', false, false);
    link.dispatchEvent(evt);
    document.body.removeChild(link);
  }
};

const isJSON = (str) => {
  try {
    if (_.isObjectLike(JSON.parse(str))) {
      return true;
    }
  } catch (e) {
    return false;
  }
  return false;
};

const isEmptyOrJSON = (str) => {
  return _.isEmpty(str) ? true : isJSON(str);
}

const jsonBeautify = (str) => {
  return isJSON(str) ? JSON.stringify(JSON.parse(str), null, 2) : str;
}

const timeFmt = (text) => moment(text.value).format('YYYY-MM-DD HH:mm:ss');

const docPicBaseUrl = '/doc';
const docPicGuideBaseUrl = `${docPicBaseUrl}/guide`;
const docBaseUrl = '/management/doc';
const docGuideBaseUrl = `${docBaseUrl}/guide`;
const docOtherBaseUrl = `${docBaseUrl}/other`;

export {
  isAntDesignProOrDev,
  isAntDesignPro,
  ALL_FIELDS,
  isJSON,
  isEmptyOrJSON,
  jsonBeautify,
  isUrl,
  timeFmt,
  exportCallback,
  docPicBaseUrl,
  docPicGuideBaseUrl,
  docBaseUrl,
  docGuideBaseUrl,
  docOtherBaseUrl,
};
