import React, { Component } from 'react';
import wrong from '@/assets/wrong.jpeg';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error(error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <p style={{ textAlign: 'center' }}>
          <img src={wrong} alt="react异常"/>
        </p>);
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
