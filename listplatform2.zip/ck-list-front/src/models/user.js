const UserModel = {
  namespace: 'user',
  state: {
    currentUser: {},
  },
};
export default UserModel;
