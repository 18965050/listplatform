export const dva = {
  config: {
    onError(e) {
      e.preventDefault();
      console.error(e.message);
    },
    initialState: {
      user: {
        currentUser: {
          name: 'lcg',
        },
      },
    },
  },
  plugins: [
    // require('dva-logger')(),
  ],
};
