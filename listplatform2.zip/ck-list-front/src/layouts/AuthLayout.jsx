import React from 'react';
import authHelper from '@/authHelper';
import ErrorBoundary from '@/components/ErrorBoundary';

const { DashboardLayout } = authHelper;
const { checkAuthHOC } = authHelper;
const Layout = checkAuthHOC(DashboardLayout);

function AuthLayout(props) {
  // auth 集成配置地址变更的方法
  authHelper.configChangeUrlHandler(props.history.push);

  authHelper.configHistory(props.history);

  return (
    <div>
      <Layout {...props}>
        <ErrorBoundary>
          {props.children}
        </ErrorBoundary>
      </Layout>
    </div>
  );
}

export default AuthLayout;
