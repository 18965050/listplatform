/**
 * Ant Design Pro v4 use `@ant-design/pro-layout` to handle Layout.
 * You can view component api by:
 * https://github.com/ant-design/ant-design-pro-layout
 */
import _ from 'lodash';
import ProLayout from '@ant-design/pro-layout';
import { Layout } from 'antd';
import React, { useState } from 'react';
import Link from 'umi/link';
import { connect } from 'dva';
import Authorized from '@/utils/Authorized';
import RightContent from '@/components/GlobalHeader/RightContent';
import logo from '../assets/logo.svg';

const { Footer } = Layout;

/**
 * use Authorized check all menu item
 */
const menuDataRender = menuList =>
  menuList.map(item => {
    const localItem = { ...item, children: item.children ? menuDataRender(item.children) : [] };
    return Authorized.check(item.authority, localItem, null);
  });

const footerRender = () => (
  <Footer style={{ textAlign: 'center' }}>Listtool © Created by XYZ</Footer>
);

const pageTitleRender = () => ' 列表平台';

const BasicLayout = props => {
  const { dispatch, children, settings } = props;

  useState(() => {
    if (dispatch) {
      dispatch({
        type: 'settings/getSetting',
      });
    }
  });
  /**
   * init variables
   */

  const handleMenuCollapse = payload =>
    dispatch &&
    dispatch({
      type: 'global/changeLayoutCollapsed',
      payload,
    });

  return (
    <ProLayout
      logo={logo}
      onCollapse={handleMenuCollapse}
      menuItemRender={(menuItemProps, defaultDom) => {
        return _.isUndefined(menuItemProps.component) ? defaultDom : (
          <Link to={menuItemProps.path}>{defaultDom}</Link>);
      }}
      breadcrumbRender={(routers = []) => [
        {
          path: '/',
          breadcrumbName: '列表平台',
        },
        ...routers,
      ]}
      footerRender={footerRender}
      menuDataRender={menuDataRender}
      pageTitleRender={pageTitleRender}
      rightContentRender={rightProps => <RightContent {...rightProps} />}
      {...props}
      {...settings}
    >
      {children}
    </ProLayout>
  );
};

export default connect(({ global, settings }) => ({
  collapsed: global.collapsed,
  settings,
}))(BasicLayout);
