export default {
  'POST /api/listtool/1001': {
    ret: 0,
    msg: [],
    data: {
      title: '投保单列表',
      query: {
        param: {
          APPID: 191030232299,
          ORDERSTATUS: 2,
          INSUREDATE: '1573743428641:::1576743428641'
        },
        order: {
          APPID: 0,
        },
        placeHolder: {
          ph1: 'a.order_id=b.order_id',
          ph2: 'a.add_time>to_date(\'2019-10-30\',\'yyyy-MM-dd\')'
        },
        pagenator: {
          pageIndex: 1,
          pageSize: 10
        }
      },
      spec: {
        functions: [{
          key: 'export',
          index: 0
        }],
        fields: [{
          key: 'APPID',
          label: '投保单ID',
          remark: '投保单ID',
          search: {
            match: 0,
            eleType: 'input',
            dataType: 1,
            index: 1
          },
          result: {
            show: 1,
            primary: 1,
            order: 1,
            index: 0
          }
        }, {
          key: 'ORDERID',
          label: '订单ID',
          remark: '订单ID',
          result: {
            show: 1,
            order: 0,
            index: 1
          }
        }, {
          key: 'ORDERSTATUS',
          label: '订单状态',
          remark: '订单状态',
          search: {
            match: 3,
            eleType: 'select',
            dataType: 0,
            mapping: '{"1":"等待支付","2":"支付成功","3":"支付未成功","4":"撤销"}',
            index: 0
          },
          result: {
            show: 1,
            order: 0,
            format: 'ql://select #ORDERSTATUS#||\'(支付成功)\' from dual',
            index: 2
          }
        }, {
          key: 'INSUREDATE',
          label: '投保日期',
          remark: '投保日期',
          search: {
            match: 3,
            eleType: 'timePicker',
            dataType: 6,
            index: 2
          }
        },
          {
            key: 'INSUREDATE2',
            label: '投保日期',
            remark: '投保日期',
            search: {
              match: 3,
              eleType: 'datePicker',
              dataType: 5,
              index: 2
            }
          },
          {
            key: 'INSUREDATE3',
            label: '投保日期',
            remark: '投保日期',
            search: {
              match: 3,
              eleType: 'datePicker',
              dataType: 5,
              index: 2
            }
          },
          {
            key: 'INSUREDATE4',
            label: '投保日期',
            remark: '投保日期',
            search: {
              match: 3,
              eleType: 'datePicker',
              dataType: 5,
              index: 2
            }
          },
          {
            key: 'INSUREDATE5',
            label: '投保日期',
            remark: '投保日期',
            search: {
              match: 3,
              eleType: 'datePicker',
              dataType: 5,
              index: 2
            }
          },
          {
            key: 'INSUREDATE6',
            label: '投保日期',
            remark: '投保日期',
            search: {
              match: 3,
              eleType: 'datePicker',
              dataType: 5,
              index: 2
            }
          },
          ]
      },
      pagenator: {
        pageIndex: 1,
        pageSize: 10,
        pageCount: 116,
        totalCount: 1155
      },
      list: [{
        APPID: 191030232299,
        ORDERID: 191030232301,
        ORDERSTATUS: '2(支付成功)'
      }, {
        APPID: 191030232309,
        ORDERID: 191030232310,
        ORDERSTATUS: '5(支付成功)'
      }, {
        APPID: 191030232314,
        ORDERID: 191030232313,
        ORDERSTATUS: '5(支付成功)'
      }, {
        APPID: 191030232316,
        ORDERID: 191030232315,
        ORDERSTATUS: '5(支付成功)'
      }, {
        APPID: 191030232319,
        ORDERID: 191030232318,
        ORDERSTATUS: '5(支付成功)'
      }, {
        APPID: 191030232324,
        ORDERID: 191030232325,
        ORDERSTATUS: '2(支付成功)'
      }, {
        APPID: 191030232328,
        ORDERID: 191030232329,
        ORDERSTATUS: '2(支付成功)'
      }, {
        APPID: 191030232335,
        ORDERID: 191030232336,
        ORDERSTATUS: '5(支付成功)'
      }, {
        APPID: 191030232338,
        ORDERID: 191030232337,
        ORDERSTATUS: '5(支付成功)'
      }, {
        APPID: 191030232340,
        ORDERID: 191030232339,
        ORDERSTATUS: '0(支付成功)'
      }]
    },
  }
};
