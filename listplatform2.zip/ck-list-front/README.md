# ck-list-front

项目使用 [Ant Design Pro](https://pro.ant.design) 初始化.做了部分裁剪。


## 环境要求

node >= 10 yarn > 1.16

npm/yarn registry 为公司内部 registry（http://192.168.51.44），可以进行私有库依赖

### 公司内部 registry 配置

公司内部 registry 地址为 http://192.168.51.44/  
可通过如下命令配置 npm：
```
npm set registry http://192.168.51.44
yarn config set registry http://192.168.51.44
```

**注意：** 公司内部 registry 不使用代理访问，如果配置了代理，通过以下命令去掉：

```
npm config delete proxy
```

## 代码风格

我们的代遵循统一的代码风格，其内容在参考 [airbnb](https://github.com/airbnb/javascript) 的基础上做了一些修改。

JavaScript (ES6) : [https://github.com/airbnb/javascript](https://github.com/airbnb/javascript)  
React : [https://github.com/airbnb/javascript/tree/master/react](https://github.com/airbnb/javascript/tree/master/react)

## ESLint

为了保证 Code Style 的执行，我们使用 ESLint 帮助我们检查不符合规范的地方。其配置文件为 [.eslintrc.js](.eslintrc.js) 。  
该工具在常用的编辑器中都有插件支持。我们主要讲 Intellij/WebStorm 中的配置方法。

### Intellij/WebStorm

1. 打开设置：Settings > Languages & Frameworks > Code Quality Tools > ESLint
2. 勾选 `Enable` / `auto...`
3. Configuration file 选择项目根目录下的 ".eslintrc"

## javascript 格式化

格式化使用项目内的 xyz-x.x-on-xxx.xml

## 项目开发介绍

### 目录结构

├── config # umi 配置，包含路由，构建等配置 ├── public │ └── favicon.png # Favicon ├── src │ ├── assets # 本地静态资源 │ ├── components # 业务通用组件 │ ├── layouts # 通用布局 │ ├── models # 全局 dva model │ ├── pages # 业务页面入口和常用模板 │ ├── services # 后台接口服务 │ ├── utils # 工具库 │ ├── locales # 国际化资源 │ ├── global.less # 全局样式 │ └── global.jsx # 全局 JS ├── README.md └── package.json

### 本地开发

安装依赖

```bash
yarn
```

启动

```bash
yarn start
```

默认端口 8000，可以修改 [package.json](package.json) 文件中 `PORT=8000` 部分。

### 开发文档

#### 路由

路由采用配置式路由，文件是 `/config/routes.js` 。目前菜单和路由耦合，所以路由配置中有菜单部分配置。但配置总体简洁明了，应该可以看懂。

#### 命名

React 组件(components)的文件名和文件夹命名采用大驼峰（首字母大写）命名（除 index.\*)。其他文件夹一律小写(组件/页面目录下的非 React 文件也用小写）。 React 组件/页面文件后缀全部用 `.jsx`，普通 js 文件用 js。

### 脚本介绍

项目的相关脚本在 [package.json](package.json) 文件中`"scripts"`部分配置，可以根据情况修改。

#### Start project

```bash
yarn start
```

#### Build project

```bash
yarn run build
```

#### Check code style

```bash
yarn run lint
```

You can also use script to auto fix some lint error:

```bash
yarn run lint:fix
```

### 更多

You can view full document on our [official website](https://pro.ant.design). And welcome any feedback in our [github](https://github.com/ant-design/ant-design-pro).



