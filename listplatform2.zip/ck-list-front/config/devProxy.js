export default {
  '/api/': {
    target: 'http://localhost:9160/',
    changeOrigin: false,
    pathRewrite: { '^/api': '' },
  },
  '/api/mock': {
    //  临时加入 mock，方式影响其他接口
    target: 'http://yapi.xyz.cn/mock/89/api/',
    changeOrigin: false,
    pathRewrite: { '^/api/mock': '' },
  },
};
