export default {
  "navTheme": "dark",
  "primaryColor": "#13C2C2",
  "layout": "sidemenu",
  "contentWidth": "Fluid",
  "fixedHeader": true,
  "autoHideHeader": true,
  "fixSiderbar": true,
  "menu": {
    "locale": false
  },
  "title": "列表平台",
  "pwa": false,
  "iconfontUrl": "",
  "collapse": true,
  "language": "zh-CN"
};
