export default [
  {
    path: '/auth/login',
    component: './login/index'
  },
  {
    path: "/listtool/:funcId",
    name: "列表查询",
    component: "./demo"
  },
  {
    path: "/",
    component: "../layouts/AuthLayout",
    routes: [
      {
        path: '/',
        name: 'welcome',
        icon: 'smile',
        component: './Welcome',
      },
      {
        path: "/management/datasource",
        name: "数据源管理",
        routes: [
          {
            path: "/management/datasource/list",
            name: "数据源列表",
            component: "./management/datasource"
          },
        ]
      },
      {
        path: "/management/app",
        name: "应用管理",
        routes: [
          {
            path: "/management/app/list",
            name: "应用列表",
            component: "./management/app"
          },
        ]
      },
      {
        path: "/management/list",
        name: "配置列表管理",
        routes: [
          {
            path: "/management/list/list",
            name: "配置应用列表",
            component: "./management/list"
          },
          {
            path: "/management/list/add",
            name: "新增应用列表",
            component: "./management/list/components/ListEditPage.jsx"
          },
          {
            path: "/management/list/update",
            name: "修改应用列表",
            component: "./management/list/components/ListEditPage.jsx"
          },
        ]
      },
      {
        path: "/management/other",
        name: "其他管理",
        routes: [
          {
            path: "/management/other/cache",
            name: "清除缓存",
            component: "./management/cache"
          },
        ]
      },
      {
        path: "/management/doc",
        name: "接入文档",
        routes: [
          {
            path: "/management/doc/guide",
            name: "接入指南",
            component: "./management/doc/guide"
          },
          {
            path: "/management/doc/other",
            name: "其他说明",
            component: "./management/doc/other"
          },
        ]
      },
      {
        path: "/listtool/demo/policy",
        name: "保单列表查询",
        component: "./demo/policy"
      },
      {
        path: '/404',
        component: './404',
      },
      {
        path: '/403',
        component: './403',
      },
      {
        path: '/500',
        component: './500',
      },
    ]
  }
];
