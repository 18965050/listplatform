#! /usr/bin/zsh -lie

source dist/support/shell/const.sh

APP_TARGET_NAME=ck-list-server.jar
bootStop
