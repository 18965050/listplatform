#! /usr/bin/zsh -lie

source dist/support/shell/const.sh

APP_TARGET_ROOT=${DEPLOY_ROOT}/dist/
APP_TARGET_NAME=ck-list-server.jar
WEB_MONITOR_URL=http://localhost:9160/actuator/health
WEB_MONITOR_SUC_CONTENT=UP
bootWebDeploy

