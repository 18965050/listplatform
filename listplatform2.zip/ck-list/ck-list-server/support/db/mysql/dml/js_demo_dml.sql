INSERT INTO LISTTOOL_LIST_INFO(LIST_ID, APP_ID, LIST_NAME, LIST_DESC, AUTH_TYPE, AUTH_EXPR, CONTEXT, DEBUG_PARAM, STATUS)
VALUES (2001, 2, '保单列表', '保单列表', 1, 'P(demo:list:2001)',
   '{
     "pipelines": [{
       "name": "execMapping",
       "type": "execMapping",
       "data": {
         "ds": "demo_apollo",
         "mappingFields": ["_@_"]
       },
       "index":0
     },{
       "name": "policyList",
       "type": "execQl",
       "data": {
         "ds": "demo_apollo",
         "ql": "select P.APP_ID,P.POLICY_NO,A.BUY_TYPE,P.INS_COM_NAME,A.ACCEPT_TIME,P.POLICY_STATUS,P.INS_COM_ID, P.PROD_ID,P.policy_id,p.policy_id key,A.APP_NAME,A.APP_EMAIL,\'0\' as flag,A.PROD_KIND,l.login_id,l.login_name,P.insurant insure_name,decode(A.APP_CARD_TYPE,\'idcard\',\'身份证\',\'armcard\',\'军官证\',\'passport\',\'护照\',\'driving_license\',\'驾驶证\',\'simplified_chinese\',\'港澳台通行证/回乡证\',\'其他\') card_type,A.APP_CARD_NO,k.link_key as cate,to_char(A.STARTING_TIME, \'yyyy-mm-dd\') || \' \' ||A.STARTING_HOUR || \':00:00\' start_time,to_char(A.ENDING_TIME, \'yyyy-mm-dd\') || \' \' || A.ENDING_HOUR ||\':00:00\' end_time,case when o.order_source = 67 and o.sid_code = \'CARWAPSID\' then 67 when o.order_source = 67 and o.sid_code = \'TCV201301060\' then 6 when o.order_source = 67 and o.sid_code = \'WEB201211270\' then 0 when o.order_source_flag = 3 then 5 when o.order_source_flag = 4 then 13 when o.order_source_flag = 5 then 14 else o.order_source end order_source,o.union_login_id,(select login_name from login_info where login_id = o.union_login_id and rownum = 1) union_login_name,o.sid_code,o.order_id,1 as endorse_times,O.UNDWR_CALLBACK_FLAG from POLICY_INFO P,APP_INFO A,ORDER_INFO O,LOGIN_INFO L,(select PROD_ID, LINK_KEY from ins.prod_cate_link where link_type = \'PROD_CATE_MAIN\') k WHERE P.APP_ID = A.APP_ID and a.order_id = o.order_id and k.prod_id = p.prod_id and a.login_id = l.login_id ${PARAMS} and a.ins_com_id in (1,2,43,61,112,143)",
         "paging": 1,
         "queries": ["_@_"],
         "orders": ["_@_"]
       },
       "index": 1
     },{
       "name": "prodList",
       "type": "execQl",
       "data": {
         "ds": "demo_myins",
         "ql": "select PROD_ID,INS_COM_ID,KEYWORD PROD_KEYWORD,PROD_NAME from ins.PROPERTY_INSURANCE where #if($linkList && !$lists.isEmpty($linkList)) #foreach($link in ${linkList}) (PROD_ID=${link.get(\\"PROD_ID\\")} AND INS_COM_ID =${link.get(\\"INS_COM_ID\\")}) #if($foreach.hasNext) OR #end #end #else 1=2 #end",
         "placeHolder": "const placeHolder={};\\nconst policyListRes=__CONTEXT[\'temps\'].tempDTOMap[\'policyList\'].list;\\nif(!_.isNil(policyListRes) && policyListRes.length>0){\\nconst linkList=[];\\n_.forEach(policyListRes,function(policy){\\nconst map={};\\nmap[\'PROD_ID\']=policy[\'PROD_ID\'].value;\\nmap[\'INS_COM_ID\']=policy[\'INS_COM_ID\'].value;\\nlinkList.push(map);\\n});\\nplaceHolder[\'linkList\']=linkList;\\n}\\n__CONTEXT[\'qlPlaceHolder\']=placeHolder;",
         "paging": 0
       },
       "index": 2
     },{
       "name": "mergeTempRes",
       "type": "mergeTempRes",
       "data": {
         "source": "policyList",
         "target": "prodList",
		 "relateFields": ["PROD_ID","INS_COM_ID"]
       },
       "index": 3
     },{
       "name": "generateRes",
       "type": "generateRes",
       "index":4
     }],
     "pagenator": {
       "pageSize": 20
     },
     "functions": [{
       "key":"export",
       "comType":"export",
       "index":1
     }],
     "fields": [{
       "key": "POLICY_NO",
       "label":"保单号",
       "remark":"请输入保单号",
       "search":{
         "match": {
           "0":"精确匹配"
         },
         "eleType": "input",
         "dataType": 12,
         "index":0
       },
       "result":{
         "order":1,
         "index":0
       }
     },{
       "key": "ORDER_ID",
       "label":"订单ID",
       "remark":"订单ID",
       "search":{
         "match": {
           "0":"精确匹配"
         },
         "eleType": "input",
         "dataType": -5,
         "index":1
       }
     },{
       "key": "APP_ID",
       "label":"投保单ID",
       "remark":"投保单ID",
       "search":{
         "match": {
           "0":"精确匹配"
         },
         "eleType": "input",
         "dataType": -5,
         "index":2
       },
       "result":{
         "order":1,
         "index":2
       }
     },{
       "key": "APP_NAME",
       "label":"投保人",
       "remark":"投保人",
       "search":{
         "match": {
           "0":"精确匹配",
           "1":"模糊匹配"
         },
         "eleType": "input",
         "dataType": 12,
         "index":3
       },
       "result":{
         "order":1,
         "index":3
       }
     },{
       "key": "LOGIN_NAME",
       "label":"用户名",
       "remark":"用户名",
       "search":{
         "match": {
           "0":"精确匹配",
           "1":"模糊匹配"
         },
         "eleType": "input",
         "dataType": 12,
         "index":4
       },
       "result":{
         "order":1,
         "index":4
       }
     },{
       "key": "ENDORSE_TIMES",
       "label":"批单次数",
       "remark":"批单次数",
       "result":{
         "order":0,
         "format":"ql://select count(1),count(1) from ins.app_group_endorse_sunshine t where t.ENDORSE_STATUS=4 and t.POLICY_ID=#POLICY_ID#",
         "index":5
       }
     },{
       "key": "APP_EMAIL",
       "label":"投保人Email",
       "remark":"投保人Email",
       "search":{
         "match": {
           "0":"精确匹配",
           "1":"模糊匹配"
         },
         "eleType": "input",
         "dataType": 12,
         "index":6
       }
     },{
       "key": "PROD_NAME",
       "label":"产品名称",
       "remark":"产品名称",
       "result":{
         "order":1,
         "index":7
       }
     },{
       "key": "INS_COM_ID",
       "label":"所属公司",
       "remark":"所属公司",
       "mapping":"ql://select INS_COM_ID,NAME from INS_COMPANY_INFO where ISBRAND = 0",
       "search":{
         "match": {
           "0":"精确匹配"
         },
         "eleType": "select",
         "dataType": -5,
         "index":8
       },
       "result":{
         "order":0,
         "index":8
       }
     },{
       "key": "POLICY_STATUS",
       "label":"保单状态",
       "remark":"保单状态",
       "mapping":"ql://select  1, \'已出单\' from dual union all select 2,\'已退保\' from dual union all select 3,\'已批单\' from dual union all select 4,\'出单中\' from dual",
       "result":{
         "order":0,
         "index":9
       }
     },{
       "key": "ACCEPT_TIME",
       "label":"承保时间",
       "remark":"承保时间",
       "search":{
         "match": {
           "3":"范围(连续)匹配"
         },
         "eleType": "timePicker",
         "dataType": 93,
         "index":10
       },
       "result":{
         "order":1,
         "index":10
       }
     },{
       "key": "CARD_TYPE",
       "label":"投保人证件类型",
       "remark":"投保人证件类型",
       "result":{
         "order":0,
         "index":11
       }
     },{
       "key": "PROD_KIND",
       "label":"保单类型",
       "remark":"保单类型",
       "result":{
         "order":0,
         "index":12
       }
     },{
       "key": "FLAG",
       "label":"标记",
       "remark":"标记",
       "result":{
         "order":0,
         "index":13
       }
     },{
       "key": "INSURE_NAME",
       "label":"被保人",
       "remark":"被保人",
       "search":{
         "match": {
           "0":"精确匹配",
           "1":"模糊匹配"
         },
         "eleType": "input",
         "dataType": 12,
         "index":14
       },
       "result":{
         "order":1,
         "index":14
       }
     },{
       "key": "CATE",
       "label":"产品目录",
       "remark":"产品目录",
       "mapping":"ql://select par_key key, par_value key from ins.base_sys_parameter t where t.par_type =\'PROD_CATE_MAIN\' AND INSTR(T.PAR_key,\'-\')>0 union select \' \' KEY, \'无\' KEY from DUAL",
       "search":{
         "match": {
           "0":"精确匹配"
         },
         "eleType": "select",
         "dataType": 12,
         "index":15
       },
       "result":{
         "order":0,
         "index":15
       }
     },{
       "key": "APP_CARD_NO",
       "label":"投保人证件号码",
       "remark":"投保人证件号码",
       "search":{
         "match": {
           "0":"精确匹配"
         },
         "eleType": "input",
         "dataType": 12,
         "index":16
       },
       "result":{
         "order":1,
         "index":16
       }
      },{
       "key": "START_TIME",
       "label":"保险起期",
       "remark":"保险起期",
       "search":{
         "match": {
           "3":"范围(连续)匹配"
         },
         "eleType": "input",
         "dataType": 12,
         "index":17
       },
       "result":{
         "order":0,
         "index":17
       }
     },{
       "key": "END_TIME",
       "label":"保险止期",
       "remark":"保险止期",
       "search":{
         "match": {
           "3":"范围(连续)匹配"
         },
         "eleType": "input",
         "dataType": 12,
         "index":18
       },
       "result":{
         "order":0,
         "index":18
       }
     },{
       "key": "BUY_TYPE",
       "label":"登录类型",
       "remark":"登录类型",
       "mapping":"ql://select 0 key,\'未登录购买\' value from dual union all select 1 key ,\'新一站账户登录\' value from dual union all select 2 key ,\'新浪单点登录购买\' value from dual",
       "search":{
         "match": {
           "0":"精确匹配"
         },
         "eleType": "select",
         "dataType": 4,
         "index":19
       }
     },{
       "key": "UNION_LOGIN_NAME",
       "label":"渠道用户名",
       "remark":"渠道用户名",
       "search":{
         "match": {
           "1":"模糊匹配"
         },
         "eleType": "input",
         "dataType": 12,
         "index":20
       },
       "result":{
         "order":0,
         "index":20
       }
     },{
       "key": "PROD_KEYWORD",
       "label":"产品关键词",
       "remark":"产品关键词",
       "result":{
         "order":0,
         "index":21
       }
     }]
   }',
   '{"placeHolder":{
       "PARAMS":""
     }
   }',1);
