/**业务数据源**/
INSERT INTO LISTTOOL_DATASOURCE_INFO(DS_ID, DS_NAME, DS_TYPE, DS_DESC, STATUS)
VALUES (1, 'listtool', 1, '列表管理平台数据库', 1);
/*demo*/
INSERT INTO LISTTOOL_DATASOURCE_INFO(DS_ID, DS_NAME, DS_TYPE, DS_DESC, STATUS)
VALUES (2, 'demo_apollo', 0, 'Demo新一站主库', 1);
INSERT INTO LISTTOOL_DATASOURCE_INFO(DS_ID, DS_NAME, DS_TYPE, DS_DESC, STATUS)
VALUES (3, 'demo_myins', 1, 'demo mysql主站数据库', 1);

/**认证**/
INSERT INTO LISTTOOL_APP_INFO(APP_ID, APP_NAME, APP_KEY, APP_SECRET, STATUS)
VALUES (1, 'LISTTOOL应用', 'listtoolKey', 'listtoolPwd', 1);
/*demo*/
INSERT INTO LISTTOOL_APP_INFO(APP_ID, APP_NAME, APP_KEY, APP_SECRET, STATUS)
VALUES (2, 'Demo应用', 'demoKey', 'demoPwd', 1);

/**列表**/
INSERT INTO LISTTOOL_LIST_INFO(LIST_ID, APP_ID, LIST_NAME, LIST_DESC, AUTH_TYPE, AUTH_EXPR, CONTEXT, STATUS)
VALUES (1, 1, '数据源列表', '数据源列表', 1, 'P(list:list:1)',
  '{
    "pipelines": [{
      "name": "execMapping",
      "type": "execMapping",
      "data": {
        "ds": "listtool",
        "mappingFields": ["_@_"]
      },
      "index":0
    },{
      "name": "execQl",
      "type": "execQl",
      "data": {
        "ds": "listtool",
        "ql": "SELECT DS_ID dsId,DS_NAME dsName,DS_TYPE dsType,DS_DESC dsDesc,STATUS status,CREATE_NAME createName,MODIFY_NAME modifyName,CREATE_TIME createTime,MODIFY_TIME modifyTime FROM LISTTOOL_DATASOURCE_INFO",
        "paging": 1,
        "queries": ["_@_"],
        "orders": ["_@_"]
      },
      "index": 1
    },{
      "name": "generateRes",
      "type": "generateRes",
      "index": 2
    }],
    "pagenator": {
       "pageSize": 10
    },
    "functions": [{
      "key":"add",
      "comType":"custom",
      "index":0
    },{
      "key":"exportData",
      "comType":"custom",
      "index":1
    },{
      "key":"importData",
      "comType":"custom",
      "index":2
    }],
    "fields": [{
      "key": "dsId",
      "label":"数据源ID",
      "remark":"请输入ID",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "input",
        "dataType": -5,
        "index":0
      },
      "result":{
        "order":1,
        "index":0
      }
    },{
      "key": "dsName",
      "label":"名称",
      "remark":"请输入名称",
      "search":{
        "match": {
          "0": "精确匹配",
          "1": "模糊匹配"
        },
        "eleType": "input",
        "dataType": 12,
        "index":1
      },
      "result":{
        "order":0,
        "index":1
      }
    },{
      "key": "dsDesc",
      "label":"描述信息",
      "remark":"描述信息",
      "result":{
        "order":0,
        "index":2
      }
    },{
      "key": "dsType",
      "label":"类型",
      "mapping": "json://{\\"0\\":\\"Oracle\\",\\"1\\":\\"Mysql\\"}",
      "remark":"请输入类型",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "select",
        "dataType": 4,
        "index":2
      },
      "result":{
        "order":0,
        "index":3
      }
    },{
      "key": "status",
      "label":"状态",
      "mapping": "json://{\\"0\\":\\"停用\\",\\"1\\":\\"启用\\"}",
      "remark":"请输入状态",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "select",
        "dataType": 4,
        "index":3
      },
      "result":{
        "order":0,
        "index":4
      }
    },{
      "key": "createName",
      "label":"添加人",
      "remark":"添加人",
      "result":{
        "order":0,
        "index":5
      }
    },{
      "key": "modifyName",
      "label":"修改人",
      "remark":"修改人",
      "result":{
        "order":0,
        "index":6
      }
    },{
      "key": "createTime",
      "label":"添加时间",
      "remark":"添加时间",
      "result":{
        "order":0,
        "index":7
      }
    },{
      "key": "modifyTime",
      "label":"修改时间",
      "remark":"修改时间",
      "result":{
        "order":1,
        "index":8
      }
    }]
	}', 1);

INSERT INTO LISTTOOL_LIST_INFO(LIST_ID, APP_ID, LIST_NAME, LIST_DESC, AUTH_TYPE, AUTH_EXPR, CONTEXT, STATUS)
VALUES (2, 1, '应用列表', '应用列表', 1, 'P(list:list:2)',
  '{
    "pipelines": [{
      "name": "execMapping",
      "type": "execMapping",
      "data": {
        "ds": "listtool",
        "mappingFields": ["_@_"]
      },
      "index":0
    },{
      "name": "execQl",
      "type": "execQl",
      "data": {
        "ds": "listtool",
        "ql": "SELECT APP_ID appId,APP_NAME appName,APP_KEY appKey,APP_SECRET appSecret,STATUS status,CREATE_NAME createName,MODIFY_NAME modifyName,CREATE_TIME createTime,MODIFY_TIME modifyTime FROM LISTTOOL_APP_INFO",
        "paging": 1,
        "queries": ["_@_"],
        "orders": ["_@_"]
      },
      "index": 1
    },{
      "name": "generateRes",
      "type": "generateRes",
      "index": 2
    }],
    "pagenator": {
      "pageSize": 10
    },
    "functions": [{
      "key":"add",
      "comType":"custom",
      "index":0
    },{
      "key":"exportData",
      "comType":"custom",
      "index":1
    },{
      "key":"importData",
      "comType":"custom",
      "index":2
    }],
    "fields": [{
      "key": "appId",
      "label":"应用ID",
      "remark":"请输入ID",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "input",
        "dataType": -5,
        "index":0
      },
      "result":{
        "order":1,
        "index":0
      }
    },{
      "key": "appName",
      "label":"名称",
      "remark":"请输入名称",
      "search":{
        "match": {
          "0": "精确匹配",
          "1": "模糊匹配"
        },
        "eleType": "input",
        "dataType": 12,
        "index":1
      },
      "result":{
        "order":0,
        "index":1
      }
    },{
      "key": "appKey",
      "label":"应用key",
      "remark":"应用key",
      "result":{
        "order":0,
        "index":2
      }
    },{
      "key": "appSecret",
      "label":"应用密钥",
      "remark":"应用密钥",
      "result":{
        "order":0,
        "index":3
      }
    },{
      "key": "status",
      "label":"状态",
      "mapping": "json://{\\"0\\":\\"停用\\",\\"1\\":\\"启用\\"}",
      "remark":"请输入状态",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "select",
        "dataType": 4,
        "index":2
      },
      "result":{
        "order":0,
        "index":4
      }
    },{
      "key": "createName",
      "label":"添加人",
      "remark":"添加人",
      "result":{
        "order":0,
        "index":5
      }
    },{
      "key": "modifyName",
      "label":"修改人",
      "remark":"修改人",
      "result":{
        "order":0,
        "index":6
      }
    },{
      "key": "createTime",
      "label":"添加时间",
      "remark":"添加时间",
      "result":{
        "order":0,
        "index":7
      }
    },{
      "key": "modifyTime",
      "label":"修改时间",
      "remark":"修改时间",
      "result":{
        "order":1,
        "index":8
      }
    }]
	}', 1);

INSERT INTO LISTTOOL_LIST_INFO(LIST_ID, APP_ID, LIST_NAME, LIST_DESC, AUTH_TYPE, AUTH_EXPR, CONTEXT, STATUS)
VALUES (3, 1, '配置列表列表', '配置列表列表', 1, 'P(list:list:3)',
  '{
    "pipelines": [{
      "name": "execMapping",
      "type": "execMapping",
      "data": {
        "ds": "listtool",
        "mappingFields": ["_@_"]
      },
      "index":0
    },{
      "name": "execQl",
      "type": "execQl",
      "data": {
        "ds": "listtool",
        "ql": "SELECT LIST_ID listId,LIST_NAME listName,LIST_DESC listDesc,AUTH_TYPE authType,AUTH_EXPR authExpr,APP_ID appId,STATUS status,CREATE_NAME createName,MODIFY_NAME modifyName,CREATE_TIME createTime,MODIFY_TIME modifyTime FROM LISTTOOL_LIST_INFO",
        "paging": 1,
        "queries": ["_@_"],
        "orders": ["_@_"]
      },
      "index": 1
    },{
      "name": "generateRes",
      "type": "generateRes",
      "index": 2
    }],
    "pagenator": {
      "pageSize": 10
    },
    "functions": [{
      "key":"add",
      "comType":"custom",
      "index":0
    },{
      "key":"exportData",
      "comType":"custom",
      "index":1
    },{
      "key":"importData",
      "comType":"custom",
      "index":2
    }],
    "fields": [{
      "key": "listId",
      "label":"列表ID",
      "remark":"请输入ID",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "input",
        "dataType": -5,
        "index":0
      },
      "result":{
        "order":1,
        "index":0
      }
    },{
      "key": "listName",
      "label":"名称",
      "remark":"请输入名称",
      "search":{
        "match": {
          "0":"精确匹配",
          "1":"模糊匹配"
        },
        "eleType": "input",
        "dataType": 12,
        "index":1
      },
      "result":{
        "order":0,
        "index":1
      }
    },{
      "key": "listDesc",
      "label":"描述信息",
      "remark":"描述信息",
      "result":{
        "order":0,
        "index":2
      }
    },{
      "key": "authType",
      "label":"认证类型",
      "mapping": "json://{\\"0\\":\\"none\\",\\"1\\":\\"medusa\\",\\"2\\":\\"custom\\"}",
      "remark":"认证类型",
      "search":{
        "match":{
          "0":"精确匹配"
        },
        "eleType": "select",
        "dataType": 4,
        "index":2
      },
      "result":{
        "order":0,
        "index":3
      }
    },{
      "key": "authExpr",
      "label":"medusa认证表达式",
      "remark":"medusa认证表达式",
      "result":{
        "order":0,
        "index":4
      }
    },{
      "key": "appId",
      "label":"应用ID",
      "mapping": "ql://select APP_ID,CONCAT(APP_ID,\'(\',APP_NAME,\')\') from LISTTOOL_APP_INFO",
      "remark":"应用ID",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "select",
        "dataType": 4,
        "index":3
      },
      "result":{
        "order":0,
        "index":5
      }
    },{
      "key": "status",
      "label":"状态",
      "mapping": "json://{\\"0\\":\\"停用\\",\\"1\\":\\"启用\\"}",
      "remark":"请输入状态",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "select",
        "dataType": 4,
        "index":4
      },
      "result":{
        "order":0,
        "index":6
      }
    },{
      "key": "createName",
      "label":"添加人",
      "remark":"添加人",
      "result":{
        "order":0,
        "index":7
      }
    },{
      "key": "modifyName",
      "label":"修改人",
      "remark":"修改人",
      "result":{
        "order":0,
        "index":8
      }
    },{
      "key": "createTime",
      "label":"添加时间",
      "remark":"添加时间",
      "result":{
        "order":0,
        "index":9
      }
    },{
      "key": "modifyTime",
      "label":"修改时间",
      "remark":"修改时间",
      "result":{
        "order":1,
        "index":10
      }
    }]
	}', 1);


INSERT INTO LISTTOOL_LIST_INFO(LIST_ID, APP_ID, LIST_NAME, LIST_DESC, AUTH_TYPE, AUTH_EXPR, CONTEXT, STATUS)
VALUES (33, 1, 'test33', 'test33', 1, 'P(list:list:33)',
  '{
    "pipelines": [{
      "name": "execMapping",
      "type": "execMapping",
      "data": {
        "ds": "listtool",
        "mappingFields": ["_@_"]
      },
      "index":0
    },{
      "name": "execQl",
      "type": "execQl",
      "data": {
        "ds": "listtool",
        "ql": "SELECT APP_ID appId,APP_NAME appName,APP_KEY appKey,APP_SECRET appSecret,STATUS status,CREATE_NAME createName,MODIFY_NAME modifyName,CREATE_TIME createTime,MODIFY_TIME modifyTime FROM LISTTOOL_APP_INFO",
        "paging": 1,
        "queries": ["_@_"],
        "orders": ["_@_"]
      },
      "index": 1
    },{
      "name": "generateRes",
      "type": "generateRes",
      "index": 2
    }],
    "pagenator": {
      "pageSize": 10
    },
    "functions": [{
      "key":"add",
      "comType":"custom",
      "index":0
    },{
      "key":"exportData",
      "comType":"custom",
      "index":1
    },{
      "key":"importData",
      "comType":"custom",
      "index":2
    }],
    "fields": [{
      "key": "appId",
      "label":"应用ID",
      "remark":"请输入ID",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "input",
        "dataType": -5,
        "index":0
      },
      "result":{
        "order":1,
        "index":0
      }
    },{
      "key": "appName",
      "label":"名称",
      "remark":"请输入名称",
      "search":{
        "match": {
          "0":"精确匹配",
          "1":"模糊匹配"
        },
        "eleType": "input",
        "dataType": 12,
        "index":1
      },
      "result":{
        "order":0,
        "index":1
      }
    },{
      "key": "appKey",
      "label":"应用key",
      "remark":"应用key",
      "result":{
        "order":0,
        "index":2
      }
    },{
      "key": "appSecret",
      "label":"应用密钥",
      "remark":"应用密钥",
      "result":{
        "order":0,
        "index":3
      }
    },{
      "key": "status",
      "label":"状态",
      "mapping": "json://{\\"0\\":\\"停用\\",\\"1\\":\\"启用\\"}",
      "remark":"请输入状态",
      "search":{
        "match": {
          "0":"精确匹配"
        },
        "eleType": "select",
        "dataType": 4,
        "index":2
      },
      "result":{
        "order":0,
        "index":4
      }
    },{
      "key": "createName",
      "label":"添加人",
      "remark":"添加人",
      "result":{
        "order":0,
        "index":5
      }
    },{
      "key": "modifyName",
      "label":"修改人",
      "remark":"修改人",
      "result":{
        "order":0,
        "index":6
      }
    },{
      "key": "createTime",
      "label":"添加时间",
      "remark":"添加时间",
      "result":{
        "order":0,
        "index":7
      }
    },{
      "key": "modifyTime",
      "label":"修改时间",
      "remark":"修改时间",
      "result":{
        "order":1,
        "index":8
      }
    }]
	}', 1);
