set define off;

--接口系统
insert into ins.base_config_info(config_id,group_id,data_id,data_value,description,md5)
values(S_BASE_CONFIG_INFO.nextval,'conf_sso_menuurl','list.development','http://list-d.xyz.cn','列表管理平台url(开发环境)','11d31efdb5b2b6ff22482fe5bd898a08');
insert into ins.base_config_info(config_id,group_id,data_id,data_value,description,md5)
values(S_BASE_CONFIG_INFO.nextval,'conf_sso_menuurl','list.test','http://list-t.xyz.cn','列表管理平台url(测试环境)','1964394f87788715f6c148282bbc92e6');
insert into ins.base_config_info(config_id,group_id,data_id,data_value,description,md5)
values(S_BASE_CONFIG_INFO.nextval,'conf_sso_menuurl','list.preview','http://plist.xyz.cn','列表管理平台url(P版环境)','abb016704e2c6ba2cd9d50eee73ba28d');
insert into ins.base_config_info(config_id,group_id,data_id,data_value,description,md5)
values(S_BASE_CONFIG_INFO.nextval,'conf_sso_menuurl','list','http://list.xyz.cn','列表管理平台url','6fcc43d3bfb8beec35cdc53d7333236b');


commit;
