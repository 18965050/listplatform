package cn.xyz.listtool.excel.xssf;

/**
 * @author lvchenggang.
 * @date 2020/5/21 10:43
 * @see
 * @since
 */
public class ExcelFileHeaderConstants {
    public static final String NAME = "NAME";
    public static final String NATIONAL_ID = "NID";
    public static final String AGE = "AGE";
    public static final String MOBILE = "MOBILE";
    public static final String EMAIL = "EMAIL";
    public static final String ADDRESS = "ADDRESS";
}
