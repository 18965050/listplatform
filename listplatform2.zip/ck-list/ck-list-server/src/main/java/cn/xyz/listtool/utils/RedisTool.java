package cn.xyz.listtool.utils;

import org.redisson.api.RBucket;
import org.redisson.api.RFuture;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * redis访问工具
 *
 * @author lvchenggang.
 * @date 2020/5/22 13:40
 * @see
 * @since
 */
@Service
public class RedisTool {

    @Autowired
    private RedissonClient redissonClient;

    public <T> T set(String name, T value, int expireTime, TimeUnit timeUnit) {
        RBucket<T> bucket = redissonClient.getBucket(name);
        bucket.set(value, expireTime, timeUnit);
        return bucket.get();
    }

    public <T> RFuture<Void> setAsync(String name, T value, int expireTime, TimeUnit timeUnit) {
        RBucket<T> bucket = redissonClient.getBucket(name);
        return bucket.setAsync(value, expireTime, timeUnit);
    }

    public <T> T get(String key) {
        RBucket<T> bucket = this.redissonClient.getBucket(key);
        return bucket.get();
    }

    public boolean tryLock(String key, int timeout, int expireTime, TimeUnit timeUnit) {
        RLock rLock = redissonClient.getLock(key);
        try {
            return rLock.tryLock(timeout, expireTime, timeUnit);
        } catch (InterruptedException e) {
            return false;
        }
    }

    public void unlock(String key) {
        RLock lock = redissonClient.getLock(key);
        lock.unlock();
    }

    public boolean isLock(String lockKey) {
        return redissonClient.getLock(lockKey).isLocked();
    }
}
