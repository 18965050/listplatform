package cn.xyz.listtool.aop;

import cn.xyz.io.admin.auth.api.base.dto.AuditDTO;
import cn.xyz.medusa.client.util.AuthUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 补充AuditDTO内容的切面
 *
 * @author lvchenggang.
 * @date 2019/12/4 11:22
 * @see
 * @since
 */
@Aspect
@Component
public class SupplyAuditInfoAspect {

    @Pointcut("@annotation(cn.xyz.listtool.aop.SupplyAudit)")
    public void methodPointCut() {
    }

    @Before(value = "methodPointCut() && @annotation(supplyAudit)", argNames = "jp,supplyAudit")
    public void before(JoinPoint jp, SupplyAudit supplyAudit) {
        //TODO: 未完成
        Object[] args = jp.getArgs();
        if (args != null && args.length >= 1 && args[0] instanceof AuditDTO) {
            AuditDTO auditDTO = (AuditDTO) args[0];
            Date date = new Date();
            switch (supplyAudit.value()) {
                case ADD:
                    auditDTO.setCreateId(AuthUtils.getCurrentPrincipal().getUserId());
                    auditDTO.setCreateName(AuthUtils.getCurrentPrincipal().getLoginName());
                    auditDTO.setCreateTime(date);
                    auditDTO.setModifyId(AuthUtils.getCurrentPrincipal().getUserId());
                    auditDTO.setModifyName(AuthUtils.getCurrentPrincipal().getLoginName());
                    auditDTO.setModifyTime(date);
                    break;
                case UPDATE:
                    auditDTO.setModifyId(AuthUtils.getCurrentPrincipal().getUserId());
                    auditDTO.setModifyName(AuthUtils.getCurrentPrincipal().getLoginName());
                    auditDTO.setModifyTime(date);
                    break;
                default:
                    throw new IllegalArgumentException("不应该出现这个异常");
            }
        }
    }
}
