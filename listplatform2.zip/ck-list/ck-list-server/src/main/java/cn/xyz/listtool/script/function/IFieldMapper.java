package cn.xyz.listtool.script.function;

import cn.xyz.chaos.mvc.web.api.BizException;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.api.FieldMappingProvider;
import cn.xyz.listtool.api.MappingContext;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.constant.Const.FIELD_MAPPING;
import cn.xyz.listtool.constant.Const.METRICS;
import cn.xyz.listtool.datasource.BizDataSource;
import cn.xyz.listtool.dto.SpecDTO;
import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.utils.ReferenceConfigCache;
import com.alibaba.dubbo.rpc.cluster.support.FailoverCluster;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Timer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

import static cn.xyz.listtool.constant.Const.COMMON_SPLITTER;
import static cn.xyz.listtool.constant.Const.DUBBO_CALL_TIMEOUT;

/**
 * <pre>
 *     字段映射器. 用于搜索和结果字段的映射,JSON map结构. 目前支持json://和ql://两种配置方式
 *     当用于搜索字段时, 返回K(实际值):V(字面值)集合
 *     当用于结果字段时, 用于页面字面值展示
 *
 *     注意:
 *     1. 不携带当前记录CONTEXT作为映射, 这点和IFieldFormat不同
 *     2. 若字段同时配置mapping和format, 则mapping配置无效!
 * </pre>
 *
 * @author lvchenggang.
 * @date 2020/1/2 18:12
 * @see
 * @since
 */
public interface IFieldMapper {
    String mapping(Long listId, String pipelineName, SpecDTO.FieldDTO fieldDTO, BizDataSource bizDS);
}

@Component
@Qualifier("jsonFieldMapper")
class JsonFieldMapper implements IFieldMapper {

    @Override
    public String mapping(Long listId, String pipelineName, SpecDTO.FieldDTO fieldDTO, BizDataSource bizDS) {
        String mapping = fieldDTO.getMapping();
        return mapping.trim().substring(FIELD_MAPPING.JSON.val().length());
    }
}

@Component
@Qualifier("qlFieldMapper")
class QlFieldMapper implements IFieldMapper {

    @Autowired
    private MeterRegistry meterRegistry;

    @Override
    public String mapping(Long listId, String pipelineName, SpecDTO.FieldDTO fieldDTO, BizDataSource bizDS) {
        String mapping = fieldDTO.getMapping();
        String ql = mapping.trim().substring(FIELD_MAPPING.QL.val().length());
        StringBuilder sb = new StringBuilder("{");
        ArrayList<Tag> tags = new ArrayList<>(2);
        METRICS.SEARCH_MAPPING.tags().forEach((tag) -> {
            if (tag.equals("dsName")) {
                tags.add(Tag.of(tag, bizDS.getDsName()));
            } else {
                tags.add(Tag.of(tag, listId + "-" + pipelineName + "-" + fieldDTO.getKey()));
            }
        });
        Timer.Sample invokerSample = Timer.start(meterRegistry);
        bizDS.getJdbcTemplate().query(ql, (rs, rowNum) -> {
            int columnCount = rs.getMetaData().getColumnCount();
            if (columnCount != 2) {
                throw new BizException(String.format("字段(%s)searchMapping返回数据结构不正确", fieldDTO.getKey()));
            } else {
                sb.append("\"" + rs.getObject(1) + "\":\"" + rs.getObject(2) + "\"" + COMMON_SPLITTER);
                return null;
            }
        });
        invokerSample.stop(meterRegistry.timer(METRICS.SEARCH_MAPPING.metric(), tags));
        //去除最后一个逗号
        sb.delete(sb.lastIndexOf(COMMON_SPLITTER), sb.length());
        sb.append("}");
        return sb.toString();
    }
}

@Component
@Qualifier("dubboFieldMapper")
class DubboFieldMapper implements IFieldMapper {

    @Autowired
    private ApplicationConfig applicationConfig;

    @Autowired
    private RegistryConfig registryConfig;

    @Autowired
    private JsonMapper jsonMapper;

    @Override
    public String mapping(Long listId, String pipelineName, SpecDTO.FieldDTO fieldDTO, BizDataSource bizDS) {
        String fieldFormat = fieldDTO.getResult().getFormat();
        String mappingJson = fieldFormat.trim().substring(Const.FIELD_FORMAT.DUBBO.val().length());
        MappingContext mappingContext = jsonMapper.fromJson(mappingJson, MappingContext.class);
        ReferenceConfig<FieldMappingProvider> reference = new ReferenceConfig<FieldMappingProvider>();
        reference.setApplication(applicationConfig);
        reference.setRegistry(registryConfig); // 多个注册中心可以用setRegistries()
        reference.setInterface(FieldMappingProvider.class);
        reference.setTimeout(DUBBO_CALL_TIMEOUT);
        reference.setCluster(FailoverCluster.NAME);

        // 设置分组
        reference.setGroup(mappingContext.getGroupName());
        reference.setCheck(false);
        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        FieldMappingProvider service = cache.get(reference);
        mappingContext.setListId(listId);
        mappingContext.setFieldKey(fieldDTO.getKey());
        return service.mappingField(mappingContext);
    }
}
