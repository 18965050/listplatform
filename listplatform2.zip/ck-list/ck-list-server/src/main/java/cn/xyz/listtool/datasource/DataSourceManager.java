package cn.xyz.listtool.datasource;

import cn.xyz.chaos.common.metrics.DruidMetricsInitialBean;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.management.web.dto.DataSourceDTO;
import cn.xyz.listtool.repository.DataSourceRepository;
import com.alibaba.druid.pool.DruidDataSource;
import com.ctrip.framework.apollo.ConfigService;
import io.micrometer.core.instrument.MeterRegistry;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.util.*;

/**
 * 列表数据源管理器. TODO: 暂不考虑DB外的数据源情况
 *
 * @author lvchenggang.
 * @date 2019/11/15 10:30
 * @see
 * @since
 */
@Component
@DependsOn("springContextUtils")
public class DataSourceManager implements InitializingBean, DisposableBean {

    Map<String/*dsName*/, BizDataSource> dsMap = new HashMap<>();

    @Autowired
    private MeterRegistry meterRegistry;

    @Autowired
    private DataSourceRepository dsRepo;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public void load() {
        Optional<List<DataSourceDTO>> dbDSListOption =
            Optional.ofNullable(this.dsRepo.selectAllByStatus(Const.STATUS.VALID.val()));
        dbDSListOption.ifPresent(dsList -> {
            dsList.forEach(dbDS -> {
                save(dbDS.getDsName(), dbDS.getDsType());
            });
        });
    }

    public void save(String dsName, Integer dsType) {
        String connUrl = ConfigService.getAppConfig().getProperty("ds." + dsName + ".connurl", null);
        String driver = ConfigService.getAppConfig().getProperty("ds." + dsName + ".driver", null);
        String userName = ConfigService.getAppConfig().getProperty("ds." + dsName + ".user", null);
        String password = ConfigService.getAppConfig().getProperty("ds." + dsName + ".pwd", null);
        if (StringUtils.isBlank(connUrl) || StringUtils.isBlank(driver) || StringUtils.isBlank(userName)
            || StringUtils.isBlank(password)) {
            this.logger.warn("列表数据源(" + dsName + ")配置信息不全,不能创建此DataSource");
        } else {
            //先删除
            this.remove(dsName);
            DruidDataSource ds = new DruidDataSource();
            ds.setUrl(connUrl);
            ds.setDriverClassName(driver);
            ds.setUsername(userName);
            ds.setPassword(password);

            // 初始连接数
            int initialSize =
                ConfigService.getAppConfig().getIntProperty("ds." + dsName + ".initialSize", 1);
            // 最大活跃连接数
            int maxActive =
                ConfigService.getAppConfig().getIntProperty("ds." + dsName + ".maxActive", 8);
            // 最小空闲连接数(不释放)
            int minIdle = ConfigService.getAppConfig().getIntProperty("ds." + dsName + ".minIdle", 1);
            // 获取连接时最大等待时间
            long maxWait =
                ConfigService.getAppConfig().getLongProperty("ds." + dsName + ".maxWait", 10000L);
            ds.setInitialSize(initialSize);
            ds.setMaxActive(maxActive);
            ds.setMinIdle(minIdle);
            ds.setMaxWait(maxWait);
            ds.setDefaultReadOnly(true);// hint: 只读
            try {
                ds.init();
            } catch (SQLException e) {
                logger.error("初始化DruidDataSource失败:", e);
                return;
            }
            JdbcTemplate jdbcTemplate = new JdbcTemplate(ds, false);
            BizDataSource bizDataSource = new BizDataSource(dsName, dsType, jdbcTemplate);
            dsMap.put(dsName, bizDataSource);

            //Metrics添加
            DruidMetricsInitialBean druidMetricsInitialBean = new DruidMetricsInitialBean();
            druidMetricsInitialBean.setMeterRegistry(meterRegistry);
            druidMetricsInitialBean.setDataSource(ds);
            Map<String, String> tagMap = new HashMap<>();
            tagMap.put(Const.METRICS.DS.tags().toArray(new String[0])[0], dsName);
            druidMetricsInitialBean.setTags(tagMap);
            druidMetricsInitialBean.afterPropertiesSet();
        }
    }

    public void remove(String dsName) {
        if (MapUtils.isNotEmpty(dsMap)) {
            BizDataSource bizDS = dsMap.remove(dsName);
            if (bizDS != null && bizDS.getJdbcTemplate() != null && bizDS.getJdbcTemplate().getDataSource() != null) {
                DruidDataSource ds = (DruidDataSource) bizDS.getJdbcTemplate().getDataSource();
                ds.close();
            }
            this.logger.info("删除数据源({})成功", dsName);
        }
    }

    public BizDataSource get(String dsName) {
        BizDataSource bizDS = this.dsMap.get(dsName);
        if (bizDS == null) {
            throw new IllegalArgumentException(String.format("未能找到%s对应的数据源", dsName));
        }
        return bizDS;
    }

    public Set<String> getDsNames() {
        return dsMap.keySet();
    }

    public void unload() {
        // TODO: 将来考虑非DB的ds释放
        dsMap.keySet().forEach(dsName -> {
            this.remove(dsName);
        });
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        this.load();
    }

    @Override
    public void destroy() throws Exception {
        this.unload();
    }
}
