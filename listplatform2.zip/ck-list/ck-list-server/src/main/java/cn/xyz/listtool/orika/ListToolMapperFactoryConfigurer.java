package cn.xyz.listtool.orika;

import cn.xyz.chaos.common.orika.XyzAbstractOrikaMapperFactoryConfigurer;
import cn.xyz.listtool.management.web.dto.AppDTO;
import cn.xyz.listtool.management.web.dto.DataSourceDTO;
import cn.xyz.listtool.management.web.dto.ListDTO;
import cn.xyz.listtool.repository.g.entity.ListtoolAppInfo;
import cn.xyz.listtool.repository.g.entity.ListtoolDatasourceInfo;
import cn.xyz.listtool.repository.g.entity.ListtoolListInfo;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.ConverterFactory;

/**
 * @author lvchenggang.
 * @date 2019/11/26 17:00
 * @see
 * @since
 */
public class ListToolMapperFactoryConfigurer extends XyzAbstractOrikaMapperFactoryConfigurer {

    @Override
    protected void addFluidMapper(MapperFactory mapperFactory) {
        mapperFactory.classMap(DataSourceDTO.class, ListtoolDatasourceInfo.class)
            .byDefault().register();

        mapperFactory.classMap(AppDTO.class, ListtoolAppInfo.class)
            .byDefault().register();

        mapperFactory.classMap(ListDTO.class, ListtoolListInfo.class)
            .byDefault().register();
    }

    @Override
    protected void addConverter(ConverterFactory converterFactory) {

    }
}
