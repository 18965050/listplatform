package cn.xyz.listtool.management.web.service;

import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.aop.SupplyAudit;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.management.web.dto.ListDTO;
import cn.xyz.listtool.repository.ListRepository;
import com.alicp.jetcache.Cache;
import com.alicp.jetcache.anno.CacheType;
import com.alicp.jetcache.anno.CreateCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR;
import static cn.xyz.listtool.aop.SupplyAudit.OpType.ADD;
import static cn.xyz.listtool.aop.SupplyAudit.OpType.UPDATE;
import static cn.xyz.listtool.constant.Const.CACHE_LIST_NAME;

/**
 * @author lvchenggang.
 * @date 2019/11/28 9:50
 * @see
 * @since
 */
@Service
public class ListService {

    @Autowired
    private ListRepository listRepo;

    @Autowired
    private JsonMapper jsonMapper;

    @CreateCache(name = CACHE_LIST_NAME, cacheType = CacheType.REMOTE)
    private Cache<Long, ListDTO> listCache;

    public ListDTO detail(Long listId) {
        return this.listRepo.selectByPrimaryKey(listId);
    }

    @SupplyAudit(ADD)
    public ListDTO add(ListDTO listDTO) {
        int i = this.listRepo.add(listDTO);
        if (i != 1) {
            throw new RuntimeException(String.format("添加业务列表(listName:%s)失败.", listDTO.getListName()));
        }
        listCache.computeIfAbsent(listDTO.getListId(), listRepo::selectByPrimaryKey);
        return listDTO;
    }

    @SupplyAudit(UPDATE)
    public ListDTO update(ListDTO listDTO) {
        int i = this.listRepo.update(listDTO, false);
        if (i != 1) {
            throw new RuntimeException(String.format("修改业务认证(listId:%d,listName:%s)失败.", listDTO.getListId(), listDTO.getListName()));
        }
        listCache.remove(listDTO.getListId());
        listCache.computeIfAbsent(listDTO.getListId(), listRepo::selectByPrimaryKey);
        return listDTO;
    }

    public ListDTO changeStatus(ListDTO listDTO) {
        int i = this.listRepo.update(listDTO, true);
        if (i != 1) {
            throw new RuntimeException(String.format("修改业务认证(listId:%d,listName:%s)失败.", listDTO.getListId(), listDTO.getListName()));
        }
        listCache.remove(listDTO.getListId());
        listCache.computeIfAbsent(listDTO.getListId(), listRepo::selectByPrimaryKey);
        return listDTO;
    }

    public String exportRows(List<Long> listIds) {
        List<ListDTO> listDTOS = this.listRepo.selectByListIds(listIds);
        StringBuilder sb = new StringBuilder("{\"" + Const.IMPORT_DATATYPE.LIST.val() + "\":");
        sb.append(jsonMapper.toJson(listDTOS));
        sb.append("}");
        return sb.toString();
    }

    public BaseResponseDTO<Void> importData(String json) {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        try {
            Map<String, List> map = jsonMapper.fromJson(json, Map.class);
            if (map.containsKey(Const.IMPORT_DATATYPE.LIST.val())) {
                List<ListDTO> listDTOS = new ArrayList<>();
                map.get(Const.IMPORT_DATATYPE.LIST.val()).forEach(listMap -> {
                    listDTOS.add(jsonMapper.fromJson(jsonMapper.toJson(listMap), ListDTO.class));
                });
                this.listRepo.importData(listDTOS);
            }
        } catch (Exception e) {
            baseResponseDTO.setRet(BIZ_ERROR.value());
            baseResponseDTO.addError(String.format("导入文件数据格式不正确或导入数据错误(errMsg:%s)", e.getMessage()));
        }
        return baseResponseDTO;
    }
}
