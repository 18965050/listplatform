package cn.xyz.listtool.management.web.dto;

import cn.xyz.io.admin.auth.api.base.dto.AuditDTO;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author lvchenggang.
 * @date 2019/11/26 16:44
 * @see
 * @since
 */
public class DataSourceDTO extends AuditDTO {

    @NotNull(message = "id不能为空", groups = {GroupAdd.class, GroupModify.class, GroupChangeStatus.class})
    private Long dsId;

    @NotBlank(message = "数据源名称不能为空", groups = {GroupAdd.class, GroupModify.class})
    private String dsName;

    @NotNull(message = "数据源类型不能为空", groups = {GroupAdd.class, GroupModify.class})
    private Integer dsType;

    private String dsDesc;

    @NotNull(message = "状态不能为空", groups = {GroupAdd.class, GroupModify.class, GroupChangeStatus.class})
    private Integer status;

    public Long getDsId() {
        return dsId;
    }

    public void setDsId(Long dsId) {
        this.dsId = dsId;
    }

    public String getDsName() {
        return dsName;
    }

    public void setDsName(String dsName) {
        this.dsName = dsName;
    }

    public Integer getDsType() {
        return dsType;
    }

    public void setDsType(Integer dsType) {
        this.dsType = dsType;
    }

    public String getDsDesc() {
        return dsDesc;
    }

    public void setDsDesc(String dsDesc) {
        this.dsDesc = dsDesc;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public interface GroupAdd {
    }


    public interface GroupModify {
    }

    public interface GroupChangeStatus {
    }
}
