package cn.xyz.listtool.repository.g.mapper;

import java.sql.JDBCType;
import java.util.Date;
import javax.annotation.Generated;
import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

public final class ListtoolDatasourceInfoDynamicSqlSupport {
    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.099+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    public static final ListtoolDatasourceInfo listtoolDatasourceInfo = new ListtoolDatasourceInfo();

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.1+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_ID")
    public static final SqlColumn<Long> dsId = listtoolDatasourceInfo.dsId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.101+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_NAME")
    public static final SqlColumn<String> dsName = listtoolDatasourceInfo.dsName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.101+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_TYPE")
    public static final SqlColumn<Integer> dsType = listtoolDatasourceInfo.dsType;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.102+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_DESC")
    public static final SqlColumn<String> dsDesc = listtoolDatasourceInfo.dsDesc;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.102+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.STATUS")
    public static final SqlColumn<Integer> status = listtoolDatasourceInfo.status;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.102+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_ID")
    public static final SqlColumn<Long> createId = listtoolDatasourceInfo.createId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.102+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_ID")
    public static final SqlColumn<Long> modifyId = listtoolDatasourceInfo.modifyId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.102+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_NAME")
    public static final SqlColumn<String> createName = listtoolDatasourceInfo.createName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.102+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_NAME")
    public static final SqlColumn<String> modifyName = listtoolDatasourceInfo.modifyName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.102+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_TIME")
    public static final SqlColumn<Date> createTime = listtoolDatasourceInfo.createTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.103+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_TIME")
    public static final SqlColumn<Date> modifyTime = listtoolDatasourceInfo.modifyTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.1+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    public static final class ListtoolDatasourceInfo extends SqlTable {
        public final SqlColumn<Long> dsId = column("DS_ID", JDBCType.BIGINT);

        public final SqlColumn<String> dsName = column("DS_NAME", JDBCType.VARCHAR);

        public final SqlColumn<Integer> dsType = column("DS_TYPE", JDBCType.TINYINT);

        public final SqlColumn<String> dsDesc = column("DS_DESC", JDBCType.VARCHAR);

        public final SqlColumn<Integer> status = column("STATUS", JDBCType.TINYINT);

        public final SqlColumn<Long> createId = column("CREATE_ID", JDBCType.BIGINT);

        public final SqlColumn<Long> modifyId = column("MODIFY_ID", JDBCType.BIGINT);

        public final SqlColumn<String> createName = column("CREATE_NAME", JDBCType.VARCHAR);

        public final SqlColumn<String> modifyName = column("MODIFY_NAME", JDBCType.VARCHAR);

        public final SqlColumn<Date> createTime = column("CREATE_TIME", JDBCType.TIMESTAMP);

        public final SqlColumn<Date> modifyTime = column("MODIFY_TIME", JDBCType.TIMESTAMP);

        public ListtoolDatasourceInfo() {
            super("LISTTOOL_DATASOURCE_INFO");
        }
    }
}