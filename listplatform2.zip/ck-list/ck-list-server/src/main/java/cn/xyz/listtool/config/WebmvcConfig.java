package cn.xyz.listtool.config;

import cn.xyz.chaos.common.utils.SpringContextUtils;
import cn.xyz.chaos.mvc.spring.DelegatingServletProxy;
import cn.xyz.chaos.mvc.web.api.ApiGenericHandlerExceptionResolver;
import cn.xyz.listtool.config.webmvc.MedusaAuthInterceptor;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.medusa.constants.MedusaConstants;
import cn.xyz.medusa.springboot.SpringBootMedusaShiroFilterFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * webmvc spring配置
 *
 * @author lvchenggang.
 * @date 2019/11/14 17:33
 * @see
 * @since
 */
@Configuration
public class WebmvcConfig {

    @Autowired
    private JsonMapper jsonMapper;

    private Logger logger = LoggerFactory.getLogger(this.getClass());


    /**
     * medusa认证
     *
     * @return
     */
    @ConditionalOnProperty(MedusaConstants.MEDUSA_BOOTSTRAP_ENABLED)
    @Bean("medusaShiroFilter")
    @DependsOn("springContextUtils")
    public SpringBootMedusaShiroFilterFactoryBean medusaShiroFilterFactoryBean() {
        SpringBootMedusaShiroFilterFactoryBean medusaShiroFilterFactoryBean = new SpringBootMedusaShiroFilterFactoryBean();
        Map<String, String> filterChainDefinitionMap = new LinkedHashMap<>();
        filterChainDefinitionMap.put("/auth", "authc");
        filterChainDefinitionMap.put("/logout", "logout");
        filterChainDefinitionMap.put("/listtool/medusa/**", "authc");
        filterChainDefinitionMap.put("/listtool/none/**", "anon");
        filterChainDefinitionMap.put("/listtool/custom/**", "anon");
        filterChainDefinitionMap.put("/listtool/**", "anon");
        filterChainDefinitionMap.put("/actuator/prometheus", "anon");
        filterChainDefinitionMap.put("/actuator/health", "anon");
        filterChainDefinitionMap.put("/**", "authc");
        medusaShiroFilterFactoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
        return medusaShiroFilterFactoryBean;
    }

    @Bean
    ServletRegistrationBean<DelegatingServletProxy> prometheusServletProxy() {
        ServletRegistrationBean servletRegistrationBean =
            new ServletRegistrationBean(new DelegatingServletProxy(), "/actuator/prometheus");
        servletRegistrationBean.setName("prometheusServlet");
        return servletRegistrationBean;
    }

    @Bean
    WebMvcConfigurer webMvcConfigurer() {
        WebMvcConfigurer webMvcConfigurer = new WebMvcConfigurer() {
            @Override
            public void addInterceptors(InterceptorRegistry registry) {
                registry.addInterceptor(SpringContextUtils.getBean("baseAuthInterceptor")).addPathPatterns(Const.URL_NONE_LIST_PATH + "/*");
                try {
                    MedusaAuthInterceptor medusaAuthInterceptor = SpringContextUtils.getBean("medusaAuthInterceptor");
                    registry.addInterceptor(medusaAuthInterceptor).addPathPatterns(Const.URL_MEDUSA_LIST_PATH + "/*");
                } catch (Exception e) {
                    logger.warn("未纳入medusa认证鉴权体系, 不能添加medusaAuthInterceptor");
                }
                registry.addInterceptor(SpringContextUtils.getBean("customAuthInterceptor")).addPathPatterns(Const.URL_CUSTOM_LIST_PATH + "/*");
            }

            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                    .allowedOrigins("*")
                    .allowedHeaders("*")
                    .allowedMethods("POST", "GET")
                    .allowCredentials(true);
            }

            @Override
            public void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> resolvers) {
                resolvers.add(new ApiGenericHandlerExceptionResolver(jsonMapper.getMapper()));
            }
        };
        return webMvcConfigurer;
    }
}
