package cn.xyz.listtool.web.dto;

import cn.xyz.listtool.dto.QueryDTO;
import cn.xyz.listtool.dto.ResultDTO;
import cn.xyz.listtool.dto.SpecDTO;
import cn.xyz.listtool.web.dto.TempsDTO.TempDTO;

import java.io.Serializable;
import java.util.List;

/**
 * 运行时上下文
 *
 * @author lvchenggang.
 * @date 2019/11/14 20:53
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class ContextDTO implements Serializable {

    private QueryDTO query;

    private SpecDTO spec;

    private List<TempDTO> temps;

    private ResultDTO result;

    public QueryDTO getQuery() {
        return query;
    }

    public void setQuery(QueryDTO query) {
        this.query = query;
    }

    public SpecDTO getSpec() {
        return spec;
    }

    public void setSpec(SpecDTO spec) {
        this.spec = spec;
    }

    public ResultDTO getResult() {
        return result;
    }

    public void setResult(ResultDTO result) {
        this.result = result;
    }

    public List<TempDTO> getTemps() {
        return temps;
    }

    public void setTemps(List<TempDTO> temps) {
        this.temps = temps;
    }
}
