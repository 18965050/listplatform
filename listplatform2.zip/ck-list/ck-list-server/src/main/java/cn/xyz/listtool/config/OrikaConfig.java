package cn.xyz.listtool.config;

import cn.xyz.chaos.common.orika.XyzOrikaMapperFactoryBuilderConfigurer;
import cn.xyz.listtool.orika.ListToolMapperFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * orika 配置
 *
 * @author lvchenggang.
 * @date 2019/4/8 10:49
 * @see
 * @since
 */

@Configuration
public class OrikaConfig {

    @Bean
    public ListToolMapperFactoryConfigurer listToolMapperFactoryConfigurer() {
        return new ListToolMapperFactoryConfigurer();
    }

    @Bean
    public XyzOrikaMapperFactoryBuilderConfigurer xyzOrikaMapperFactoryBuilderConfigurer() {
        return new XyzOrikaMapperFactoryBuilderConfigurer();
    }
}
