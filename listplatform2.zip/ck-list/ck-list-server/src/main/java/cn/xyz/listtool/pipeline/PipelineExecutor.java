package cn.xyz.listtool.pipeline;

import cn.xyz.chaos.common.utils.SpringContextUtils;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.constant.Const.CONTEXT;
import cn.xyz.listtool.dto.SpecDTO;
import cn.xyz.listtool.script.ScriptEngine;
import cn.xyz.listtool.script.function.ExecMappingFunction;
import cn.xyz.listtool.script.function.ExecQlFunction;
import cn.xyz.listtool.script.function.GenerateResFunction;
import cn.xyz.listtool.script.function.MergeTempResFunction;
import cn.xyz.listtool.web.dto.TempsDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 * pipeline 执行器
 * 暂时先实现最简单的方式
 * </pre>
 *
 * @author lvchenggang.
 * @date 2020/2/17 8:58
 * @see
 * @since
 */
@Component
public class PipelineExecutor {
    @Autowired
    @Qualifier("qlScriptEngine")
//    @Qualifier("jsScriptEngine")
    private ScriptEngine scriptEngine;

    @Autowired
    private JsonMapper jsonMapper;

    public void execPipeline(Map<String, Object> context) {
        SpecDTO specDTO = (SpecDTO) context.get(CONTEXT.SPEC.val());
        List<SpecDTO.PipeLineDTO> pipelines = specDTO.getPipelines();
        if (CollectionUtils.isNotEmpty(pipelines)) {
            pipelines.sort((p1, p2) -> {
                if (p1.getIndex() == null) {
                    return -1;
                } else if (p2.getIndex() == null) {
                    return 1;
                } else {
                    return p1.getIndex() < p2.getIndex() ? -1 : (p1.getIndex().intValue() == p2.getIndex() ? 0 : 1);
                }
            });
            for (SpecDTO.PipeLineDTO pipeLine : pipelines) {
                TempsDTO tempsDTO = (TempsDTO) context.get(CONTEXT.TEMPS.val());
                tempsDTO.setCurrentPipelineDTO(pipeLine);
                String pipeLineType = pipeLine.getType();
                if (StringUtils.isNotBlank(pipeLineType)) {
                    if (Const.PIPELINE_TYPE.SCRIPT.val().equals(pipeLineType)) {
                        this.scriptEngine.exec((String) pipeLine.getData(), context);
                    } else if (Const.PIPELINE_TYPE.EXECMAPPING.val().equals(pipeLineType)) {
                        ExecMappingParam execMappingParam = this.jsonMapper.fromJson(this.jsonMapper.toJson(pipeLine.getData()), ExecMappingParam.class);
                        ExecMappingFunction execMappingFunction = (ExecMappingFunction) SpringContextUtils.getBean(Const.PIPELINE_TYPE.EXECMAPPING.clz());
                        execMappingFunction.exec(context, pipeLine, execMappingParam);
                    } else if (Const.PIPELINE_TYPE.EXECQL.val().equals(pipeLineType)) {
                        ExecQlParam execQlParam = this.jsonMapper.fromJson(this.jsonMapper.toJson(pipeLine.getData()), ExecQlParam.class);
                        ExecQlFunction execQlFunction = (ExecQlFunction) SpringContextUtils.getBean(Const.PIPELINE_TYPE.EXECQL.clz());
                        execQlFunction.exec(context, pipeLine, execQlParam);
                    } else if (Const.PIPELINE_TYPE.MERGETEMPRES.val().equals(pipeLineType)) {
                        MergeTempResParam mergeTempResultParam = this.jsonMapper.fromJson(this.jsonMapper.toJson(pipeLine.getData()), MergeTempResParam.class);
                        MergeTempResFunction mergeTempResultFunction = (MergeTempResFunction) SpringContextUtils.getBean(Const.PIPELINE_TYPE.MERGETEMPRES.clz());
                        mergeTempResultFunction.exec(context, pipeLine, mergeTempResultParam);
                    } else if (Const.PIPELINE_TYPE.GENERATERES.val().equals(pipeLineType)) {
                        GenerateResFunction generateResultFunction = (GenerateResFunction) SpringContextUtils.getBean(Const.PIPELINE_TYPE.GENERATERES.clz());
                        generateResultFunction.exec(context, pipeLine, null);
                    }
                }
            }
        }
    }
}
