package cn.xyz.listtool.script.ql;

import cn.xyz.chaos.mvc.web.api.BizException;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.pipeline.ExecMappingParam;
import cn.xyz.listtool.pipeline.ExecQlParam;
import cn.xyz.listtool.pipeline.MergeTempResParam;
import cn.xyz.listtool.script.ScriptEngine;
import cn.xyz.listtool.script.function.FunctionUtils;
import com.ql.util.express.DefaultContext;
import com.ql.util.express.DynamicParamsUtil;
import com.ql.util.express.ExpressRunner;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * QL Express脚本引擎
 *
 * @author lvchenggang.
 * @date 2019/11/15 15:36
 * @see
 * @since
 */
@Component("qlScriptEngine")
public class QlScriptEngine implements ScriptEngine {

    private ExpressRunner runner;

    @Override
    public void setup() {
        runner = new ExpressRunner();
        // 开启函数动态参数调用
        DynamicParamsUtil.supportDynamicParams = true;
        // 自定义注册
        try {
            runner.addFunctionOfClassMethod("execMapping", FunctionUtils.class.getName(), "execMapping",
                new Class[]{Map.class, ExecMappingParam.class}, null);
            runner.addFunctionOfClassMethod("execQl", FunctionUtils.class.getName(), "execQl",
                new Class[]{Map.class, ExecQlParam.class}, null);
            runner.addFunctionOfClassMethod("mergeTempRes", FunctionUtils.class.getName(), "mergeTempRes",
                new Class[]{Map.class, MergeTempResParam.class}, null);
            runner.addFunctionOfClassMethod("generateRes", FunctionUtils.class.getName(), "generateRes",
                new Class[]{Map.class}, null);
            runner.addFunctionOfClassMethod("dubboCall", FunctionUtils.class.getName(), "dubboCall",
                new Class[]{String.class, String.class, Map.class}, null);
        } catch (Exception e) {
            logger.error("QL中添加自定义方法失败:", e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public <T> T exec(String express, Map<String, Object> context) {
        DefaultContext<String, Object> defaultContext = new DefaultContext<>();
        defaultContext.putAll(context);
        // 将自身放入, 便于脚本获取上下文
        defaultContext.put(Const.CONTEXT.SELF.val(), defaultContext);
        List<String> errList = new ArrayList<>();
        try {
            T rs = (T) runner.execute(express, defaultContext, errList, true, false);
            defaultContext.remove(Const.CONTEXT.SELF.val());
            context.putAll(defaultContext);
            return rs;
        } catch (Exception e) {
            logger.error("QL脚本引擎脚本执行失败:", e);
            String exMsg = e.getMessage();
            Throwable cause = e.getCause();
            if (cause != null) {
                exMsg = cause.getMessage();
                if (cause instanceof InvocationTargetException) {
                    exMsg = ((InvocationTargetException) cause).getTargetException().getMessage();
                }
            }
            throw new BizException(exMsg);
        }
    }
}
