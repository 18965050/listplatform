package cn.xyz.listtool.repository.g.mapper;

import static cn.xyz.listtool.repository.g.mapper.ListtoolDatasourceInfoDynamicSqlSupport.*;
import static org.mybatis.dynamic.sql.SqlBuilder.*;

import cn.xyz.chaos.orm.mybatis.MyBatisRepository;
import cn.xyz.listtool.repository.g.entity.ListtoolDatasourceInfo;
import java.util.List;
import java.util.function.Function;
import javax.annotation.Generated;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.dynamic.sql.SqlBuilder;
import org.mybatis.dynamic.sql.delete.DeleteDSL;
import org.mybatis.dynamic.sql.delete.MyBatis3DeleteModelAdapter;
import org.mybatis.dynamic.sql.delete.render.DeleteStatementProvider;
import org.mybatis.dynamic.sql.insert.render.InsertStatementProvider;
import org.mybatis.dynamic.sql.render.RenderingStrategy;
import org.mybatis.dynamic.sql.select.MyBatis3SelectModelAdapter;
import org.mybatis.dynamic.sql.select.QueryExpressionDSL;
import org.mybatis.dynamic.sql.select.SelectDSL;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.update.MyBatis3UpdateModelAdapter;
import org.mybatis.dynamic.sql.update.UpdateDSL;
import org.mybatis.dynamic.sql.update.render.UpdateStatementProvider;
import org.mybatis.dynamic.sql.util.SqlProviderAdapter;

@Mapper
@MyBatisRepository
public interface ListtoolDatasourceInfoMapper {
    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.104+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    long count(SelectStatementProvider selectStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.105+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    @DeleteProvider(type=SqlProviderAdapter.class, method="delete")
    int delete(DeleteStatementProvider deleteStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.106+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    @InsertProvider(type=SqlProviderAdapter.class, method="insert")
    int insert(InsertStatementProvider<ListtoolDatasourceInfo> insertStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.107+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @ResultMap("ListtoolDatasourceInfoResult")
    ListtoolDatasourceInfo selectOne(SelectStatementProvider selectStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.108+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @ResultMap("ListtoolDatasourceInfoResult")
    List<ListtoolDatasourceInfo> selectManyWithRowbounds(SelectStatementProvider selectStatement, RowBounds rowBounds);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.11+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default Function<SelectStatementProvider, List<ListtoolDatasourceInfo>> selectManyWithRowbounds(RowBounds rowBounds) {
        return selectStatement -> selectManyWithRowbounds(selectStatement, rowBounds);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.108+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @Results(id="ListtoolDatasourceInfoResult", value = {
        @Result(column="DS_ID", property="dsId", jdbcType=JdbcType.BIGINT, id=true),
        @Result(column="DS_NAME", property="dsName", jdbcType=JdbcType.VARCHAR),
        @Result(column="DS_TYPE", property="dsType", jdbcType=JdbcType.TINYINT),
        @Result(column="DS_DESC", property="dsDesc", jdbcType=JdbcType.VARCHAR),
        @Result(column="STATUS", property="status", jdbcType=JdbcType.TINYINT),
        @Result(column="CREATE_ID", property="createId", jdbcType=JdbcType.BIGINT),
        @Result(column="MODIFY_ID", property="modifyId", jdbcType=JdbcType.BIGINT),
        @Result(column="CREATE_NAME", property="createName", jdbcType=JdbcType.VARCHAR),
        @Result(column="MODIFY_NAME", property="modifyName", jdbcType=JdbcType.VARCHAR),
        @Result(column="CREATE_TIME", property="createTime", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="MODIFY_TIME", property="modifyTime", jdbcType=JdbcType.TIMESTAMP)
    })
    List<ListtoolDatasourceInfo> selectMany(SelectStatementProvider selectStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.111+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    @UpdateProvider(type=SqlProviderAdapter.class, method="update")
    int update(UpdateStatementProvider updateStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.111+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<Long>> countByExample() {
        return SelectDSL.selectWithMapper(this::count, SqlBuilder.count())
                .from(listtoolDatasourceInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.112+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default DeleteDSL<MyBatis3DeleteModelAdapter<Integer>> deleteByExample() {
        return DeleteDSL.deleteFromWithMapper(this::delete, listtoolDatasourceInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.113+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default int deleteByPrimaryKey(Long dsId_) {
        return DeleteDSL.deleteFromWithMapper(this::delete, listtoolDatasourceInfo)
                .where(dsId, isEqualTo(dsId_))
                .build()
                .execute();
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.156+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default int insert(ListtoolDatasourceInfo record) {
        return insert(SqlBuilder.insert(record)
                .into(listtoolDatasourceInfo)
                .map(dsId).toProperty("dsId")
                .map(dsName).toProperty("dsName")
                .map(dsType).toProperty("dsType")
                .map(dsDesc).toProperty("dsDesc")
                .map(status).toProperty("status")
                .map(createId).toProperty("createId")
                .map(modifyId).toProperty("modifyId")
                .map(createName).toProperty("createName")
                .map(modifyName).toProperty("modifyName")
                .map(createTime).toProperty("createTime")
                .map(modifyTime).toProperty("modifyTime")
                .build()
                .render(RenderingStrategy.MYBATIS3));
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.157+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default int insertSelective(ListtoolDatasourceInfo record) {
        return insert(SqlBuilder.insert(record)
                .into(listtoolDatasourceInfo)
                .map(dsId).toPropertyWhenPresent("dsId", record::getDsId)
                .map(dsName).toPropertyWhenPresent("dsName", record::getDsName)
                .map(dsType).toPropertyWhenPresent("dsType", record::getDsType)
                .map(dsDesc).toPropertyWhenPresent("dsDesc", record::getDsDesc)
                .map(status).toPropertyWhenPresent("status", record::getStatus)
                .map(createId).toPropertyWhenPresent("createId", record::getCreateId)
                .map(modifyId).toPropertyWhenPresent("modifyId", record::getModifyId)
                .map(createName).toPropertyWhenPresent("createName", record::getCreateName)
                .map(modifyName).toPropertyWhenPresent("modifyName", record::getModifyName)
                .map(createTime).toPropertyWhenPresent("createTime", record::getCreateTime)
                .map(modifyTime).toPropertyWhenPresent("modifyTime", record::getModifyTime)
                .build()
                .render(RenderingStrategy.MYBATIS3));
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.158+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolDatasourceInfo>>> selectByExample(RowBounds rowBounds) {
        return SelectDSL.selectWithMapper(selectManyWithRowbounds(rowBounds), dsId, dsName, dsType, dsDesc, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolDatasourceInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.158+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolDatasourceInfo>>> selectByExample() {
        return SelectDSL.selectWithMapper(this::selectMany, dsId, dsName, dsType, dsDesc, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolDatasourceInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.16+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolDatasourceInfo>>> selectDistinctByExample(RowBounds rowBounds) {
        return SelectDSL.selectDistinctWithMapper(selectManyWithRowbounds(rowBounds), dsId, dsName, dsType, dsDesc, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolDatasourceInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.16+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolDatasourceInfo>>> selectDistinctByExample() {
        return SelectDSL.selectDistinctWithMapper(this::selectMany, dsId, dsName, dsType, dsDesc, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolDatasourceInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.161+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default ListtoolDatasourceInfo selectByPrimaryKey(Long dsId_) {
        return SelectDSL.selectWithMapper(this::selectOne, dsId, dsName, dsType, dsDesc, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolDatasourceInfo)
                .where(dsId, isEqualTo(dsId_))
                .build()
                .execute();
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.163+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default UpdateDSL<MyBatis3UpdateModelAdapter<Integer>> updateByExample(ListtoolDatasourceInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolDatasourceInfo)
                .set(dsId).equalTo(record::getDsId)
                .set(dsName).equalTo(record::getDsName)
                .set(dsType).equalTo(record::getDsType)
                .set(dsDesc).equalTo(record::getDsDesc)
                .set(status).equalTo(record::getStatus)
                .set(createId).equalTo(record::getCreateId)
                .set(modifyId).equalTo(record::getModifyId)
                .set(createName).equalTo(record::getCreateName)
                .set(modifyName).equalTo(record::getModifyName)
                .set(createTime).equalTo(record::getCreateTime)
                .set(modifyTime).equalTo(record::getModifyTime);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.164+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default UpdateDSL<MyBatis3UpdateModelAdapter<Integer>> updateByExampleSelective(ListtoolDatasourceInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolDatasourceInfo)
                .set(dsId).equalToWhenPresent(record::getDsId)
                .set(dsName).equalToWhenPresent(record::getDsName)
                .set(dsType).equalToWhenPresent(record::getDsType)
                .set(dsDesc).equalToWhenPresent(record::getDsDesc)
                .set(status).equalToWhenPresent(record::getStatus)
                .set(createId).equalToWhenPresent(record::getCreateId)
                .set(modifyId).equalToWhenPresent(record::getModifyId)
                .set(createName).equalToWhenPresent(record::getCreateName)
                .set(modifyName).equalToWhenPresent(record::getModifyName)
                .set(createTime).equalToWhenPresent(record::getCreateTime)
                .set(modifyTime).equalToWhenPresent(record::getModifyTime);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.165+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default int updateByPrimaryKey(ListtoolDatasourceInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolDatasourceInfo)
                .set(dsName).equalTo(record::getDsName)
                .set(dsType).equalTo(record::getDsType)
                .set(dsDesc).equalTo(record::getDsDesc)
                .set(status).equalTo(record::getStatus)
                .set(createId).equalTo(record::getCreateId)
                .set(modifyId).equalTo(record::getModifyId)
                .set(createName).equalTo(record::getCreateName)
                .set(modifyName).equalTo(record::getModifyName)
                .set(createTime).equalTo(record::getCreateTime)
                .set(modifyTime).equalTo(record::getModifyTime)
                .where(dsId, isEqualTo(record::getDsId))
                .build()
                .execute();
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.167+08:00", comments="Source Table: listtool..LISTTOOL_DATASOURCE_INFO")
    default int updateByPrimaryKeySelective(ListtoolDatasourceInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolDatasourceInfo)
                .set(dsName).equalToWhenPresent(record::getDsName)
                .set(dsType).equalToWhenPresent(record::getDsType)
                .set(dsDesc).equalToWhenPresent(record::getDsDesc)
                .set(status).equalToWhenPresent(record::getStatus)
                .set(createId).equalToWhenPresent(record::getCreateId)
                .set(modifyId).equalToWhenPresent(record::getModifyId)
                .set(createName).equalToWhenPresent(record::getCreateName)
                .set(modifyName).equalToWhenPresent(record::getModifyName)
                .set(createTime).equalToWhenPresent(record::getCreateTime)
                .set(modifyTime).equalToWhenPresent(record::getModifyTime)
                .where(dsId, isEqualTo(record::getDsId))
                .build()
                .execute();
    }
}