package cn.xyz.listtool.web.service;

import cn.xyz.chaos.common.utils.encrypt.EncryptorUtils;
import cn.xyz.chaos.mvc.web.api.AuthenticationException;
import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.chaos.mvc.web.api.BizException;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.auth.AuthChecker;
import cn.xyz.listtool.auth.AuthenDTO;
import cn.xyz.listtool.dto.*;
import cn.xyz.listtool.management.web.dto.AppDTO;
import cn.xyz.listtool.management.web.dto.ListDTO;
import cn.xyz.listtool.pipeline.PipelineExecutor;
import cn.xyz.listtool.repository.AppRepository;
import cn.xyz.listtool.repository.ListRepository;
import cn.xyz.listtool.script.function.FunctionUtils;
import cn.xyz.listtool.utils.ExportUtils;
import cn.xyz.listtool.utils.RedisTool;
import cn.xyz.listtool.web.dto.TempsDTO;
import com.alibaba.dubbo.common.utils.NamedThreadFactory;
import com.alibaba.dubbo.config.annotation.Reference;
import com.ctrip.framework.apollo.ConfigService;
import com.focustech.ins.metis.mount.file.File2Provider;
import com.focustech.ins.metis.mount.file.FileConstants;
import com.focustech.ins.metis.mount.file.dto.FileDTO;
import org.apache.cassandra.extend.client.FFSClient;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.shiro.authz.AuthorizationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import static cn.xyz.chaos.common.utils.encrypt.Encryptor.ALGORITHM.PBEWithMD5AndDES;
import static cn.xyz.listtool.ListConst.LIST_OPER.*;
import static cn.xyz.listtool.constant.Const.*;

/**
 * 列表 Service
 *
 * @author lvchenggang.
 * @date 2019/11/18 10:05
 * @see
 * @since
 */
@Service
public class ListtoolService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ListRepository listRepo;

    @Autowired
    private AppRepository appRepo;

    @Autowired
    private JsonMapper jsonMapper;

    @Autowired
    private PipelineExecutor plExec;

    @Autowired
    private AuthChecker authChecker;

    @Autowired
    private RedisTool redisTool;

    @Reference(check = false)
    private File2Provider file2Provider;

    @Autowired
    private FFSClient ffsClient;

    private ThreadPoolExecutor exportSendExecutor = new ThreadPoolExecutor(5, 30, 60L, TimeUnit.SECONDS,
        new LinkedBlockingQueue<Runnable>(),
        new NamedThreadFactory("exportSender", true));

    private ThreadPoolExecutor exportReceiveExecutor = new ThreadPoolExecutor(5, 30, 60L, TimeUnit.SECONDS,
        new LinkedBlockingQueue<Runnable>(),
        new NamedThreadFactory("exportReciever", true));

    /**
     * 当queryDTO不够完整时进行完善
     *
     * @param queryDTO
     */
    public static void requisiteQueryDTO(QueryDTO queryDTO, Long listId) {
        if (queryDTO.getPagenator() == null) {
            queryDTO.setPagenator(new PageDTO());
        }
        if (MapUtils.isEmpty(queryDTO.getOper())) {
            Map<String, Integer> oper = new HashMap<>();
            oper.put(EXEC_YES.key(), EXEC_YES.val());
            queryDTO.setOper(oper);
        }
        if (!queryDTO.getOper().containsKey(EXEC_YES.key())) {
            queryDTO.getOper().put(EXEC_YES.key(), EXEC_YES.val());
        }
    }

    public String getAuthPath(Long listId, boolean isExport) {
        ListDTO listDTO = listRepo.selectByPrimaryKey(listId);
        if (listDTO == null) {
            throw new BizException("配置列表不存在");
        }
        try {
            return isExport ? AUTH_TYPE.pathFromVal(listDTO.getAuthType()) + "export/" : AUTH_TYPE.pathFromVal(listDTO.getAuthType());
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

    public BaseResponseDTO<Map<String, Map<String, Object>>> pipelineDebug(ListDTO debugListDTO) {
        BaseResponseDTO<Map<String, Map<String, Object>>> baseResponseDTO = new BaseResponseDTO<>();
        // (1) 组装context
        Map<String, Object> context = new HashMap<>();
        context.put(CONTEXT.QUERY.val(), debugListDTO.getQueryDTO());
        if (debugListDTO == null || StringUtils.isBlank(debugListDTO.getContext())) {
            baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
            baseResponseDTO.addError("列表配置有缺失");
            return baseResponseDTO;
        }

        try {
            context.put(CONTEXT.ID.val(), debugListDTO.getListId());
            context.put(CONTEXT.SPEC.val(), jsonMapper.fromJson(debugListDTO.getContext(), SpecDTO.class));
        } catch (RuntimeException e) {
            baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
            baseResponseDTO.addError("列表context配置不符合JSON规范,无法解析");
            return baseResponseDTO;
        }
        TempsDTO tempsDTO = new TempsDTO();
        context.put(CONTEXT.TEMPS.val(), tempsDTO);
        Map<String, Map<String, Object>> logMap = new LinkedHashMap<>();
        context.put(CONTEXT.LOG.val(), logMap);
        //(1) pipeline执行,执行结果放入context的temps部分
        try {
            plExec.execPipeline(context);
        } catch (Exception e) {
            this.logger.warn("pipiline调试报错", e);
            SpecDTO.PipeLineDTO currentPipeline = FunctionUtils.getCurrentPipeline(context);
            Map<String, Object> pipelineLogMap = logMap.get(currentPipeline.getName());
            if (MapUtils.isEmpty(pipelineLogMap)) {
                pipelineLogMap = new LinkedHashMap<>();
                logMap.put(currentPipeline.getName(), pipelineLogMap);
            }
            pipelineLogMap.put("exception", e.getMessage());
        } finally {
            baseResponseDTO.setData(logMap);
            return baseResponseDTO;
        }
    }

    public <T> BaseResponseDTO<T> serverDataHandler(HttpServletResponse response, String token, Long listId, ServerQueryDTO serverQueryDTO) {
        ListDTO listDTO = this.listRepo.selectByPrimaryKey(listId);
        if (listDTO == null) {
            throw new BizException(String.format("列表(listId:%d)不存在", listId));
        }
        AppDTO appDTO = appRepo.selectByPrimaryKey(listDTO.getAppId());
        boolean pass = this.authChecker.tokenCheck(token, appDTO);
        if (!pass) {
            throw new AuthenticationException("认证失败");
        }

        if (listDTO.getAuthType() == AUTH_TYPE.MEDUSA.val()) {
            Long userId = serverQueryDTO.getUserId();
            //不能将authChecker.getAuthenDTOByUserId放在authChecker.serviceAuthCheck中调用, 否则缓存失效
            AuthenDTO authenDTO = this.authChecker.getAuthenDTOByUserId(userId);
            pass = this.authChecker.serviceAuthCheck(authenDTO, listDTO.getAuthExpr());
            if (!pass) {
                throw new AuthorizationException("medusa鉴权失败");
            }
        }
        QueryDTO queryDTO = serverQueryDTO.getQueryDTO();
        String exportToken = serverQueryDTO.getExportToken();
        //判断数据查询还是数据导出
        if (queryDTO.getOper().containsKey(EXPORT_YES.key()) && EXPORT_YES.val() == queryDTO.getOper().get(EXPORT_YES.key())) {
            return (BaseResponseDTO<T>) this.export(listId, null, queryDTO, exportToken);
        } else {
            return (BaseResponseDTO<T>) this.pageList(listId, null, queryDTO);
        }
    }

    public BaseResponseDTO<ResultDTO> pageList(Long listId, ListDTO debugListDTO, QueryDTO queryDTO) {
        BaseResponseDTO<ResultDTO> baseResponseDTO = new BaseResponseDTO<>();
        // (1) 组装context
        Map<String, Object> context = new HashMap<>();
        context.put(CONTEXT.QUERY.val(), queryDTO);
        ListDTO execListDTO = debugListDTO;
        Long execListId = listId;
        if (listId != null) {
            execListDTO = listRepo.selectByPrimaryKey(listId);
        } else if (debugListDTO != null) {
            execListId = debugListDTO.getListId();
        }
        if (execListDTO == null || StringUtils.isBlank(execListDTO.getContext())) {
            baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
            baseResponseDTO.addError(String.format("列表(listId:%d)配置有缺失", execListId));
            return baseResponseDTO;
        }

        context.put(CONTEXT.ID.val(), execListId);
        SpecDTO specDTO = null;
        try {
            specDTO = jsonMapper.fromJson(execListDTO.getContext(), SpecDTO.class);
            context.put(CONTEXT.SPEC.val(), specDTO);
        } catch (RuntimeException e) {
            baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
            baseResponseDTO.addError(String.format("列表(listId:%d)context配置不符合JSON规范:" + e.getMessage(), execListId));
            return baseResponseDTO;
        }
        TempsDTO tempsDTO = new TempsDTO();
        context.put(CONTEXT.TEMPS.val(), tempsDTO);
        Map<String, Map<String, Object>> logMap = new LinkedHashMap<>();
        context.put(CONTEXT.LOG.val(), logMap);
        //(1) pipeline执行,执行结果放入context的temps部分
        plExec.execPipeline(context);
        // (2)获取列表结果
        ResultDTO resultDTO = (ResultDTO) context.get(CONTEXT.RESULT.val());
        if (resultDTO == null) {
            resultDTO = new ResultDTO();
            if (specDTO != null) {
                resultDTO.setSpec(specDTO);
                resultDTO.setPagenator(specDTO.getPagenator());
            }
            resultDTO.setQuery(queryDTO);
        }
        baseResponseDTO.setData(resultDTO);
        baseResponseDTO.getData().setTitle(execListDTO.getListName());
        return baseResponseDTO;
    }

    public BaseResponseDTO<ExportDTO> exportPreCheck(Long listId, ListDTO debugListDTO, QueryDTO queryDTO) {
        BaseResponseDTO<ExportDTO> baseResponseDTO = new BaseResponseDTO<>();
        BaseResponseDTO<ResultDTO> exportResDTO = this.pageList(listId, debugListDTO, queryDTO);
        if (BaseResponseDTO.DEFAULT_RESPONSE_RESULT.SUCCESS.value() != exportResDTO.getRet()) {
            baseResponseDTO.setRet(exportResDTO.getRet());
            baseResponseDTO.addErrors(exportResDTO.getMsg());
            return baseResponseDTO;
        }
        // 校验导出上限
        PageDTO pagenator = exportResDTO.getData().getPagenator();
        int exportCountshreshhold = ConfigService.getAppConfig().getIntProperty("export.count.shreshhold", 1000);
        if (pagenator.getTotalCount() > exportCountshreshhold) {
            baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
            baseResponseDTO.addError(String.format("导出数据超过上限(%d)条", exportCountshreshhold));
            return baseResponseDTO;
        }
        //检验是否处于锁定状态
        String lockKey = ExportUtils.lockKey(listId);
        if (this.redisTool.isLock(lockKey)) {
            baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
            baseResponseDTO.addError("导出状态被锁定, 请稍后再试");
            return baseResponseDTO;
        }
        ExportDTO exportDTO = new ExportDTO();
        exportDTO.setTotalCount(pagenator.getTotalCount());
        baseResponseDTO.setData(exportDTO);
        return baseResponseDTO;
    }

    public BaseResponseDTO<ExportDTO> export(Long listId, ListDTO debugListDTO, QueryDTO queryDTO, String exportToken) {
        BaseResponseDTO<ExportDTO> baseResponseDTO = new BaseResponseDTO<>();
        if (StringUtils.isBlank(exportToken)) {
            BaseResponseDTO<ExportDTO> checkResDTO = this.exportPreCheck(listId, null, queryDTO);
            if (BaseResponseDTO.DEFAULT_RESPONSE_RESULT.SUCCESS.value() != checkResDTO.getRet()) {
                baseResponseDTO.setRet(checkResDTO.getRet());
                baseResponseDTO.addErrors(checkResDTO.getMsg());
                return baseResponseDTO;
            }
            String exportTokenKey = String.format("%d_%s", listId, DateFormatUtils.format(new Date(), "yyyymmddHHmmss"));
            this.exportSendExecutor.execute(() -> {
                String lockKey = ExportUtils.lockKey(listId);
                Integer expireTime = ConfigService.getAppConfig().getIntProperty("export.lock.expireTime", 5 * 60);
                boolean isLock = redisTool.tryLock(lockKey, 0, expireTime, TimeUnit.SECONDS);
                if (isLock) {
                    try {
                        doExport(listId, debugListDTO, queryDTO, checkResDTO.getData().getTotalCount(), exportTokenKey);
                    } finally {
                        redisTool.unlock(lockKey);
                    }
                }
            });
            ExportDTO exportDTO = new ExportDTO();
            exportDTO.setExportToken(exportTokenKey);
            baseResponseDTO.setData(exportDTO);
            return baseResponseDTO;
        } else {
            //检查导出状态
            String downloadToken = this.redisTool.get(exportToken);
            Long fileId = this.authChecker.decryptDownloadToken(downloadToken);
            if (fileId == null) {
                //通过锁判断是否为恶意导出
                String lockKey = ExportUtils.lockKey(listId);
                if (!this.redisTool.isLock(lockKey)) {
                    baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
                    baseResponseDTO.addError("导出token无效或已失效,请重新导出");
                    return baseResponseDTO;
                } else {
                    //导出进行中
                    return baseResponseDTO;
                }
            } else {
                //判断导出过程是否正常
                if (fileId == ERR_FILE_ID) {
                    baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
                    baseResponseDTO.addError("导出过程出现异常");
                    return baseResponseDTO;
                } else {
                    ExportDTO exportDTO = new ExportDTO();
                    String downloadUrl = ConfigService.getAppConfig().getProperty("listtool.download.url", "http://list.xyz.cn/api/listtool/exportDownload");
                    downloadUrl = String.format("%s/%d?downloadToken=%s", downloadUrl, listId, downloadToken);
                    exportDTO.setDownloadUrl(downloadUrl);
                    baseResponseDTO.setData(exportDTO);
                    return baseResponseDTO;
                }

            }
        }
    }

    private void doExport(Long listId, ListDTO debugListDTO, QueryDTO queryDTO, Integer totalCount, String exportToken) {
        int pageSize = ConfigService.getAppConfig().getIntProperty("export.batch.size", 10000);
        int pageCount = totalCount % pageSize > 0 ? totalCount / pageSize + 1 : totalCount / pageSize;
        if (pageCount > 0) {
            ListDTO listDTO = this.listRepo.selectByPrimaryKey(listId);
            FileDTO fileDTO = new FileDTO();
            fileDTO.setName(listDTO.getListName());
            fileDTO.setExtension("xlsx");
            fileDTO.setLocation(FileConstants.LOCATION_FFS.key());
            fileDTO.setAuthority(FileConstants.AUTHORITY_YES.key());
            fileDTO.setStatus(FileConstants.STATUS_VALID.key());
            FileDTO fileDTO2 = this.file2Provider.createNoStore(fileDTO);
            Long fileId = fileDTO2.getId();
            String downloadToken = EncryptorUtils.encrypt(fileId + PARAM_VALUE_SPLITTER + System.currentTimeMillis(), DOWNLOAD_TOKEN_PWD, PBEWithMD5AndDES);

            PipedInputStream pis = new PipedInputStream();
            PipedOutputStream pos = null;
            SXSSFWorkbook workbook = null;
            try {
                pos = new PipedOutputStream(pis);
                workbook = new SXSSFWorkbook(1000);
                SXSSFSheet wbSheet = null;
                CellStyle dataCellStyle = workbook.createCellStyle();
                dataCellStyle.setAlignment(HorizontalAlignment.CENTER);//水平居中
                dataCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//垂直居中
                Font dataFont = workbook.createFont();
                dataFont.setFontHeightInPoints((short) 12);
                dataCellStyle.setFont(dataFont);
                int dataIndex = 2;
                for (int i = 1; i <= pageCount; i++) {
                    PageDTO pageDTO = new PageDTO();
                    pageDTO.setPageIndex(i);
                    pageDTO.setPageSize(pageSize);
                    queryDTO.setPagenator(pageDTO);
                    queryDTO.getOper().put(EXPORT_NO.key(), EXPORT_NO.val());
                    BaseResponseDTO<ResultDTO> pageResDTO = this.pageList(listId, null, queryDTO);
                    if (BaseResponseDTO.DEFAULT_RESPONSE_RESULT.SUCCESS.value() != pageResDTO.getRet()) {
                        throw new BizException("导出数据批次检索失败");
                    } else {
                        ResultDTO resultDTO = pageResDTO.getData();
                        if (i == 1) {
                            //导出表格头
                            wbSheet = ExportUtils.exportExcelHeader(workbook, resultDTO);
                            //导出表格内容
                            ExportUtils.exportExcelData(wbSheet, dataIndex, resultDTO, dataCellStyle);
                            dataIndex += resultDTO.getList().size();
                        } else {
                            ExportUtils.exportExcelData(wbSheet, dataIndex, resultDTO, dataCellStyle);
                            dataIndex += resultDTO.getList().size();
                        }
                    }
                }
                Thread exportReceiverThread = new Thread(() -> {
                    try {
                        ffsClient.putBlob(FFS_TABLE, String.valueOf(fileId), pis, null);
                    } catch (Exception e) {
                        logger.error("导出数据保存到FFS失败", e);
                    }
                });
                this.exportReceiveExecutor.execute(exportReceiverThread);
                workbook.write(pos);
                // 强制缓存中的内容输出
                pos.flush();
                exportReceiverThread.join();
                this.redisTool.setAsync(exportToken, downloadToken, 30, TimeUnit.SECONDS);
            } catch (Exception e) {
                this.logger.error("导出数据失败", e);
                this.file2Provider.delete(fileId);
                downloadToken = EncryptorUtils.encrypt(ERR_FILE_ID + PARAM_VALUE_SPLITTER + System.currentTimeMillis(), DOWNLOAD_TOKEN_PWD, PBEWithMD5AndDES);
                this.redisTool.setAsync(exportToken, downloadToken, 30, TimeUnit.SECONDS);
            } finally {
                try {
                    if (pos != null) {
                        pos.close();
                    }
                    if (pis != null) {
                        pis.close();
                    }
                    if (workbook != null) {
                        workbook.close();
                    }
                } catch (Exception e) {
                    //ignore
                }

            }

        }
    }

    public BaseResponseDTO<Void> exportDownload(Long listId, String downloadToken, HttpServletResponse response) {
        BaseResponseDTO<Void> baseResponseDTO = new BaseResponseDTO<>();
        Long fileId = this.authChecker.decryptDownloadToken(downloadToken);
        if (fileId == null) {
            baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
            baseResponseDTO.addError("下载token异常, 不能导出数据");
        } else {
            String title = "_title_";
            ListDTO listDTO = this.listRepo.selectByPrimaryKey(listId);
            if (listDTO != null) {
                title = listDTO.getListName();
            }
            try {
                response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(title, "UTF-8") + ".xlsx");
                OutputStream os = response.getOutputStream();
                this.ffsClient.getBlobBean(FFS_TABLE, String.valueOf(fileId), os);
                os.flush();
                os.close();
                //删除文件
                this.file2Provider.delete(fileId);
            } catch (Exception e) {
                baseResponseDTO.setRet(BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR.value());
                baseResponseDTO.addError("导出数据下载失败");
            }

        }
        return baseResponseDTO;
    }
}
