package cn.xyz.listtool.web.controller;

import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.dto.ExportDTO;
import cn.xyz.listtool.dto.QueryDTO;
import cn.xyz.listtool.dto.ResultDTO;
import cn.xyz.listtool.dto.ServerQueryDTO;
import cn.xyz.listtool.web.service.ListtoolService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static cn.xyz.listtool.ListConst.LIST_OPER.EXPORT_YES;
import static cn.xyz.listtool.constant.Const.*;

/**
 * 列表 Controller
 *
 * @author lvchenggang.
 * @date 2019/11/14 17:12
 * @see
 * @since
 */
@Controller
@RequestMapping(URL_LIST_PREFIX)
public class ListtoolController {

    @Autowired
    private ListtoolService listtoolService;

    @Autowired
    private JsonMapper jsonMapper;

    @RequestMapping(value = "server/{listId:[\\d]+}", method = RequestMethod.POST)
    @ResponseBody
    public <T> BaseResponseDTO<T> serverPageList(HttpServletRequest request, HttpServletResponse response, @RequestParam("token") String token, @PathVariable Long listId, @RequestBody(required = false) ServerQueryDTO serverQueryDTO) {
        QueryDTO queryDTO = serverQueryDTO.getQueryDTO();
        if (queryDTO == null) {
            queryDTO = new QueryDTO();
            serverQueryDTO.setQueryDTO(queryDTO);
        }
        this.listtoolService.requisiteQueryDTO(queryDTO, listId);
        return listtoolService.serverDataHandler(response, token, listId, serverQueryDTO);
    }

    private String realForward(HttpServletRequest request, Long listId, QueryDTO queryDTO) {
        if (queryDTO == null) {
            queryDTO = new QueryDTO();
        }
        this.listtoolService.requisiteQueryDTO(queryDTO, listId);
        request.setAttribute("queryDTO", queryDTO);

        boolean isExport = false;
        if (queryDTO.getOper().containsKey(EXPORT_YES.key()) && EXPORT_YES.val() == queryDTO.getOper().get(EXPORT_YES.key())) {
            isExport = true;
        }

        String forwardUrl = "forward:" + URL_LIST_PREFIX + this.listtoolService.getAuthPath(listId, isExport) + listId;

        /**
         * <pre>
         * 由于MedusaAuthcFilter继承OncePerRequestFilter, 导致默认情况下的请求转发不会再次走此Filter.
         * 这里简单采用从request删除attribute的方式来解决此问题. 参见OncePerRequestFilter.doFilter()方法
         * </pre>
         */
        request.removeAttribute("shiroFilterProxy.FILTERED");

        String token = request.getParameter(PARAM_TOKEN);
        return StringUtils.isBlank(token) ? forwardUrl : forwardUrl + "?" + PARAM_TOKEN + "=" + token;
    }

    @RequestMapping(value = "{listId:[\\d]+}", method = RequestMethod.GET)
    public String forward(HttpServletRequest request, @PathVariable Long listId, @RequestParam(required = false, value = "queryDTO") String queryDTOStr) {
        QueryDTO queryDTO = this.jsonMapper.fromJson(queryDTOStr, QueryDTO.class);
        return this.realForward(request, listId, queryDTO);
    }


    @RequestMapping(value = "{listId:[\\d]+}", method = RequestMethod.POST)
    public String forward(HttpServletRequest request, @PathVariable Long listId, @RequestBody(required = false) QueryDTO queryDTO) {
        return this.realForward(request, listId, queryDTO);
    }

    @RequestMapping(value = "{path:none|medusa|custom}/{listId:[\\d]+}")
    @ResponseBody
    public BaseResponseDTO<ResultDTO> pageList(HttpServletRequest request, @PathVariable Long listId) {
        QueryDTO queryDTO = (QueryDTO) request.getAttribute("queryDTO");
        return listtoolService.pageList(listId, null, queryDTO);
    }

    @RequestMapping(value = "{path:none|medusa|custom}/export/{listId:[\\d]+}")
    @ResponseBody
    public BaseResponseDTO<ExportDTO> export(HttpServletRequest request, @PathVariable Long listId) {
        QueryDTO queryDTO = (QueryDTO) request.getAttribute("queryDTO");
        String exportToken = request.getParameter(EXPORT_TOKEN);
        return this.listtoolService.export(listId, null, queryDTO, exportToken);
    }

    @RequestMapping("exportDownload/{listId:[\\d]+}")
    @ResponseBody
    public BaseResponseDTO<Void> exportDownload(@PathVariable Long listId, HttpServletRequest request, HttpServletResponse response) {
        String downloadToken = request.getParameter(DOWNLOAD_TOKEN);
        return this.listtoolService.exportDownload(listId, downloadToken, response);
    }
}
