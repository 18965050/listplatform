package cn.xyz.listtool.management.web.controller;

import cn.xyz.chaos.mvc.web.api.BaseController;
import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.constant.Const.CACHE;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR;

/**
 * @author lvchenggang.
 * @date 2019/12/12 17:50
 * @see
 * @since
 */
@RestController
@RequestMapping("/management/cache")
@RequiresPermissions({"list:other"})
public class CacheController extends BaseController {

    @Autowired
    private RedissonClient redissonClient;

    @RequestMapping(path = "/invalidate", method = RequestMethod.POST)
    public BaseResponseDTO<Void> invalidate(@RequestBody String type) {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        try {
            String key = CACHE.keyFromType(Integer.valueOf(type));
            this.redissonClient.getKeys().deleteByPattern(key);
        } catch (Exception e) {
            baseResponseDTO.setRet(BIZ_ERROR.value());
            baseResponseDTO.addError(String.format("清除缓存失败(errMsg:%s)", e.getMessage()));
        }
        return baseResponseDTO;
    }
}
