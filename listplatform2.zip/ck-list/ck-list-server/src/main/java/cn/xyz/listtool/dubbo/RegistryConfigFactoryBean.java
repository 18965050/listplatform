package cn.xyz.listtool.dubbo;

import com.alibaba.dubbo.config.RegistryConfig;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.ConfigService;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * <pre>
 * dubbo RegistryConfig 工厂类
 * </pre>
 *
 * @author lvchenggang
 */
@Component
public class RegistryConfigFactoryBean implements FactoryBean<RegistryConfig>, InitializingBean {

    private RegistryConfig registryConfig;

    @Override
    public void afterPropertiesSet() throws Exception {
        registryConfig = new RegistryConfig();
        Config config = ConfigService.getConfig("XYZ.bootDubbo");
        registryConfig.setAddress(config.getProperty("spring.dubbo.registry.address", null));
        registryConfig.setPort(config.getIntProperty("spring.dubbo.registry.port", 14160));
        registryConfig.setProtocol(config.getProperty("spring.dubbo.registry.protocol", "dubbo"));
        registryConfig.setTimeout(config.getIntProperty("spring.dubbo.registry.timeout", 3000));
        registryConfig.setFile(config.getProperty("spring.dubbo.registry.file", "/home/xyz/dubbo/ck-list.cache"));
        registryConfig.setRegister(config.getBooleanProperty("spring.dubbo.registry.register", true));
    }

    @Override
    public RegistryConfig getObject() throws Exception {
        return this.registryConfig;
    }

    @Override
    public Class<?> getObjectType() {
        return RegistryConfig.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

}
