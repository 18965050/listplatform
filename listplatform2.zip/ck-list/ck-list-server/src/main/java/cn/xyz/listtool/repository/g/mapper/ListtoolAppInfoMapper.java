package cn.xyz.listtool.repository.g.mapper;

import static cn.xyz.listtool.repository.g.mapper.ListtoolAppInfoDynamicSqlSupport.*;
import static org.mybatis.dynamic.sql.SqlBuilder.*;

import cn.xyz.chaos.orm.mybatis.MyBatisRepository;
import cn.xyz.listtool.repository.g.entity.ListtoolAppInfo;
import java.util.List;
import java.util.function.Function;
import javax.annotation.Generated;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.dynamic.sql.SqlBuilder;
import org.mybatis.dynamic.sql.delete.DeleteDSL;
import org.mybatis.dynamic.sql.delete.MyBatis3DeleteModelAdapter;
import org.mybatis.dynamic.sql.delete.render.DeleteStatementProvider;
import org.mybatis.dynamic.sql.insert.render.InsertStatementProvider;
import org.mybatis.dynamic.sql.render.RenderingStrategy;
import org.mybatis.dynamic.sql.select.MyBatis3SelectModelAdapter;
import org.mybatis.dynamic.sql.select.QueryExpressionDSL;
import org.mybatis.dynamic.sql.select.SelectDSL;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.update.MyBatis3UpdateModelAdapter;
import org.mybatis.dynamic.sql.update.UpdateDSL;
import org.mybatis.dynamic.sql.update.render.UpdateStatementProvider;
import org.mybatis.dynamic.sql.util.SqlProviderAdapter;

@Mapper
@MyBatisRepository
public interface ListtoolAppInfoMapper {
    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.214+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    long count(SelectStatementProvider selectStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.216+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    @DeleteProvider(type=SqlProviderAdapter.class, method="delete")
    int delete(DeleteStatementProvider deleteStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.217+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    @InsertProvider(type=SqlProviderAdapter.class, method="insert")
    int insert(InsertStatementProvider<ListtoolAppInfo> insertStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.217+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @ResultMap("ListtoolAppInfoResult")
    ListtoolAppInfo selectOne(SelectStatementProvider selectStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.218+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @ResultMap("ListtoolAppInfoResult")
    List<ListtoolAppInfo> selectManyWithRowbounds(SelectStatementProvider selectStatement, RowBounds rowBounds);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.22+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default Function<SelectStatementProvider, List<ListtoolAppInfo>> selectManyWithRowbounds(RowBounds rowBounds) {
        return selectStatement -> selectManyWithRowbounds(selectStatement, rowBounds);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.218+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @Results(id="ListtoolAppInfoResult", value = {
        @Result(column="APP_ID", property="appId", jdbcType=JdbcType.BIGINT, id=true),
        @Result(column="APP_NAME", property="appName", jdbcType=JdbcType.VARCHAR),
        @Result(column="APP_KEY", property="appKey", jdbcType=JdbcType.VARCHAR),
        @Result(column="APP_SECRET", property="appSecret", jdbcType=JdbcType.VARCHAR),
        @Result(column="STATUS", property="status", jdbcType=JdbcType.TINYINT),
        @Result(column="CREATE_ID", property="createId", jdbcType=JdbcType.BIGINT),
        @Result(column="MODIFY_ID", property="modifyId", jdbcType=JdbcType.BIGINT),
        @Result(column="CREATE_NAME", property="createName", jdbcType=JdbcType.VARCHAR),
        @Result(column="MODIFY_NAME", property="modifyName", jdbcType=JdbcType.VARCHAR),
        @Result(column="CREATE_TIME", property="createTime", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="MODIFY_TIME", property="modifyTime", jdbcType=JdbcType.TIMESTAMP)
    })
    List<ListtoolAppInfo> selectMany(SelectStatementProvider selectStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.221+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    @UpdateProvider(type=SqlProviderAdapter.class, method="update")
    int update(UpdateStatementProvider updateStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.221+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<Long>> countByExample() {
        return SelectDSL.selectWithMapper(this::count, SqlBuilder.count())
                .from(listtoolAppInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.225+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default DeleteDSL<MyBatis3DeleteModelAdapter<Integer>> deleteByExample() {
        return DeleteDSL.deleteFromWithMapper(this::delete, listtoolAppInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.228+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default int deleteByPrimaryKey(Long appId_) {
        return DeleteDSL.deleteFromWithMapper(this::delete, listtoolAppInfo)
                .where(appId, isEqualTo(appId_))
                .build()
                .execute();
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.229+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default int insert(ListtoolAppInfo record) {
        return insert(SqlBuilder.insert(record)
                .into(listtoolAppInfo)
                .map(appId).toProperty("appId")
                .map(appName).toProperty("appName")
                .map(appKey).toProperty("appKey")
                .map(appSecret).toProperty("appSecret")
                .map(status).toProperty("status")
                .map(createId).toProperty("createId")
                .map(modifyId).toProperty("modifyId")
                .map(createName).toProperty("createName")
                .map(modifyName).toProperty("modifyName")
                .map(createTime).toProperty("createTime")
                .map(modifyTime).toProperty("modifyTime")
                .build()
                .render(RenderingStrategy.MYBATIS3));
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.23+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default int insertSelective(ListtoolAppInfo record) {
        return insert(SqlBuilder.insert(record)
                .into(listtoolAppInfo)
                .map(appId).toPropertyWhenPresent("appId", record::getAppId)
                .map(appName).toPropertyWhenPresent("appName", record::getAppName)
                .map(appKey).toPropertyWhenPresent("appKey", record::getAppKey)
                .map(appSecret).toPropertyWhenPresent("appSecret", record::getAppSecret)
                .map(status).toPropertyWhenPresent("status", record::getStatus)
                .map(createId).toPropertyWhenPresent("createId", record::getCreateId)
                .map(modifyId).toPropertyWhenPresent("modifyId", record::getModifyId)
                .map(createName).toPropertyWhenPresent("createName", record::getCreateName)
                .map(modifyName).toPropertyWhenPresent("modifyName", record::getModifyName)
                .map(createTime).toPropertyWhenPresent("createTime", record::getCreateTime)
                .map(modifyTime).toPropertyWhenPresent("modifyTime", record::getModifyTime)
                .build()
                .render(RenderingStrategy.MYBATIS3));
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.232+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolAppInfo>>> selectByExample(RowBounds rowBounds) {
        return SelectDSL.selectWithMapper(selectManyWithRowbounds(rowBounds), appId, appName, appKey, appSecret, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolAppInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.232+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolAppInfo>>> selectByExample() {
        return SelectDSL.selectWithMapper(this::selectMany, appId, appName, appKey, appSecret, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolAppInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.233+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolAppInfo>>> selectDistinctByExample(RowBounds rowBounds) {
        return SelectDSL.selectDistinctWithMapper(selectManyWithRowbounds(rowBounds), appId, appName, appKey, appSecret, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolAppInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.233+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolAppInfo>>> selectDistinctByExample() {
        return SelectDSL.selectDistinctWithMapper(this::selectMany, appId, appName, appKey, appSecret, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolAppInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.234+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default ListtoolAppInfo selectByPrimaryKey(Long appId_) {
        return SelectDSL.selectWithMapper(this::selectOne, appId, appName, appKey, appSecret, status, createId, modifyId, createName, modifyName, createTime, modifyTime)
                .from(listtoolAppInfo)
                .where(appId, isEqualTo(appId_))
                .build()
                .execute();
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.235+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default UpdateDSL<MyBatis3UpdateModelAdapter<Integer>> updateByExample(ListtoolAppInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolAppInfo)
                .set(appId).equalTo(record::getAppId)
                .set(appName).equalTo(record::getAppName)
                .set(appKey).equalTo(record::getAppKey)
                .set(appSecret).equalTo(record::getAppSecret)
                .set(status).equalTo(record::getStatus)
                .set(createId).equalTo(record::getCreateId)
                .set(modifyId).equalTo(record::getModifyId)
                .set(createName).equalTo(record::getCreateName)
                .set(modifyName).equalTo(record::getModifyName)
                .set(createTime).equalTo(record::getCreateTime)
                .set(modifyTime).equalTo(record::getModifyTime);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.236+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default UpdateDSL<MyBatis3UpdateModelAdapter<Integer>> updateByExampleSelective(ListtoolAppInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolAppInfo)
                .set(appId).equalToWhenPresent(record::getAppId)
                .set(appName).equalToWhenPresent(record::getAppName)
                .set(appKey).equalToWhenPresent(record::getAppKey)
                .set(appSecret).equalToWhenPresent(record::getAppSecret)
                .set(status).equalToWhenPresent(record::getStatus)
                .set(createId).equalToWhenPresent(record::getCreateId)
                .set(modifyId).equalToWhenPresent(record::getModifyId)
                .set(createName).equalToWhenPresent(record::getCreateName)
                .set(modifyName).equalToWhenPresent(record::getModifyName)
                .set(createTime).equalToWhenPresent(record::getCreateTime)
                .set(modifyTime).equalToWhenPresent(record::getModifyTime);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.237+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default int updateByPrimaryKey(ListtoolAppInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolAppInfo)
                .set(appName).equalTo(record::getAppName)
                .set(appKey).equalTo(record::getAppKey)
                .set(appSecret).equalTo(record::getAppSecret)
                .set(status).equalTo(record::getStatus)
                .set(createId).equalTo(record::getCreateId)
                .set(modifyId).equalTo(record::getModifyId)
                .set(createName).equalTo(record::getCreateName)
                .set(modifyName).equalTo(record::getModifyName)
                .set(createTime).equalTo(record::getCreateTime)
                .set(modifyTime).equalTo(record::getModifyTime)
                .where(appId, isEqualTo(record::getAppId))
                .build()
                .execute();
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.238+08:00", comments="Source Table: listtool..LISTTOOL_APP_INFO")
    default int updateByPrimaryKeySelective(ListtoolAppInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolAppInfo)
                .set(appName).equalToWhenPresent(record::getAppName)
                .set(appKey).equalToWhenPresent(record::getAppKey)
                .set(appSecret).equalToWhenPresent(record::getAppSecret)
                .set(status).equalToWhenPresent(record::getStatus)
                .set(createId).equalToWhenPresent(record::getCreateId)
                .set(modifyId).equalToWhenPresent(record::getModifyId)
                .set(createName).equalToWhenPresent(record::getCreateName)
                .set(modifyName).equalToWhenPresent(record::getModifyName)
                .set(createTime).equalToWhenPresent(record::getCreateTime)
                .set(modifyTime).equalToWhenPresent(record::getModifyTime)
                .where(appId, isEqualTo(record::getAppId))
                .build()
                .execute();
    }
}