package cn.xyz.listtool.repository;

import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.management.web.dto.AppDTO;
import cn.xyz.listtool.orika.MappingUtils;
import cn.xyz.listtool.repository.dao.ListtoolAppInfoDAO;
import cn.xyz.listtool.repository.g.entity.ListtoolAppInfo;
import com.alicp.jetcache.anno.Cached;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static cn.xyz.listtool.constant.Const.CACHE_APP_NAME;
import static cn.xyz.listtool.repository.g.mapper.ListtoolAppInfoDynamicSqlSupport.listtoolAppInfo;
import static org.mybatis.dynamic.sql.SqlBuilder.isEqualTo;
import static org.mybatis.dynamic.sql.SqlBuilder.isIn;

/**
 * @author lvchenggang.
 * @date 2019/11/27 15:15
 * @see
 * @since
 */
@Repository
public class AppRepository {

    @Autowired
    private ListtoolAppInfoDAO appDao;

    @Cached(name = CACHE_APP_NAME, key = "#appId")
    public AppDTO selectByPrimaryKey(Long appId) {
        ListtoolAppInfo appInfo = this.appDao.selectByPrimaryKey(appId);
        return MappingUtils.beanConvert(appInfo, AppDTO.class);
    }

    public int add(AppDTO appDTO) {
        ListtoolAppInfo appInfo = MappingUtils.beanConvert(appDTO, ListtoolAppInfo.class);
        int res = this.appDao.insertSelective(appInfo);
        appDTO.setAppId(appInfo.getAppId());
        return res;
    }

    public int update(AppDTO appDTO) {
        ListtoolAppInfo appInfo = MappingUtils.beanConvert(appDTO, ListtoolAppInfo.class);
        return this.appDao.updateByPrimaryKeySelective(appInfo);
    }

    public List<AppDTO> getAllValidAppIds() {
        List<ListtoolAppInfo> appInfos = this.appDao.selectByExample().where(listtoolAppInfo.status, isEqualTo(Const.STATUS.VALID.val())).build().execute();
        return MappingUtils.beanListConvert(appInfos, AppDTO.class);
    }

    public List<AppDTO> selectByAppIds(List<Long> appIds) {
        List<ListtoolAppInfo> appInfos = this.appDao.selectByExample().where(listtoolAppInfo.appId, isIn(appIds)).build().execute();
        return MappingUtils.beanListConvert(appInfos, AppDTO.class);
    }

    @Transactional
    public void importData(List<AppDTO> appDTOS) {
        if (CollectionUtils.isNotEmpty(appDTOS)) {
            List<Long> appIds = new ArrayList<>();
            List<ListtoolAppInfo> appInfos = MappingUtils.beanListConvert(appDTOS, ListtoolAppInfo.class);
            appDTOS.forEach(appDTO -> {
                appIds.add(appDTO.getAppId());
            });
            this.appDao.deleteByAppIds(appIds);
            this.appDao.batchInsert(appInfos);
        }
    }
}
