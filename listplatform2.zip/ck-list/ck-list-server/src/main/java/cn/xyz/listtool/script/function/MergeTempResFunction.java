package cn.xyz.listtool.script.function;

import cn.xyz.listtool.constant.Const.CONTEXT;
import cn.xyz.listtool.dto.ResultDTO;
import cn.xyz.listtool.dto.SpecDTO;
import cn.xyz.listtool.pipeline.MergeTempResParam;
import cn.xyz.listtool.web.dto.TempsDTO;
import cn.xyz.listtool.web.dto.TempsDTO.TempDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static cn.xyz.listtool.constant.Const.COMMON_SPLITTER;

/**
 * 合并pipeline执行结果
 *
 * @author lvchenggang.
 * @date 2020/2/18 13:48
 * @see
 * @since
 */
@Component
public class MergeTempResFunction extends AbstractFunction<MergeTempResParam, Void> {

    public Void innerExec(Map<String, Object> context, SpecDTO.PipeLineDTO pipeLineDTO, MergeTempResParam mergeTempResParam, Map<String, Object> logMap) {
        TempsDTO tempsDTO = (TempsDTO) context.get(CONTEXT.TEMPS.val());
        Map<String, TempDTO> tempDTOMap = tempsDTO.getTempDTOMap();
        TempDTO logDTO = new TempDTO();
        String source = mergeTempResParam.getSource();
        String target = mergeTempResParam.getTarget();
        if (StringUtils.isNotBlank(source)&& StringUtils.isNotBlank(target)) {
            TempDTO sourceTempDTO = tempDTOMap.get(source);
            TempDTO targetTempDTO = tempDTOMap.get(target);
            if (sourceTempDTO != null && targetTempDTO != null) {
                List<Map<String, ResultDTO.FieldValueDTO>> sourceDataList = sourceTempDTO.getList();
                List<Map<String, ResultDTO.FieldValueDTO>> targetDataList = targetTempDTO.getList();
                if (CollectionUtils.isNotEmpty(sourceDataList) && CollectionUtils.isNotEmpty(targetDataList)) {
                    //(1) pipeline合并
                    Map<String, ResultDTO.FieldValueDTO> firstSourceDataMap = sourceDataList.get(0);
                    List<SpecDTO.FieldDTO> fieldDTOS = ((SpecDTO) context.get(CONTEXT.SPEC.val())).getFields().stream().filter(fieldDTO -> {
                        return fieldDTO.getResult() != null && firstSourceDataMap.containsKey(fieldDTO.getKey()) && !mergeTempResParam.getRelateFields().contains(fieldDTO.getKey());
                    }).collect(Collectors.toList());

                    fieldDTOS.forEach(fieldDTO -> {
                        for (Map<String, ResultDTO.FieldValueDTO> targetDataMap : targetDataList) {
                            List<Map<String, ResultDTO.FieldValueDTO>> dataList = sourceDataList;
                            for (String relateField : mergeTempResParam.getRelateFields()) {
                                ResultDTO.FieldValueDTO relateValue = targetDataMap.get(relateField);
                                dataList = this.getResByRelateField(dataList, relateField, relateValue);
                                if (CollectionUtils.isEmpty(dataList)) {
                                    break;
                                }
                            }
                            if (CollectionUtils.isEmpty(dataList)) {
                                targetDataMap.put(fieldDTO.getKey(), null);
                            } else {
                                if (dataList.size() == 1) {
                                    targetDataMap.put(fieldDTO.getKey(), dataList.get(0).get(fieldDTO.getKey()));
                                } else {
                                    List value = new ArrayList();
                                    StringBuilder labelValueSB = new StringBuilder();
                                    dataList.forEach(dataMap -> {
                                        ResultDTO.FieldValueDTO fieldValueDTO = dataMap.get(fieldDTO.getKey());
                                        value.add(fieldValueDTO.getValue());
                                        labelValueSB.append(fieldValueDTO.getLabelValue()).append(COMMON_SPLITTER);
                                    });
                                    String labelValue = labelValueSB.substring(0, labelValueSB.lastIndexOf(COMMON_SPLITTER));
                                    ResultDTO.FieldValueDTO fieldValueDTO = new ResultDTO.FieldValueDTO(value, labelValue);
                                    targetDataMap.put(fieldDTO.getKey(), fieldValueDTO);
                                }
                            }
                        }
                    });
                    logDTO.setList(targetTempDTO.getList());
                }
                //(2) temps删除source对应的结果
                tempDTOMap.remove(source);
            }
        }


        logMap.put(this.getName(), logDTO);
        return null;
    }

    private List<Map<String, ResultDTO.FieldValueDTO>> getResByRelateField(List<Map<String, ResultDTO.FieldValueDTO>> dataList, String key, ResultDTO.FieldValueDTO val) {
        if (CollectionUtils.isEmpty(dataList)) {
            return null;
        }
        List<Map<String, ResultDTO.FieldValueDTO>> resList = new ArrayList<>();
        for (Map<String, ResultDTO.FieldValueDTO> dataMap : dataList) {
            if (dataMap.get(key).getValue().equals(val.getValue())) {
                resList.add(dataMap);
            }
        }
        return resList;
    }
}
