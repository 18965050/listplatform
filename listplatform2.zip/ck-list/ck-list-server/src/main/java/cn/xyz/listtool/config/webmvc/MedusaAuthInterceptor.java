package cn.xyz.listtool.config.webmvc;

import cn.xyz.chaos.mvc.web.api.AuthenticationException;
import cn.xyz.listtool.management.web.dto.ListDTO;
import cn.xyz.medusa.client.MedusaPrincipal;
import cn.xyz.medusa.client.util.AuthUtils;
import cn.xyz.medusa.constants.MedusaConstants;
import cn.xyz.medusa.utils.AuthCheckService;
import org.apache.shiro.authz.AuthorizationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Medusa 鉴权拦截器
 *
 * @author lvchenggang.
 * @date 2019/12/5 11:10
 * @see
 * @since
 */
@ConditionalOnProperty(MedusaConstants.MEDUSA_BOOTSTRAP_ENABLED)
@Component("medusaAuthInterceptor")
public class MedusaAuthInterceptor extends BaseAuthInterceptor {

    @Autowired
    private AuthCheckService authCheckService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        super.preHandle(request, response, handler);

        ListDTO listDTO = this.getListDTOThreadLocal().get();
        MedusaPrincipal currentPrincipal = AuthUtils.getCurrentPrincipal();

        if (null == currentPrincipal) {
            throw new AuthenticationException("认证失败");
        }
        Long userId = currentPrincipal.getUserId();
        if (this.authCheckService.medusaAuthCheck(userId, listDTO.getAuthExpr())) {
            return true;
        }
        throw new AuthorizationException("鉴权失败");
    }

}
