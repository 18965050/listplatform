package cn.xyz.listtool.config.webmvc;

import cn.xyz.chaos.mvc.web.api.BizException;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.management.web.dto.ListDTO;
import cn.xyz.listtool.repository.ListRepository;
import org.apache.shiro.authz.AuthorizationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 基础认证拦截器
 *
 * @author lvchenggang.
 * @date 2019/12/10 11:44
 * @see
 * @since
 */
@Component("baseAuthInterceptor")
public class BaseAuthInterceptor extends HandlerInterceptorAdapter {

    private Pattern pathPattern = Pattern.compile("^/listtool(/none/|/medusa/|/custom/)(\\d+)$");

    @Autowired
    private ListRepository listRepo;

    private ThreadLocal<ListDTO> listDTOThreadLocal = new ThreadLocal<ListDTO>();

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String uri = request.getRequestURI();
        Matcher matcher = pathPattern.matcher(uri);
        if (!matcher.find()) {
            throw new BizException("列表查询路径不正确");
        } else {
            String authPath = matcher.group(1);
            Long listId = Long.valueOf(matcher.group(2));
            ListDTO listDTO = listRepo.selectByPrimaryKey(listId);
            if (Const.STATUS.VALID.val() != listDTO.getStatus()) {
                throw new BizException(String.format("列表(listId:%d)已经停用", listDTO.getListId()));
            }
            listDTOThreadLocal.set(listDTO);
            int authType = listDTO.getAuthType();
            for (Const.AUTH_TYPE eAuthType : Const.AUTH_TYPE.values()) {
                if (eAuthType.val() == authType && eAuthType.path().equals(authPath)) {
                    return true;
                }
            }
            throw new AuthorizationException("鉴权失败");
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        this.listDTOThreadLocal.remove();
    }

    public ThreadLocal<ListDTO> getListDTOThreadLocal() {
        return listDTOThreadLocal;
    }
}
