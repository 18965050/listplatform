package cn.xyz.listtool.config;

import cn.xyz.chaos.common.utils.SpringContextUtils;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.api.impl.FieldFormatProviderImpl;
import com.alibaba.boot.velocity.VelocityConstants;
import com.ctrip.framework.apollo.ConfigService;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.cassandra.extend.client.FFSClient;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.tools.ToolManager;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.velocity.VelocityProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Primary;


/**
 * 一般性的spring配置
 *
 * @author lvchenggang.
 * @date 2019/11/15 10:29
 * @see
 * @since
 */
@Configuration
@ImportResource("classpath:/ck-list-soa.xml")
public class NormalConfig {

    @Bean("springContextUtils")
    @Primary
    public SpringContextUtils initSpringContextUtils() {
        return new SpringContextUtils();
    }

    @Bean
    @Primary
    public JsonMapper jsonMapper(ObjectMapper objectMapper) {
        return new JsonMapper(objectMapper, JsonInclude.Include.NON_NULL);
    }

    @ConditionalOnClass(VelocityEngine.class)
    @ConditionalOnProperty({VelocityConstants.VELOCITY_ENABLED_PROPERTY_NAME,
        VelocityConstants.VELOCITY_TOOLBOX_CONFIG_LOCATION_PROPERTY_NAME})
    @ConditionalOnMissingBean(ToolManager.class)
    @Bean
    public ToolManager toolManager(VelocityEngine velocityEngine, VelocityProperties velocityProperties) {
        ToolManager toolManager = new ToolManager(false, false);
        toolManager.setVelocityEngine(velocityEngine);
        // ToolManager only support load config resource from classpath(without "classpath:") or filesystem
        String toolConfigLocation =
            StringUtils.remove(velocityProperties.getToolboxConfigLocation(), "classpath:").trim();
        toolManager.configure(toolConfigLocation);
        return toolManager;
    }

    @Bean("fieldFormatProvider")
    public FieldFormatProviderImpl fieldFormatProvider() {
        return new FieldFormatProviderImpl();
    }

    @Bean("ffsClient")
    public FFSClient ffsClient() {
        String hosts = ConfigService.getConfig("XYZ.ffs").getProperty("ffs.hosts", "nonExist");
        String keySpaceName = ConfigService.getConfig("XYZ.ffs").getProperty("ffs.keyspaceName", "nonExist");
        String username = ConfigService.getConfig("XYZ.ffs").getProperty("ffs.username", "nonExist");
        String password = ConfigService.getConfig("XYZ.ffs").getProperty("ffs.password", "nonExist");
        return FFSClient.getInstance(hosts, keySpaceName,
            FFSClient.BlockSize.BlockSize_1M, username, password);
    }

}
