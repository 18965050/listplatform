package cn.xyz.listtool.script.function;

import cn.xyz.chaos.common.utils.SpringContextUtils;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.constant.Const.CONTEXT;
import cn.xyz.listtool.constant.Const.FIELD_FORMAT;
import cn.xyz.listtool.constant.Const.METRICS;
import cn.xyz.listtool.datasource.BizDataSource;
import cn.xyz.listtool.datasource.DataSourceManager;
import cn.xyz.listtool.dto.PageDTO;
import cn.xyz.listtool.dto.QueryDTO;
import cn.xyz.listtool.dto.ResultDTO;
import cn.xyz.listtool.dto.SpecDTO;
import cn.xyz.listtool.pipeline.CompleteQlParam;
import cn.xyz.listtool.pipeline.ExecQlParam;
import cn.xyz.listtool.script.ScriptEngine;
import cn.xyz.listtool.web.dto.TempsDTO.TempDTO;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Timer;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.*;

import static cn.xyz.listtool.ListConst.LIST_OPER.EXPORT_YES;


/**
 * 执行QL的函数
 *
 * @author lvchenggang.
 * @date 2019/11/20 11:45
 * @see
 * @since
 */
@Component
public class ExecQlFunction extends AbstractFunction<ExecQlParam, TempDTO> {

    @Autowired
    private MeterRegistry meterRegistry;

    @Autowired
    private JsonMapper jsonMapper;

    public TempDTO innerExec(Map<String, Object> context, SpecDTO.PipeLineDTO pipelineDTO, ExecQlParam execQlParam, Map<String, Object> logMap) {
        String placeHolder = execQlParam.getPlaceHolder();
        if (StringUtils.isNotBlank(placeHolder)) {
            ScriptEngine scriptEngine = SpringContextUtils.getBean("qlScriptEngine");
//            ScriptEngine scriptEngine = SpringContextUtils.getBean("jsScriptEngine");
            scriptEngine.exec(placeHolder, context);
        }
        String ds = execQlParam.getDs();
        String ql = execQlParam.getQl();
        Integer paging = execQlParam.getPaging();
        Set<String> queries = execQlParam.getQueries();
        Set<String> orders = execQlParam.getOrders();
        CompleteQlParam completeQlParam = new CompleteQlParam(ql, ds, queries, orders, paging);
        CompleteQlFunction completeQlFunction = CompleteQlFunction.getInstance(ds);
        TempDTO tempDTO = completeQlFunction.innerExec(context, pipelineDTO, completeQlParam, logMap);
        String pipelineName = pipelineDTO.getName();
        String dsName = execQlParam.getDs();
        DataSourceManager dsManager = SpringContextUtils.getBean(DataSourceManager.class);
        BizDataSource bizDS = dsManager.get(dsName);
        String listId = String.valueOf(context.get(CONTEXT.ID.val()));
        ArrayList<Tag> tags = new ArrayList<>(2);
        QueryDTO queryDTO = (QueryDTO) context.get(CONTEXT.QUERY.val());
        JdbcTemplate jdbcTemplate = bizDS.getJdbcTemplate();
        Timer.Sample invokerSample = null;
        List<SpecDTO.FieldDTO> fieldDTOS = ((SpecDTO) context.get(CONTEXT.SPEC.val())).getFields();
        if (tempDTO != null) {
            // (2) 查询分页信息
            if (StringUtils.isNotBlank(tempDTO.getCountQl())) {
                Object[] countParamArr = new Object[tempDTO.getCountPss().size()];
                int[] countParamTypeArr = new int[tempDTO.getCountPss().size()];
                for (int i = 0; i < tempDTO.getCountPss().size(); i++) {
                    countParamArr[i] = tempDTO.getCountPss().get(i).getParam();
                    countParamTypeArr[i] = tempDTO.getCountPss().get(i).getParamType();
                }
                METRICS.QL_COUNT.tags().forEach((tag) -> {
                    if (tag.equals("dsName")) {
                        tags.add(Tag.of(tag, bizDS.getDsName()));
                    } else {
                        tags.add(Tag.of(tag, listId + "-" + pipelineName));
                    }
                });
                invokerSample = Timer.start(meterRegistry);
                PageDTO pageDTO = jdbcTemplate.queryForObject(tempDTO.getCountQl(), countParamArr, countParamTypeArr, (rs, rowNum) -> {
                    PageDTO pgDTO = new PageDTO();
                    int totalCount = rs.getInt(1);
                    int pageSize = queryDTO.getPagenator().getPageSize();
                    pgDTO.setTotalCount(totalCount);
                    pgDTO.setPageIndex(queryDTO.getPagenator().getPageIndex());
                    pgDTO.setPageSize(pageSize);
                    int pageCount = (totalCount % pageSize == 0 ? totalCount / pageSize : totalCount / pageSize + 1);
                    if (pageCount == 0) {
                        pageCount = 1;
                    }
                    pgDTO.setPageCount(pageCount);
                    return pgDTO;
                });
                invokerSample.stop(meterRegistry.timer(METRICS.QL_COUNT.metric(), tags));
                tempDTO.setPagenator(pageDTO);
            }

            // (3) 查询列表数据(导出数据不执行实际查询)
            if (!(queryDTO.getOper().containsKey(EXPORT_YES.key()) && EXPORT_YES.val() == queryDTO.getOper().get(EXPORT_YES.key()))) {
                if (StringUtils.isNotBlank(tempDTO.getQl())) {
                    Object[] paramArr = new Object[tempDTO.getPss().size()];
                    int[] paramTypeArr = new int[tempDTO.getPss().size()];
                    for (int i = 0; i < tempDTO.getPss().size(); i++) {
                        paramArr[i] = tempDTO.getPss().get(i).getParam();
                        paramTypeArr[i] = tempDTO.getPss().get(i).getParamType();
                    }
                    tags.clear();
                    METRICS.QL_EXEC.tags().forEach((tag) -> {
                        if (tag.equals("dsName")) {
                            tags.add(Tag.of(tag, bizDS.getDsName()));
                        } else {
                            tags.add(Tag.of(tag, listId + "-" + pipelineName));
                        }
                    });
                    invokerSample = Timer.start(meterRegistry);
                    List<Map<String, Object>> dataList = jdbcTemplate.queryForList(tempDTO.getQl(), paramArr, paramTypeArr);
                    invokerSample.stop(meterRegistry.timer(METRICS.QL_EXEC.metric(), tags));
                    List<Map<String, ResultDTO.FieldValueDTO>> finalDataList = new ArrayList<>(dataList.size());
                    //(3)结果预保存
                    if (CollectionUtils.isNotEmpty(dataList)) {
                        dataList.forEach(dataMap -> {
                            Map<String, ResultDTO.FieldValueDTO> map = new LinkedHashMap<>();
                            dataMap.forEach((k, v) -> {
                                ResultDTO.FieldValueDTO fvDTO = new ResultDTO.FieldValueDTO(v, v == null ? "" : String.valueOf(v));
                                map.put(k, fvDTO);
                            });
                            finalDataList.add(map);
                        });
                    }

                    // (4) 字段映射
                    if (CollectionUtils.isNotEmpty(finalDataList)) {
                        finalDataList.forEach(row -> {
                            Set<String> keySet = row.keySet();
                            for (SpecDTO.FieldDTO fieldDTO : fieldDTOS) {
                                String fieldKey = fieldDTO.getKey();
                                if (keySet.contains(fieldKey)) {
                                    // 先进行FieldFormat改写
                                    if (fieldDTO.getResult() != null && StringUtils.isNotBlank(fieldDTO.getResult().getFormat())) {
                                        String fieldFormatStr = fieldDTO.getResult().getFormat();
                                        if (StringUtils.isNotBlank(fieldFormatStr)) {
                                            IFieldFormat fieldFormat = null;
                                            if (fieldFormatStr.trim().startsWith(FIELD_FORMAT.QL.val())) {
                                                fieldFormat = SpringContextUtils.getBean("qlFieldFormat");
                                            } else if (fieldFormatStr.trim().startsWith(FIELD_FORMAT.DUBBO.val())) {
                                                fieldFormat = SpringContextUtils.getBean("dubboFieldFormat");
                                            } else {
                                                String errInfo = String.format("不支持的字段映射(fieldFormat:%s)", fieldFormatStr);
                                                logger.error(errInfo);
                                                throw new RuntimeException(errInfo);
                                            }
                                            Pair<Object, String> pair = fieldFormat.formatField(Long.valueOf(listId), pipelineName, row, fieldDTO, bizDS);
                                            row.put(fieldKey, new ResultDTO.FieldValueDTO(pair.getLeft(), pair.getRight()));
                                        }
                                    } else if (StringUtils.isNotBlank(fieldDTO.getMapping())) { //再进行FieldMapping改写
                                        //mapping已经转换过, 无需再次转换
                                        Map map = jsonMapper.fromJson(fieldDTO.getMapping(), Map.class);
                                        row.put(fieldKey, new ResultDTO.FieldValueDTO(row.get(fieldKey).getValue(),
                                            String.valueOf(map.getOrDefault(String.valueOf(row.get(fieldKey).getValue()), row.get(fieldKey).getLabelValue()))));
                                    }
                                }
                            }
                        });
                    }
                    tempDTO.setList(finalDataList);
                }
            }
        }
        TempDTO logDTO = new TempDTO();
        logDTO.setPagenator(tempDTO.getPagenator());
        logDTO.setList(tempDTO.getList());
        logMap.put(this.getName(), logDTO);
        return tempDTO;
    }
}
