package cn.xyz.listtool.auth;

import cn.xyz.chaos.common.utils.encrypt.EncryptorUtils;
import cn.xyz.io.admin.auth.api.Adm2PermissionProvider;
import cn.xyz.io.admin.auth.api.Adm2RoleProvider;
import cn.xyz.io.admin.auth.api.AdmUserProvider;
import cn.xyz.io.admin.auth.api.dto.*;
import cn.xyz.listtool.management.web.dto.AppDTO;
import cn.xyz.medusa.utils.AuthCheckService;
import com.alibaba.dubbo.config.annotation.Reference;
import com.alicp.jetcache.anno.Cached;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static cn.xyz.chaos.common.utils.encrypt.Encryptor.ALGORITHM.PBEWithMD5AndDES;
import static cn.xyz.listtool.ListConst.PARAM_VALUE_SPLITTER;
import static cn.xyz.listtool.constant.Const.*;

/**
 * 鉴权校验器
 *
 * @author lvchenggang.
 * @date 2020/5/8 9:39
 * @see
 * @since
 */
@Component
public class AuthChecker {

    @Reference(check = false)
    private AdmUserProvider admUserProvider;

    @Reference(check = false)
    private Adm2RoleProvider adm2RoleProvider;

    @Reference(check = false)
    private Adm2PermissionProvider adm2PermissionProvider;

    @Autowired
    private AuthCheckService authCheckService;

    public boolean tokenCheck(String token, AppDTO appDTO) {
        try {
            String plainText = EncryptorUtils.decrypt(token, appDTO.getAppSecret(), PBEWithMD5AndDES);
            String[] plainParts = plainText.split(PARAM_VALUE_SPLITTER);
            if (plainParts.length == 2 && plainParts[0].equals(appDTO.getAppKey()) && (System.currentTimeMillis() - Long.valueOf(plainParts[1]) < VALID_TOKEN_MS)) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public Long decryptDownloadToken(String token) {
        try {
            String plainText = EncryptorUtils.decrypt(token, DOWNLOAD_TOKEN_PWD, PBEWithMD5AndDES);
            String[] plainParts = plainText.split(PARAM_VALUE_SPLITTER);
            if (plainParts.length == 2 && (System.currentTimeMillis() - Long.valueOf(plainParts[1]) < VALID_TOKEN_MS)) {
                try {
                    return Long.valueOf(plainParts[0]);
                } catch (Exception e) {
                    return null;
                }
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Cached(name = CACHE_USER_NAME, key = "#userId")
    public AuthenDTO getAuthenDTOByUserId(Long userId) {
        Assert.notNull(userId, "userId不能为空");
        AuthenDTO authenDTO = new AuthenDTO();
        AdmUserDTO admUserDTO = this.admUserProvider.queryByUserId(userId);
        if (admUserDTO != null) {
            authenDTO.setLoginName(admUserDTO.getLoginname());
            List<Adm2RoleDTO> roles = this.admUserProvider.getRolesByUserId(userId);
            if (CollectionUtils.isNotEmpty(roles)) {
                Set<String> roleKeySet = new HashSet<>();
                authenDTO.setRoleKeySet(roleKeySet);
                Set<String> permExprSet = new HashSet<>();
                authenDTO.setPermExprSet(permExprSet);
                roles.forEach(role -> {
                    roleKeySet.add(role.getKey());
                    Adm2RolePermRelateQueryDTO rolePermRelateQueryDTO = new Adm2RolePermRelateQueryDTO();
                    rolePermRelateQueryDTO.setRoleIdEq(role.getRoleId());
                    List<SimpleAdm2RolePermRelateDTO> rolePermRelateDTOS = this.adm2RoleProvider.queryRolePermRelationBySelective(rolePermRelateQueryDTO);
                    if (CollectionUtils.isNotEmpty(rolePermRelateDTOS)) {
                        String permIds = rolePermRelateDTOS.get(0).getPermIds();
                        if (StringUtils.isNotBlank(permIds)) {
                            String[] splitArr = permIds.split(",");
                            for (int i = 0; i < splitArr.length; i++) {
                                Adm2PermissionQueryDTO permissionQueryDTO = new Adm2PermissionQueryDTO();
                                permissionQueryDTO.setPermissionIdEq(Long.valueOf(splitArr[i]));
                                List<Adm2PermissionDTO> adm2PermissionDTOS = adm2PermissionProvider.queryBySelective(permissionQueryDTO);
                                if (CollectionUtils.isNotEmpty(adm2PermissionDTOS)) {
                                    adm2PermissionDTOS.forEach(adm2PermissionDTO -> {
                                        permExprSet.add(adm2PermissionDTO.getExpression());
                                    });
                                }
                            }
                        }
                    }
                });
            }
        }
        return authenDTO;
    }

    public boolean serviceAuthCheck(AuthenDTO authenDTO, String authExpr) {
        if (StringUtils.isBlank(authExpr)) {
            return true;
        } else {
            return this.authCheckService.authCheck(authenDTO.getLoginName(), authenDTO.getRoleKeySet(), authenDTO.getPermExprSet(), authExpr);
        }
    }

}
