package cn.xyz.listtool.auth;

import java.util.Set;

/**
 * 鉴权对象
 *
 * @author lvchenggang.
 * @date 2020/5/8 9:42
 * @see
 * @since
 */
public class AuthenDTO {

    private String loginName;

    private Set<String> roleKeySet;

    private Set<String> permExprSet;

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public Set<String> getRoleKeySet() {
        return roleKeySet;
    }

    public void setRoleKeySet(Set<String> roleKeySet) {
        this.roleKeySet = roleKeySet;
    }

    public Set<String> getPermExprSet() {
        return permExprSet;
    }

    public void setPermExprSet(Set<String> permExprSet) {
        this.permExprSet = permExprSet;
    }
}
