package cn.xyz.listtool.repository.g.mapper;

import java.sql.JDBCType;
import java.util.Date;
import javax.annotation.Generated;
import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

public final class ListtoolListInfoDynamicSqlSupport {
    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.081+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    public static final ListtoolListInfo listtoolListInfo = new ListtoolListInfo();

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.083+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_ID")
    public static final SqlColumn<Long> listId = listtoolListInfo.listId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.083+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.APP_ID")
    public static final SqlColumn<Long> appId = listtoolListInfo.appId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.084+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_NAME")
    public static final SqlColumn<String> listName = listtoolListInfo.listName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.084+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_DESC")
    public static final SqlColumn<String> listDesc = listtoolListInfo.listDesc;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.084+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.AUTH_TYPE")
    public static final SqlColumn<Integer> authType = listtoolListInfo.authType;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.084+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.AUTH_EXPR")
    public static final SqlColumn<String> authExpr = listtoolListInfo.authExpr;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.084+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.STATUS")
    public static final SqlColumn<Integer> status = listtoolListInfo.status;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.084+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_ID")
    public static final SqlColumn<Long> createId = listtoolListInfo.createId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.084+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_ID")
    public static final SqlColumn<Long> modifyId = listtoolListInfo.modifyId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.084+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_NAME")
    public static final SqlColumn<String> createName = listtoolListInfo.createName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.085+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_NAME")
    public static final SqlColumn<String> modifyName = listtoolListInfo.modifyName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.085+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_TIME")
    public static final SqlColumn<Date> createTime = listtoolListInfo.createTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.085+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_TIME")
    public static final SqlColumn<Date> modifyTime = listtoolListInfo.modifyTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.085+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CONTEXT")
    public static final SqlColumn<String> context = listtoolListInfo.context;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.085+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.DEBUG_PARAM")
    public static final SqlColumn<String> debugParam = listtoolListInfo.debugParam;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.082+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    public static final class ListtoolListInfo extends SqlTable {
        public final SqlColumn<Long> listId = column("LIST_ID", JDBCType.BIGINT);

        public final SqlColumn<Long> appId = column("APP_ID", JDBCType.BIGINT);

        public final SqlColumn<String> listName = column("LIST_NAME", JDBCType.VARCHAR);

        public final SqlColumn<String> listDesc = column("LIST_DESC", JDBCType.VARCHAR);

        public final SqlColumn<Integer> authType = column("AUTH_TYPE", JDBCType.TINYINT);

        public final SqlColumn<String> authExpr = column("AUTH_EXPR", JDBCType.VARCHAR);

        public final SqlColumn<Integer> status = column("STATUS", JDBCType.TINYINT);

        public final SqlColumn<Long> createId = column("CREATE_ID", JDBCType.BIGINT);

        public final SqlColumn<Long> modifyId = column("MODIFY_ID", JDBCType.BIGINT);

        public final SqlColumn<String> createName = column("CREATE_NAME", JDBCType.VARCHAR);

        public final SqlColumn<String> modifyName = column("MODIFY_NAME", JDBCType.VARCHAR);

        public final SqlColumn<Date> createTime = column("CREATE_TIME", JDBCType.TIMESTAMP);

        public final SqlColumn<Date> modifyTime = column("MODIFY_TIME", JDBCType.TIMESTAMP);

        public final SqlColumn<String> context = column("CONTEXT", JDBCType.LONGVARCHAR);

        public final SqlColumn<String> debugParam = column("DEBUG_PARAM", JDBCType.LONGVARCHAR);

        public ListtoolListInfo() {
            super("LISTTOOL_LIST_INFO");
        }
    }
}