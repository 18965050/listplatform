package cn.xyz.listtool.web.controller;

import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.ListReqDTO;
import cn.xyz.listtool.ListtoolUtils;
import cn.xyz.listtool.dto.QueryDTO;
import cn.xyz.medusa.client.MedusaPrincipal;
import cn.xyz.medusa.client.util.AuthUtils;
import com.ctrip.framework.apollo.ConfigService;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.AUTHEN_FAIL;
import static cn.xyz.listtool.constant.Const.URL_LIST_PREFIX;

/**
 * Demo Controller.展示后台如何通过{@link ListtoolUtils#request} 来请求列表平台
 *
 * @author lvchenggang.
 * @date 2020/2/5 8:13
 * @see
 * @since
 */
@Controller
@RequestMapping(URL_LIST_PREFIX)
public class DemoController {

    @Autowired
    private JsonMapper jsonMapper;

    private BaseResponseDTO realDemo(QueryDTO queryDTO, HttpServletRequest request, HttpServletResponse response) {
        ListReqDTO reqDTO = new ListReqDTO();
        reqDTO.setListId(2001L);
        reqDTO.setAppKey("demoKey");
        reqDTO.setAppSecret("demoPwd");
        reqDTO.setReqUrl(ConfigService.getAppConfig().getProperty("listtool.req.url", "http://list-d.xyz.cn/api/listtool/server"));
        reqDTO.setHttpConnTimeout(5000);
        reqDTO.setHttpSoTimeout(180000);
        if (MapUtils.isEmpty(queryDTO.getPlaceHolder())) {
            Map<String, Object> map = new HashMap<>();
            map.put("PARAMS", "");
            queryDTO.setPlaceHolder(map);
        }
        MedusaPrincipal currentPrincipal = AuthUtils.getCurrentPrincipal();
        if (currentPrincipal == null) {
            BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
            baseResponseDTO.setRet(AUTHEN_FAIL.value());
            baseResponseDTO.addError("认证失败");
            return baseResponseDTO;
        }
        Long userId = currentPrincipal.getUserId();
        reqDTO.setUserId(userId);
        reqDTO.setQueryDTO(queryDTO);
        return ListtoolUtils.request(request, response, reqDTO);
    }

    @RequestMapping(value = "demo", method = RequestMethod.GET)
    @ResponseBody
    public BaseResponseDTO demo(@RequestParam(value = "queryDTO", required = false) String queryDTOStr, HttpServletRequest request, HttpServletResponse response) {
        QueryDTO queryDTO = jsonMapper.fromJson(queryDTOStr, QueryDTO.class);
        return this.realDemo(queryDTO, request, response);
    }

    @RequestMapping(value = "demo", method = RequestMethod.POST)
    @ResponseBody
    public BaseResponseDTO demo(@RequestBody(required = false) QueryDTO queryDTO, HttpServletRequest request, HttpServletResponse response) {
        return this.realDemo(queryDTO, request, response);
    }

    @RequestMapping(value = "demo/policyStatusCount")
    @ResponseBody
    public BaseResponseDTO<Map<Integer, Integer>> getPolicyStatusCount() {
        BaseResponseDTO<Map<Integer, Integer>> baseResponseDTO = new BaseResponseDTO<>();
        Map<Integer, Integer> map = new HashMap<>();
        map.put(Integer.valueOf(1), RandomUtils.nextInt(0, 1000000));
        map.put(Integer.valueOf(2), RandomUtils.nextInt(0, 1000000));
        map.put(Integer.valueOf(3), RandomUtils.nextInt(0, 1000000));
        map.put(Integer.valueOf(4), RandomUtils.nextInt(0, 1000000));
        baseResponseDTO.setData(map);
        return baseResponseDTO;
    }
}
