package cn.xyz.listtool.config;

import cn.xyz.chaos.common.metrics.ConfiguredPrometheusMeterRegistryFactoryBean;
import cn.xyz.chaos.common.metrics.DruidMetricsInitialBean;
import cn.xyz.chaos.mvc.metrics.PrometheusServletBean;
import cn.xyz.chaos.mvc.metrics.WebMvcMetricsFilterFactoryBean;
import cn.xyz.listtool.constant.Const;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Khan
 */
@Configuration
public class MetricConfig {

    /**
     * 将PrometheusMeterRegistry转换为一个bean,供下面使用
     *
     * @return
     */
    @Bean
    ConfiguredPrometheusMeterRegistryFactoryBean meterRegistry() {
        return new ConfiguredPrometheusMeterRegistryFactoryBean();
    }

    /**
     * HTTP请求响应监控
     *
     * @param meterRegistry
     * @return
     */
    @Bean("webMvcMetricsFilter")
    WebMvcMetricsFilterFactoryBean webMvcMetricsFilterFactoryBean(MeterRegistry meterRegistry) {
        WebMvcMetricsFilterFactoryBean webMvcMetricsFilterFactoryBean = new WebMvcMetricsFilterFactoryBean();
        webMvcMetricsFilterFactoryBean.setMeterRegistry(meterRegistry);
        return webMvcMetricsFilterFactoryBean;
    }

    /**
     * 配合 {@link cn.xyz.chaos.mvc.spring.DelegatingServletProxy},用于metrics输出
     *
     * @return
     */
    @Bean("prometheusServlet")
    PrometheusServletBean prometheusServletBean() {
        PrometheusServletBean prometheusServletBean = new PrometheusServletBean();
        return prometheusServletBean;
    }

    @Bean
    DruidMetricsInitialBean druidMetricsInitialBean(MeterRegistry meterRegistry, DataSource dataSource) {
        DruidMetricsInitialBean druidMetricsInitialBean = new DruidMetricsInitialBean();
        druidMetricsInitialBean.setMeterRegistry(meterRegistry);
        druidMetricsInitialBean.setDataSource(dataSource);
        Map<String, String> tagMap = new HashMap<>();
        tagMap.put(Const.METRICS.DS.tags().toArray(new String[0])[0], "self");
        druidMetricsInitialBean.setTags(tagMap);
        return druidMetricsInitialBean;
    }

}
