package cn.xyz.listtool.script.function;

import cn.xyz.chaos.mvc.web.api.BizException;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.api.FieldFormatProvider;
import cn.xyz.listtool.api.FormatContext;
import cn.xyz.listtool.constant.Const.FIELD_FORMAT;
import cn.xyz.listtool.constant.Const.METRICS;
import cn.xyz.listtool.datasource.BizDataSource;
import cn.xyz.listtool.dto.ResultDTO;
import cn.xyz.listtool.dto.SpecDTO;
import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.utils.ReferenceConfigCache;
import com.alibaba.dubbo.rpc.cluster.support.FailoverCluster;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Timer;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static cn.xyz.listtool.constant.Const.DUBBO_CALL_TIMEOUT;

/**
 * <pre>
 *     结果字段<b>重新定义</b>器.会忽略列表sql查询出的字段结果,而使用当前记录作为CONTEXT来获取真正的值
 *     Pair格式: K(实际值):V(字面值)
 *     目前支持ql://配置方式
 * </pre>
 *
 * @author lvchenggang.
 * @date 2019/11/21 9:28
 * @see
 * @since
 */
public interface IFieldFormat {

    Pair<Object, String> formatField(Long listId, String pipelineName, Map<String, ResultDTO.FieldValueDTO> row, SpecDTO.FieldDTO fieldDTO, BizDataSource bizDS);
}

@Component
@Qualifier("qlFieldFormat")
class QlFieldFormat implements IFieldFormat {

    private static final String VAR_REGEX = "#\\w+#";

    private static final Pattern P = Pattern.compile(VAR_REGEX);

    @Autowired
    private MeterRegistry meterRegistry;

    @Override
    public Pair<Object, String> formatField(Long listId, String pipelineName, Map<String, ResultDTO.FieldValueDTO> row, SpecDTO.FieldDTO fieldDTO, BizDataSource bizDS) {
        String fieldFormat = fieldDTO.getResult().getFormat();
        String ql = fieldFormat.trim().substring(FIELD_FORMAT.QL.val().length());
        // (1)替换ql中的变量
        Matcher m = P.matcher(ql);
        List<Object> params = new ArrayList<>();
        while (m.find()) {
            String key = m.group().substring(1, m.group().length() - 1);
            params.add(row.getOrDefault(key, new ResultDTO.FieldValueDTO("#" + key + "#", "#" + key + "#")).getValue());
        }
        ql = ql.replaceAll(VAR_REGEX, "?");
        ArrayList<Tag> tags = new ArrayList<>(2);
        METRICS.FIELD_FORMAT.tags().forEach((tag) -> {
            if (tag.equals("dsName")) {
                tags.add(Tag.of(tag, bizDS.getDsName()));
            } else {
                tags.add(Tag.of(tag, listId + "-" + pipelineName + "-" + fieldDTO.getKey()));
            }
        });
        Timer.Sample invokerSample = Timer.start(meterRegistry);
        Pair<Object, String> pair = bizDS.getJdbcTemplate().queryForObject(ql, params.toArray(), (rs, rowNum) -> {
            int columnCount = rs.getMetaData().getColumnCount();
            if (columnCount != 2) {
                throw new BizException(String.format("字段(%s)fieldFormat返回数据结构不正确", fieldDTO.getKey()));
            } else {
                return Pair.of(rs.getObject(1), String.valueOf(rs.getObject(2)));
            }
        });
        invokerSample.stop(meterRegistry.timer(METRICS.FIELD_FORMAT.metric(), tags));
        return pair;
    }

    public static void main(String[] args) {
        String ql = "select * from #aa# where #cc# and #bb# order by #dd#";
        Map<String, Object> map = new HashMap<>();
        List<Object> params = new ArrayList<>();
        map.put("aa", 1);
        map.put("bb", "test");
        map.put("cc", "23");
        Matcher m = P.matcher(ql);

        while (m.find()) {
            String key = m.group().substring(1, m.group().length() - 1);
            params.add(map.getOrDefault(key, "#" + key + "#"));
        }
        System.out.println(ql.replaceAll(VAR_REGEX, "?"));
        System.out.println(params);

    }
}

@Component
@Qualifier("dubboFieldFormat")
class DubboFieldFormat implements IFieldFormat {

    @Autowired
    private ApplicationConfig applicationConfig;

    @Autowired
    private RegistryConfig registryConfig;

    @Autowired
    private JsonMapper jsonMapper;

    @Override
    public Pair<Object, String> formatField(Long listId, String pipelineName, Map<String, ResultDTO.FieldValueDTO> row, SpecDTO.FieldDTO fieldDTO, BizDataSource bizDS) {
        String fieldFormat = fieldDTO.getResult().getFormat();
        String formatJson = fieldFormat.trim().substring(FIELD_FORMAT.DUBBO.val().length());
        FormatContext formatContext = jsonMapper.fromJson(formatJson, FormatContext.class);
        ReferenceConfig<FieldFormatProvider> reference = new ReferenceConfig<FieldFormatProvider>();
        reference.setApplication(applicationConfig);
        reference.setRegistry(registryConfig); // 多个注册中心可以用setRegistries()
        reference.setInterface(FieldFormatProvider.class);
        reference.setTimeout(DUBBO_CALL_TIMEOUT);
        reference.setCluster(FailoverCluster.NAME);

        // 设置分组
        reference.setGroup(formatContext.getGroupName());
        reference.setCheck(false);
        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        FieldFormatProvider service = cache.get(reference);
        formatContext.setListId(listId);
        formatContext.setFieldKey(fieldDTO.getKey());
        return service.formatField(formatContext, row);
    }
}
