package cn.xyz.listtool.script.js;

import cn.xyz.chaos.mvc.web.api.BizException;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.script.ScriptEngine;
import org.springframework.stereotype.Component;

import javax.script.ScriptContext;
import javax.script.ScriptEngineManager;
import javax.script.SimpleBindings;
import javax.script.SimpleScriptContext;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/**
 * JavaScript 脚本引擎
 *
 * @author lvchenggang.
 * @date 2020/4/16 9:58
 * @see
 * @since
 */
@Component("jsScriptEngine")
public class JSScriptEngine implements ScriptEngine {

    private javax.script.ScriptEngine nashorn;

    private String preDefinedScript;

    @Override
    public void setup() {
        ScriptEngineManager scriptEngineManager = new ScriptEngineManager();
        nashorn = scriptEngineManager.getEngineByName("nashorn");
        String lodashPath = Thread.currentThread().getContextClassLoader().getResource("javascript/lodash.min.js").getPath();
        preDefinedScript = String.format("load('%s');\n", lodashPath);
        preDefinedScript += "const execMapping=Java.type('cn.xyz.listtool.script.function.FunctionUtils').execMapping;\n";
        preDefinedScript += "const execQl=Java.type('cn.xyz.listtool.script.function.FunctionUtils').execQl;\n";
        preDefinedScript += "const mergeTempRes=Java.type('cn.xyz.listtool.script.function.FunctionUtils').mergeTempRes;\n";
        preDefinedScript += "const generateRes=Java.type('cn.xyz.listtool.script.function.FunctionUtils').generateRes;\n";
        preDefinedScript += "const dubboCall=Java.type('cn.xyz.listtool.script.function.FunctionUtils').dubboCall;\n";
    }

    @Override
    public <T> T exec(String express, Map<String, Object> context) {
        SimpleBindings simpleBindings = new SimpleBindings();
        simpleBindings.put(Const.CONTEXT.SELF.val(), context);
        ScriptContext scriptContext = new SimpleScriptContext();
        scriptContext.setBindings(simpleBindings, ScriptContext.ENGINE_SCOPE);
        try {
            return (T) nashorn.eval(this.preDefinedScript + express, scriptContext);
        } catch (Exception e) {
            logger.error("JS脚本引擎脚本执行失败:", e);
            String exMsg = e.getMessage();
            Throwable cause = e.getCause();
            if (cause != null) {
                exMsg = cause.getMessage();
                if (cause instanceof InvocationTargetException) {
                    exMsg = ((InvocationTargetException) cause).getTargetException().getMessage();
                }
            }
            throw new BizException(exMsg);
        }
    }
}
