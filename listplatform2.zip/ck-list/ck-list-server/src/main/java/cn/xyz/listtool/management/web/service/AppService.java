package cn.xyz.listtool.management.web.service;

import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.aop.SupplyAudit;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.management.web.dto.AppDTO;
import cn.xyz.listtool.repository.AppRepository;
import com.alicp.jetcache.Cache;
import com.alicp.jetcache.anno.CacheType;
import com.alicp.jetcache.anno.CreateCache;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR;
import static cn.xyz.listtool.aop.SupplyAudit.OpType.ADD;
import static cn.xyz.listtool.aop.SupplyAudit.OpType.UPDATE;
import static cn.xyz.listtool.constant.Const.CACHE_APP_NAME;

/**
 * @author lvchenggang.
 * @date 2019/11/27 15:14
 * @see
 * @since
 */
@Service
public class AppService {

    @Autowired
    private AppRepository appRepo;

    @CreateCache(name = CACHE_APP_NAME, cacheType = CacheType.REMOTE)
    private Cache<Long, AppDTO> appCache;

    @Autowired
    private JsonMapper jsonMapper;

    @SupplyAudit(ADD)
    public AppDTO add(AppDTO appDTO) {
        int i = this.appRepo.add(appDTO);
        if (i != 1) {
            throw new RuntimeException(String.format("添加业务应用(appName:%s)失败.", appDTO.getAppName()));
        }
        appCache.computeIfAbsent(appDTO.getAppId(), appRepo::selectByPrimaryKey);
        return appDTO;
    }

    @SupplyAudit(UPDATE)
    public AppDTO update(AppDTO appDTO) {
        int i = this.appRepo.update(appDTO);
        if (i != 1) {
            throw new RuntimeException(String.format("修改业务应用(appId:%d,appName:%s)失败.", appDTO.getAppId(), appDTO.getAppName()));
        }
        appCache.remove(appDTO.getAppId());
        appCache.computeIfAbsent(appDTO.getAppId(), appRepo::selectByPrimaryKey);
        return appDTO;
    }

    public AppDTO detail(Long appId) {
        return this.appRepo.selectByPrimaryKey(appId);
    }

    public Map<Long, String> getAppIds() {
        Map<Long, String> map = new LinkedHashMap<>();
        List<AppDTO> appDTOS = this.appRepo.getAllValidAppIds();
        if (CollectionUtils.isNotEmpty(appDTOS)) {
            appDTOS.forEach(appDTO -> {
                map.put(appDTO.getAppId(), appDTO.getAppId() + "(" + appDTO.getAppName() + ")");
            });
        }
        return map;
    }

    public String exportRows(List<Long> appIds) {
        List<AppDTO> appDTOS = this.appRepo.selectByAppIds(appIds);
        StringBuilder sb = new StringBuilder("{\"" + Const.IMPORT_DATATYPE.APP.val() + "\":");
        sb.append(jsonMapper.toJson(appDTOS));
        sb.append("}");
        return sb.toString();
    }

    public BaseResponseDTO<Void> importData(String json) {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        try {
            Map<String, List> map = jsonMapper.fromJson(json, Map.class);
            if (map.containsKey(Const.IMPORT_DATATYPE.APP.val())) {
                List<AppDTO> appDTOS = new ArrayList<>();
                map.get(Const.IMPORT_DATATYPE.APP.val()).forEach(appMap -> {
                    appDTOS.add(jsonMapper.fromJson(jsonMapper.toJson(appMap), AppDTO.class));
                });
                this.appRepo.importData(appDTOS);
            }
        } catch (Exception e) {
            baseResponseDTO.setRet(BIZ_ERROR.value());
            baseResponseDTO.addError(String.format("导入文件数据格式不正确或导入数据错误(errMsg:%s)", e.getMessage()));
        }
        return baseResponseDTO;
    }

}
