package cn.xyz.listtool.repository.g.entity;

import java.util.Date;
import javax.annotation.Generated;

public class ListtoolAppInfo {
    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.196+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_ID")
    private Long appId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.201+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_NAME")
    private String appName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.201+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_KEY")
    private String appKey;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.201+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_SECRET")
    private String appSecret;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.STATUS")
    private Integer status;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.CREATE_ID")
    private Long createId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.MODIFY_ID")
    private Long modifyId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.CREATE_NAME")
    private String createName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.203+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.MODIFY_NAME")
    private String modifyName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.203+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.CREATE_TIME")
    private Date createTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.203+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.MODIFY_TIME")
    private Date modifyTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.2+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_ID")
    public Long getAppId() {
        return appId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.201+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_ID")
    public void setAppId(Long appId) {
        this.appId = appId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.201+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_NAME")
    public String getAppName() {
        return appName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.201+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_NAME")
    public void setAppName(String appName) {
        this.appName = appName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.201+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_KEY")
    public String getAppKey() {
        return appKey;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.201+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_KEY")
    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.201+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_SECRET")
    public String getAppSecret() {
        return appSecret;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.APP_SECRET")
    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.STATUS")
    public Integer getStatus() {
        return status;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.STATUS")
    public void setStatus(Integer status) {
        this.status = status;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.CREATE_ID")
    public Long getCreateId() {
        return createId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.CREATE_ID")
    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.MODIFY_ID")
    public Long getModifyId() {
        return modifyId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.MODIFY_ID")
    public void setModifyId(Long modifyId) {
        this.modifyId = modifyId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.CREATE_NAME")
    public String getCreateName() {
        return createName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.202+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.CREATE_NAME")
    public void setCreateName(String createName) {
        this.createName = createName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.203+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.MODIFY_NAME")
    public String getModifyName() {
        return modifyName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.203+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.MODIFY_NAME")
    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.203+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.CREATE_TIME")
    public Date getCreateTime() {
        return createTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.203+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.CREATE_TIME")
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.203+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.MODIFY_TIME")
    public Date getModifyTime() {
        return modifyTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-30T08:12:14.203+08:00", comments="Source field: listtool..LISTTOOL_APP_INFO.MODIFY_TIME")
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}