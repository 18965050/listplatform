package cn.xyz.listtool.management.web.controller;

import cn.xyz.chaos.mvc.web.api.BaseController;
import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.constant.Const.PIPELINE_TYPE;
import cn.xyz.listtool.constant.Const.SEARCH_DATATYPE;
import cn.xyz.listtool.constant.Const.SEARCH_MATCH;
import cn.xyz.listtool.dto.QueryDTO;
import cn.xyz.listtool.management.web.dto.ListDTO;
import cn.xyz.listtool.management.web.service.ListService;
import cn.xyz.listtool.utils.DownloadUtils;
import cn.xyz.listtool.web.service.ListtoolService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR;
import static cn.xyz.listtool.ListConst.EXPORT_TOKEN;
import static cn.xyz.listtool.ListConst.LIST_OPER.EXPORT_YES;
import static cn.xyz.listtool.constant.Const.IMPORT_DATATYPE.LIST;

/**
 * @author lvchenggang.
 * @date 2019/11/28 9:55
 * @see
 * @since
 */
@RestController
@RequestMapping("/management/list")
@RequiresPermissions({"list:list"})
public class ListController extends BaseController {

    @Autowired
    private ListService listService;

    @Autowired
    private ListtoolService listtoolService;

    @RequestMapping(path = "/detail", method = RequestMethod.GET)
    public BaseResponseDTO<ListDTO> detail(@RequestParam("listId") Long listId) {
        return this.returnWithSuccess(this.listService.detail(listId));
    }

    @RequestMapping(path = "/add", method = RequestMethod.POST)
    public BaseResponseDTO<ListDTO> add(@Validated(ListDTO.GroupAdd.class) @RequestBody ListDTO listDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return this.returnWithCheckFail(bindingResult.getAllErrors());
        }
        return this.returnWithSuccess(listService.add(listDTO));
    }

    @RequestMapping(path = "/update", method = RequestMethod.POST)
    public BaseResponseDTO<ListDTO> update(@Validated(ListDTO.GroupModify.class) @RequestBody ListDTO listDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return this.returnWithCheckFail(bindingResult.getAllErrors());
        }
        return this.returnWithSuccess(listService.update(listDTO));
    }

    @RequestMapping(path = "/changeStatus", method = RequestMethod.POST)
    public BaseResponseDTO<ListDTO> changeStatus(@Validated(ListDTO.GroupChangeStatus.class) @RequestBody ListDTO listDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return this.returnWithCheckFail(bindingResult.getAllErrors());
        }
        ListDTO listDTO1 = new ListDTO();
        listDTO1.setListId(listDTO.getListId());
        listDTO1.setStatus(listDTO.getStatus());
        return this.returnWithSuccess(listService.changeStatus(listDTO1));
    }

    @RequestMapping(path = "/getSearchDataType", method = RequestMethod.GET)
    public BaseResponseDTO<Map<Integer, String>> getSearchDataType() {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        Map<Integer, String> dataMap = new LinkedHashMap<>();
        baseResponseDTO.setData(dataMap);
        for (SEARCH_DATATYPE dataType : SEARCH_DATATYPE.values()) {
            dataMap.put(dataType.val(), dataType.desc());
        }
        return baseResponseDTO;
    }

    @RequestMapping(path = "/getSearchMatch", method = RequestMethod.GET)
    public BaseResponseDTO<Map<Integer, String>> getSearchMatch() {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        Map<Integer, String> dataMap = new LinkedHashMap<>();
        baseResponseDTO.setData(dataMap);
        for (SEARCH_MATCH searchMatch : SEARCH_MATCH.values()) {
            dataMap.put(searchMatch.val(), searchMatch.desc());
        }
        return baseResponseDTO;
    }

    @RequestMapping(path = "/getPipelineType", method = RequestMethod.GET)
    public BaseResponseDTO<Map<String, String>> getPipelineType() {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        Map<String, String> dataMap = new LinkedHashMap<>();
        baseResponseDTO.setData(dataMap);
        for (PIPELINE_TYPE pipelineType : PIPELINE_TYPE.values()) {
            dataMap.put(pipelineType.val(), pipelineType.desc());
        }
        return baseResponseDTO;
    }


    @RequestMapping(value = "debug")
    @ResponseBody
    public <T> BaseResponseDTO<T> debug(HttpServletRequest request, @RequestBody ListDTO listDTO) {
        QueryDTO queryDTO = listDTO.getQueryDTO();
        if (queryDTO == null) {
            queryDTO = new QueryDTO();
            listDTO.setQueryDTO(queryDTO);
        }
        Long listId = listDTO.getListId();
        ListtoolService.requisiteQueryDTO(queryDTO, listId);
        if (queryDTO.getOper().containsKey(EXPORT_YES.key()) && EXPORT_YES.val() == queryDTO.getOper().get(EXPORT_YES.key())) {
            String exportToken = request.getParameter(EXPORT_TOKEN);
            return (BaseResponseDTO<T>) this.listtoolService.export(listId, listDTO, queryDTO, exportToken);
        }
        return (BaseResponseDTO<T>) this.listtoolService.pageList(null, listDTO, queryDTO);
    }

    @RequestMapping(value = "pipelineDebug")
    @ResponseBody
    public BaseResponseDTO<Map<String, Map<String, Object>>> pipelineDebug(@RequestBody ListDTO listDTO) {
        QueryDTO queryDTO = listDTO.getQueryDTO();
        if (queryDTO == null) {
            queryDTO = new QueryDTO();
            listDTO.setQueryDTO(queryDTO);
        }
        ListtoolService.requisiteQueryDTO(queryDTO, listDTO.getListId());
        return this.listtoolService.pipelineDebug(listDTO);
    }


    @RequestMapping(path = "/exportRows", method = RequestMethod.GET)
    public void exportRows(HttpServletRequest request, HttpServletResponse response, @RequestParam("listIds") List<Long> listIds) throws UnsupportedEncodingException {
        String json = this.listService.exportRows(listIds);
        DownloadUtils.down(LIST.fileName(), json.getBytes("UTF-8"), request, response);
    }

    @RequestMapping(path = "/importData", method = RequestMethod.POST)
    public BaseResponseDTO<Void> importData(@RequestParam("file") MultipartFile multipartFile) throws IOException {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        if (multipartFile == null || !(multipartFile.getBytes().length > 0)) {
            return returnWithFail(BIZ_ERROR.value(), Arrays.asList(new String[]{"导入文件为空"}));
        }
        String json = new String(multipartFile.getBytes(), "UTF-8");
        return this.listService.importData(json);
    }

}
