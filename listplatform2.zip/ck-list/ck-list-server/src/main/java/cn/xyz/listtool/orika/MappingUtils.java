package cn.xyz.listtool.orika;

import cn.xyz.chaos.common.utils.SpringContextUtils;
import cn.xyz.chaos.orm.mybatis.easylist.paginator.domain.PageBounds;
import cn.xyz.chaos.orm.mybatis.easylist.paginator.domain.PageList;
import cn.xyz.chaos.orm.mybatis.easylist.paginator.domain.Paginator;
import cn.xyz.io.admin.auth.api.base.dto.PageListDTO;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Khan
 */
public final class MappingUtils {

    private static MapperFacade mapperFacade;

    private MappingUtils() {}

    /**
     * bean 集合转换
     *
     * @param sourceList 源集合
     * @param destClass 目标集合的类
     * @return 目标集合,not null
     */
    public static <T, K> List<K> beanListConvert(List<T> sourceList, Class<K> destClass) {
        List<K> destList = new ArrayList<K>();
        if (CollectionUtils.isNotEmpty(sourceList)) {
            for (T source : sourceList) {
                destList.add(beanConvert(source, destClass));
            }
        }
        return destList;
    }

    /**
     * bean转换
     *
     * @param source 源
     * @param destClass 目标类
     * @return 目标
     */
    public static <T, K> K beanConvert(T source, Class<K> destClass) {
        return getMapperFacade().map(source, destClass);
    }

    /**
     * bean转换
     *
     * @param source 源
     * @param destObj 目标对象
     */
    public static <T, K> void beanConvert(T source, K destObj) {
        getMapperFacade().map(source, destObj);
    }

    private static MapperFacade getMapperFacade() {
        if (null == mapperFacade) {
            synchronized (MappingUtils.class) {
                if (null == mapperFacade) {
                    mapperFacade = SpringContextUtils.getBean(MapperFacade.class);
                }
            }
        }
        return mapperFacade;
    }

    public static <T, K> PageListDTO<K> pageList2PageListDTO(PageList<T> pageList, Class<K> destClass) {
        PageListDTO<K> rs = new PageListDTO<>();
        if (CollectionUtils.isNotEmpty(pageList)) {
            Paginator paginator = pageList.getPaginator();
            if (null != paginator) {
                rs.setCurrentPage(paginator.getPage());
                rs.setTotalPage(paginator.getTotalPages());
                rs.setTotalCount(paginator.getTotalCount());
            } else { // 当PageBounds实例化时不采用分页的方式时, PageList走的是默认构造函数实例化的, 此时paginator为null
                rs.setCurrentPage(PageBounds.NO_PAGE);
                rs.setTotalPage(PageBounds.NO_PAGE);
                rs.setTotalCount(pageList.size());
            }

        } else {
            rs.setCurrentPage(0);
            rs.setTotalPage(0);
            rs.setTotalCount(0);
        }

        if (CollectionUtils.isNotEmpty(pageList) && (!pageList.get(0).getClass().equals(destClass))) {
            rs.setDataList(beanListConvert(pageList, destClass));
        } else {
            // noinspection unchecked
            rs.setDataList((List<K>) pageList);
        }
        return rs;
    }

}
