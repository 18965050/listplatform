package cn.xyz.listtool.repository.dao;

import cn.xyz.chaos.orm.mybatis.MyBatisRepository;
import cn.xyz.chaos.orm.mybatis.easylist.paginator.domain.PageBounds;
import cn.xyz.chaos.orm.mybatis.easylist.paginator.domain.PageList;
import cn.xyz.listtool.repository.g.entity.ListtoolListInfo;
import cn.xyz.listtool.repository.g.mapper.ListtoolListInfoMapper;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
@MyBatisRepository
public interface ListtoolListInfoDAO extends ListtoolListInfoMapper {


    @Select("SELECT LIST_ID listId,APP_ID appId,LIST_NAME listName," +
        "LIST_DESC listDesc,AUTH_TYPE authType,AUTH_EXPR authExpr,STATUS status," +
        "CREATE_NAME createName,MODIFY_NAME modifyName,CREATE_TIME createTime,MODIFY_TIME modifyTime FROM LISTTOOL_LIST_INFO")
    @ResultType(ListtoolListInfo.class)
    public PageList<ListtoolListInfo> pageListBySelective(PageBounds pageBounds);

    @Delete("<script>" +
        "DELETE FROM LISTTOOL_LIST_INFO WHERE LIST_ID IN " +
        "<foreach collection='listIds' item='listId' open='(' close=')' separator=','>" +
        "#{listId}" +
        "</foreach>" +
        "</script>")
    public void deleteByListIds(@Param("listIds") List<Long> listIds);

    @Insert("<script>" +
        "INSERT INTO LISTTOOL_LIST_INFO(LIST_ID,APP_ID,LIST_NAME,LIST_DESC,AUTH_TYPE,AUTH_EXPR,CONTEXT,DEBUG_PARAM,STATUS,CREATE_ID,MODIFY_ID,CREATE_NAME,MODIFY_NAME,CREATE_TIME,MODIFY_TIME) VALUES " +
        "<foreach collection='listDTOs' item='listDTO' separator=','>" +
        "(#{listDTO.listId},#{listDTO.appId},#{listDTO.listName},#{listDTO.listDesc},#{listDTO.authType},#{listDTO.authExpr},#{listDTO.context},#{listDTO.debugParam},#{listDTO.status},#{listDTO.createId},#{listDTO.modifyId},#{listDTO.createName},#{listDTO.modifyName},#{listDTO.createTime},#{listDTO.modifyTime} )" +
        "</foreach>" +
        "</script>")
    public void batchInsert(@Param("listDTOs") List<ListtoolListInfo> lists);
}
