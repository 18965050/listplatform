package cn.xyz.listtool.repository.dao;

import cn.xyz.chaos.orm.mybatis.MyBatisRepository;
import cn.xyz.listtool.repository.g.entity.ListtoolAppInfo;
import cn.xyz.listtool.repository.g.entity.ListtoolDatasourceInfo;
import cn.xyz.listtool.repository.g.mapper.ListtoolDatasourceInfoMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
@MyBatisRepository
public interface ListtoolDatasourceInfoDAO extends ListtoolDatasourceInfoMapper {
    @Delete("<script>" +
        "DELETE FROM LISTTOOL_DATASOURCE_INFO WHERE DS_ID IN " +
        "<foreach collection='dsIds' item='dsId' open='(' close=')' separator=','>" +
        "#{dsId}" +
        "</foreach>" +
        "</script>")
    public void deleteByDsIds(@Param("dsIds") List<Long> dsIds);

    @Insert("<script>" +
        "INSERT INTO LISTTOOL_DATASOURCE_INFO(DS_ID,DS_NAME,DS_TYPE,DS_DESC,STATUS,CREATE_ID,MODIFY_ID,CREATE_NAME,MODIFY_NAME,CREATE_TIME,MODIFY_TIME) VALUES " +
        "<foreach collection='dsDTOs' item='dsDTO' separator=','>" +
        "(#{dsDTO.dsId},#{dsDTO.dsName},#{dsDTO.dsType},#{dsDTO.dsDesc},#{dsDTO.status},#{dsDTO.createId},#{dsDTO.modifyId},#{dsDTO.createName},#{dsDTO.modifyName},#{dsDTO.createTime},#{dsDTO.modifyTime} )" +
        "</foreach>" +
        "</script>")
    public void batchInsert(@Param("dsDTOs") List<ListtoolDatasourceInfo> dss);

}
