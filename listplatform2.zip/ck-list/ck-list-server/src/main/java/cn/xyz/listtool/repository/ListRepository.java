package cn.xyz.listtool.repository;

import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.management.web.dto.ListDTO;
import cn.xyz.listtool.orika.MappingUtils;
import cn.xyz.listtool.repository.dao.ListtoolListInfoDAO;
import cn.xyz.listtool.repository.g.entity.ListtoolListInfo;
import com.alicp.jetcache.anno.Cached;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static cn.xyz.listtool.constant.Const.CACHE_LIST_NAME;
import static cn.xyz.listtool.repository.g.mapper.ListtoolListInfoDynamicSqlSupport.listtoolListInfo;
import static org.mybatis.dynamic.sql.SqlBuilder.isIn;

/**
 * @author lvchenggang.
 * @date 2019/11/28 9:32
 * @see
 * @since
 */
@Repository
public class ListRepository {

    @Autowired
    private ListtoolListInfoDAO listDao;

    @Cached(name = CACHE_LIST_NAME, key = "#listId")
    public ListDTO selectByPrimaryKey(Long listId) {
        ListtoolListInfo listInfo = this.listDao.selectByPrimaryKey(listId);
        return MappingUtils.beanConvert(listInfo, ListDTO.class);
    }

    public int add(ListDTO listDTO) {
        Integer authType = listDTO.getAuthType();
        if (authType != Const.AUTH_TYPE.MEDUSA.val()) {
            listDTO.setAuthExpr(null);
        }
        ListtoolListInfo listInfo = MappingUtils.beanConvert(listDTO, ListtoolListInfo.class);
        int res = this.listDao.insertSelective(listInfo);
        listDTO.setListId(listInfo.getListId());
        return res;
    }

    public int update(ListDTO listDTO, boolean isSelective) {
        Integer authType = listDTO.getAuthType();
        if (authType != null && authType != Const.AUTH_TYPE.MEDUSA.val()) {
            listDTO.setAuthExpr(null);
        }
        ListtoolListInfo listInfo = MappingUtils.beanConvert(listDTO, ListtoolListInfo.class);
        if (isSelective) {
            return this.listDao.updateByPrimaryKeySelective(listInfo);
        } else {
            return this.listDao.updateByPrimaryKey(listInfo);
        }
    }

    public List<ListDTO> selectByListIds(List<Long> listIds) {
        List<ListtoolListInfo> listInfos = this.listDao.selectByExample().where(listtoolListInfo.listId, isIn(listIds)).build().execute();
        return MappingUtils.beanListConvert(listInfos, ListDTO.class);
    }

    @Transactional
    public void importData(List<ListDTO> listDTOS) {
        if (CollectionUtils.isNotEmpty(listDTOS)) {
            List<Long> listIds = new ArrayList<>();
            List<ListtoolListInfo> listInfos = MappingUtils.beanListConvert(listDTOS, ListtoolListInfo.class);
            listDTOS.forEach(listDTO -> {
                listIds.add(listDTO.getListId());
            });
            this.listDao.deleteByListIds(listIds);
            this.listDao.batchInsert(listInfos);
        }
    }
}
