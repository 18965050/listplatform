package cn.xyz.listtool.script;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * 脚本引擎，用于动态执行 flow 上的脚本和 iface 上的脚本，以实现动态组装流程
 */
public interface ScriptEngine {

    Logger logger = LoggerFactory.getLogger(ScriptEngine.class.getName());

    /**
     * 初始化
     */
    @PostConstruct
    default void setup() {};

    /**
     * 执行
     * @param express
     * @param context
     * @param <T>
     * @return
     */
    <T> T exec(String express, Map<String, Object> context);

    /**
     * 销毁
     */
    @PreDestroy
    default void destroy() {};
}
