package cn.xyz.listtool.script.function;

import cn.xyz.chaos.common.utils.SpringContextUtils;
import cn.xyz.listtool.constant.Const.CONTEXT;
import cn.xyz.listtool.constant.Const.FIELD_MAPPING;
import cn.xyz.listtool.datasource.BizDataSource;
import cn.xyz.listtool.datasource.DataSourceManager;
import cn.xyz.listtool.dto.SpecDTO;
import cn.xyz.listtool.pipeline.ExecMappingParam;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static cn.xyz.listtool.constant.Const.ALL_FIELDS;

/**
 * 执行字段映射的函数
 *
 * @author lvchenggang.
 * @date 2020/3/12 16:29
 * @see
 * @since
 */
@Component
public class ExecMappingFunction extends AbstractFunction<ExecMappingParam, Void> {

    public Void innerExec(Map<String, Object> context, SpecDTO.PipeLineDTO pipelineDTO, ExecMappingParam execMappingParam, Map<String, Object> logMap) {
        List<SpecDTO.FieldDTO> logDTOList = new ArrayList<>();
        String listId = String.valueOf(context.get(CONTEXT.ID.val()));
        String pipelineName = pipelineDTO.getName();
        String dsName = execMappingParam.getDs();
        Set<String> mappingFields = execMappingParam.getMappingFields();
        if (CollectionUtils.isNotEmpty(mappingFields)) {
            DataSourceManager dsManager = SpringContextUtils.getBean(DataSourceManager.class);
            BizDataSource bizDS = dsManager.get(dsName);
            List<SpecDTO.FieldDTO> fieldDTOS = ((SpecDTO) context.get(CONTEXT.SPEC.val())).getFields();
            if (CollectionUtils.isNotEmpty(fieldDTOS)) {
                fieldDTOS.stream().filter(fieldDTO -> {
                    return (mappingFields.contains(ALL_FIELDS) || mappingFields.contains(fieldDTO.getKey())) && StringUtils.isNotBlank(fieldDTO.getMapping());
                }).forEach(fieldDTO -> {
                    String mapping = fieldDTO.getMapping();
                    IFieldMapper searchMapper = null;
                    if (mapping.trim().startsWith(FIELD_MAPPING.JSON.val())) {
                        searchMapper = SpringContextUtils.getBean("jsonFieldMapper");
                    } else if (mapping.trim().startsWith(FIELD_MAPPING.QL.val())) {
                        searchMapper = SpringContextUtils.getBean("qlFieldMapper");
                    } else if (mapping.trim().startsWith(FIELD_MAPPING.DUBBO.val())) {
                        searchMapper = SpringContextUtils.getBean("dubboFieldMapper");
                    } else {
                        String errInfo = String.format("不支持的查询映射(mapping:%s)", mapping);
                        logger.error(errInfo);
                        throw new RuntimeException(errInfo);
                    }
                    fieldDTO.setMapping(searchMapper.mapping(Long.valueOf(listId), pipelineName, fieldDTO, bizDS));
                    SpecDTO.FieldDTO resDTO = new SpecDTO.FieldDTO();
                    resDTO.setKey(fieldDTO.getKey());
                    resDTO.setMapping(fieldDTO.getMapping());
                    logDTOList.add(resDTO);
                });
            }
        }
        logMap.put(this.getName(), logDTOList);
        return null;
    }
}
