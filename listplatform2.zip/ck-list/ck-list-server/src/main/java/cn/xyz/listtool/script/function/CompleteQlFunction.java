package cn.xyz.listtool.script.function;

import cn.xyz.chaos.common.utils.SpringContextUtils;
import cn.xyz.listtool.datasource.BizDataSource;
import cn.xyz.listtool.datasource.DataSourceManager;
import cn.xyz.listtool.dto.QueryDTO;
import cn.xyz.listtool.dto.SpecDTO;
import cn.xyz.listtool.pipeline.CompleteQlParam;
import cn.xyz.listtool.web.dto.TempsDTO;
import cn.xyz.listtool.web.dto.TempsDTO.TempDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.tools.ToolContext;
import org.apache.velocity.tools.ToolManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.StringWriter;
import java.sql.Date;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

import static cn.xyz.listtool.ListConst.LIST_OPER;
import static cn.xyz.listtool.ListConst.PARAM_VALUE_SPLITTER;
import static cn.xyz.listtool.constant.Const.*;

/**
 * 获取查询QL函数
 *
 * @author lvchenggang.
 * @date 2019/11/18 14:48
 * @see
 * @since
 */
public abstract class CompleteQlFunction extends AbstractFunction<CompleteQlParam, TempDTO> {

    @Autowired
    private VelocityEngine ve;

    @Autowired
    private ToolManager toolManager;

    abstract protected void wrapPagenator(TempDTO tempDTO, Integer offset, Integer limit);

    abstract protected String wrapQl(String ql);

    public static CompleteQlFunction getInstance(String dsName) {
        DataSourceManager dsManager = SpringContextUtils.getBean(DataSourceManager.class);
        BizDataSource bizDS = dsManager.get(dsName);
        CompleteQlFunction completeQlFunction = null;
        switch (bizDS.getDsType()) {
            case DATASOURCE.ORACLE:
                completeQlFunction = SpringContextUtils.getBean("oracleCompleteQlFunction");
                break;
            case DATASOURCE.MYSQL:
                completeQlFunction = SpringContextUtils.getBean("mySqlCompleteQlFunction");
                break;
            default:
                throw new RuntimeException("未找到对应的数据源类型");
        }
        return completeQlFunction;
    }

    public TempDTO innerExec(Map<String, Object> context, SpecDTO.PipeLineDTO pipeLineDTO, CompleteQlParam completeQlParam, Map<String, Object> logMap) {
        QueryDTO queryDTO = (QueryDTO) context.get(CONTEXT.QUERY.val());
        boolean needCompleteQl = queryDTO.getOper().get(LIST_OPER.EXEC_NO.key()) == LIST_OPER.EXEC_NO.val() ? false : true;
        SpecDTO specDTO = (SpecDTO) context.get(CONTEXT.SPEC.val());
        final TempsDTO tempsDTO = (TempsDTO) context.get(CONTEXT.TEMPS.val());
        Map<String, TempDTO> tempDTOMap = tempsDTO.getTempDTOMap();
        String pipeLineName = pipeLineDTO.getName();
        Optional<TempDTO> tempDTOOptional = Optional.ofNullable(tempDTOMap.get(pipeLineName));
        TempDTO tempDTO = tempDTOOptional.orElseGet(() -> {
            TempDTO newTempDTO = new TempDTO();
            tempDTOMap.put(pipeLineName, newTempDTO);
            return newTempDTO;
        });
        // (0) 将QueryDTO中的placeHolder添加到CompleteQlParam的placeHolder中
        Map<String, Object> queryPH = queryDTO.getPlaceHolder();
        Map<String, Object> paramPH = (Map<String, Object>) context.get(CONTEXT.QL_PLACEHOLDER.val());
        if (MapUtils.isNotEmpty(queryPH)) {
            if (MapUtils.isNotEmpty(paramPH)) {
                paramPH.putAll(queryPH);
            } else {
                context.put(CONTEXT.QL_PLACEHOLDER.val(), queryPH);
            }
        }
        // (1) replaceHolder替换
        Map<String, Object> placeHolder = (Map<String, Object>) context.get(CONTEXT.QL_PLACEHOLDER.val());
        String ql = this.placeHolderReplace(completeQlParam.getQl(), placeHolder);
        // (2)组装查询条件
        // (2.1)先过滤掉非此pipeline的查询参数及排序字段
        Map<String, String> pipelineQueryParams = new LinkedHashMap<>();
        Map<String, QueryDTO.ParamDTO> queryParamMap = queryDTO.getParam();
        Set<String> plQueries = completeQlParam.getQueries();
        if (CollectionUtils.isNotEmpty(plQueries)) {
            List<SpecDTO.FieldDTO> searchFields = specDTO.getFields().stream().filter(fieldDTO -> {
                return fieldDTO.getSearch() != null;
            }).collect(Collectors.toList());
            for (String plQuery : plQueries) {
                //从queryDTO中获取
                if (MapUtils.isNotEmpty(queryParamMap)) {
                    List<String> queryKeys = new ArrayList<>();
                    if (ALL_FIELDS.equals(plQuery)) {
                        queryKeys.addAll(queryParamMap.keySet());
                    } else if (queryParamMap.containsKey(plQuery)) {
                        queryKeys.add(plQuery);
                    }
                    if (CollectionUtils.isNotEmpty(queryKeys)) {
                        queryKeys.forEach(queryKey -> {
                            for (SpecDTO.FieldDTO searchField : searchFields) {
                                if (searchField.getKey().equals(queryKey)) {
                                    QueryDTO.ParamDTO paramDTO = queryParamMap.get(queryKey);
                                    Integer match = paramDTO.getMatch();
                                    Map<Integer, String> fieldMatch = searchField.getSearch().getMatch();
                                    if (match != null) {
                                        //校验match是否允许
                                        if (!fieldMatch.keySet().contains(match)) {
                                            throw new IllegalArgumentException(String.format("字段(%s)match匹配条件不在配置范围内", queryKey));
                                        }
                                    } else {
                                        Set<Integer> matchSet = fieldMatch.keySet();
                                        match = fieldMatch.keySet().toArray(new Integer[0])[0];

                                    }
                                    pipelineQueryParams.put(queryKey, paramDTO.getValue() + PIPELINE_PARAM_VALUE_SPLITTER + match + PIPELINE_PARAM_VALUE_SPLITTER + searchField.getSearch().getDataType());
                                    break;
                                }
                            }
                        });
                    }
                }
            }
        }

        Map<String, Integer> pipelineOrders = new LinkedHashMap<>();
        Map<String, Integer> queryOrderMap = queryDTO.getOrder();
        Set<String> plOrders = completeQlParam.getOrders();
        if (MapUtils.isNotEmpty(queryOrderMap) && CollectionUtils.isNotEmpty(plOrders)) {
            List<SpecDTO.FieldDTO> sortFields = specDTO.getFields().stream().filter(fieldDTO -> {
                return fieldDTO.getResult() != null &&
                    fieldDTO.getResult().getOrder() == ORDER.YES.val();
            }).sorted((field1, field2) -> {
                int index1 = field1.getResult().getIndex();
                int index2 = field2.getResult().getIndex();
                return index1 < index2 ? -1 : (index1 == index2 ? 0 : 1);
            }).collect(Collectors.toList());

            sortFields.forEach(fieldDTO -> {
                String sortKey = fieldDTO.getKey();
                if ((plOrders.contains(ALL_FIELDS) || plOrders.contains(sortKey)) && queryOrderMap.keySet().contains(sortKey)) {
                    pipelineOrders.put(sortKey, queryOrderMap.get(sortKey));
                }
            });
        }
        if (needCompleteQl) {
            // (2.2)wrap where and order
            this.wrapWhereAndOrder(tempDTO, ql, pipelineQueryParams, pipelineOrders);
            // (2.3) 配置分页信息
            if (completeQlParam.getPaging() == PAGING.YES.val()) {
                tempDTO.setCountQl("select count(1) from ( " + tempDTO.getQl() + " ) tmp_count");
                tempDTO.setCountPss(new ArrayList<>(tempDTO.getPss()));
                // (2.4) 组装分页信息
                if (!(queryDTO.getOper().containsKey(LIST_OPER.EXPORT_YES.key()) && LIST_OPER.EXPORT_YES.val() == queryDTO.getOper().get(LIST_OPER.EXPORT_YES.key()))) {
                    Integer pageIndex = queryDTO.getPagenator().getPageIndex();
                    if (pageIndex == null || pageIndex < 1) {
                        pageIndex = specDTO.getPagenator().getPageIndex();
                    }
                    if (pageIndex == null || pageIndex < 1) {
                        pageIndex = 1;
                    }
                    queryDTO.getPagenator().setPageIndex(pageIndex);
                    Integer pageSize = queryDTO.getPagenator().getPageSize();
                    if (pageSize == null || pageSize < 1) {
                        pageSize = specDTO.getPagenator().getPageSize();
                    }
                    if (pageSize == null || pageSize < 1) {
                        pageSize = 10;
                    }
                    queryDTO.getPagenator().setPageSize(pageSize);
                    this.wrapPagenator(tempDTO, (pageIndex - 1) * pageSize, pageSize);
                }
            }
        }

        TempDTO logDTO = new TempDTO();
        logDTO.setQl(tempDTO.getQl());
        logDTO.setPss(tempDTO.getPss());
        logDTO.setCountQl(tempDTO.getCountQl());
        logDTO.setCountPss(tempDTO.getCountPss());
        logMap.put(this.getName(), logDTO);

        return tempDTO;
    }

    private String placeHolderReplace(String ql, Map<String, Object> placeHolder) {
        ToolContext tc = this.toolManager.createContext();
        if (MapUtils.isNotEmpty(placeHolder)) {
            tc.putAll(placeHolder);
        }
        StringWriter sw = new StringWriter();
        boolean success = this.ve.evaluate(tc, sw, "", ql);
        if (success) {
            return sw.toString();
        }
        throw new RuntimeException("ql解析失败");
    }

    private void wrapWhereAndOrder(TempDTO tempDTO, String ql, Map<String, String> params,
                                   Map<String, Integer> orders) {
        tempDTO.setQl(ql);
        List<TempDTO.PSDTO> pss = new ArrayList<>();
        tempDTO.setPss(pss);
        StringBuilder whereSB = new StringBuilder();
        StringBuilder orderSB = new StringBuilder();
        // (1) 检索条件
        if (MapUtils.isNotEmpty(params)) {
            for (String paramKey : params.keySet()) {
                String[] paramValueArr = params.get(paramKey).split(PIPELINE_PARAM_VALUE_SPLITTER);
                int match = Integer.valueOf(paramValueArr[1]);
                int dataType = Integer.valueOf(paramValueArr[2]);
                if (match == SEARCH_MATCH.EQUAL.val()) {
                    whereSB.append(paramKey + " = ? and ");
                    pss.add(calculateSqlObj(paramValueArr[0], dataType, match));
                } else if (match == SEARCH_MATCH.LIKE.val()) {
                    whereSB.append(paramKey + " like ? and ");
                    pss.add(calculateSqlObj(paramValueArr[0], dataType, match));
                } else if (match == SEARCH_MATCH.NOTEQUAL.val()) {
                    whereSB.append(paramKey + " != ? and ");
                    pss.add(calculateSqlObj(paramValueArr[0], dataType, match));
                } else if (match == SEARCH_MATCH.RANGE.val()) {
                    String[] valArr = paramValueArr[0].split(PARAM_VALUE_SPLITTER);
                    if (valArr.length == 1) {
                        whereSB.append(paramKey + " >= ? and ");
                        pss.add(calculateSqlObj(valArr[0], dataType, match));
                    } else if (valArr.length == 2) {
                        if (StringUtils.isNotBlank(valArr[0])) {
                            whereSB.append(paramKey + " >= ? and ");
                            pss.add(calculateSqlObj(valArr[0], dataType, match));
                        }
                        if (StringUtils.isNotBlank(valArr[1])) {
                            whereSB.append(paramKey + " <= ? and ");
                            pss.add(calculateSqlObj(valArr[1], dataType, match));
                        }
                    } else {
                        throw new IllegalArgumentException("参数类型是范围时,传入的值格式错误");
                    }
                } else if (match == SEARCH_MATCH.IN.val()) {
                    whereSB.append(paramKey + " in (");
                    String[] valArr = paramValueArr[0].split(PARAM_VALUE_SPLITTER);
                    for (int i = 0; i < valArr.length; i++) {
                        if (i < valArr.length - 1) {
                            whereSB.append(" ?, ");
                        } else {
                            whereSB.append(" ? ) and ");
                        }
                        pss.add(calculateSqlObj(valArr[i], dataType, match));
                    }
                }
            }
            // whereSB去除最后一个and
            if (StringUtils.isNotBlank(whereSB)) {
                whereSB.delete(whereSB.lastIndexOf("and"), whereSB.length());
            }
        }

        // (2) 排序
        if (MapUtils.isNotEmpty(orders)) {
            for (String orderKey : orders.keySet()) {
                int orderValue = orders.get(orderKey);
                if (orderValue == ORDER_TYPE.ASC.key()) {
                    orderSB.append(orderKey + " " + ORDER_TYPE.ASC.val() + ",");
                } else if (orderValue == ORDER_TYPE.DESC.key()) {
                    orderSB.append(orderKey + " " + ORDER_TYPE.DESC.val() + ",");
                }
            }
            // orderSB去除最后一个逗号
            if (StringUtils.isNotBlank(orderSB)) {
                orderSB.delete(orderSB.lastIndexOf(","), orderSB.length());
            }
        }

        // (3)拼装完整的ql
        if (StringUtils.isNotBlank(whereSB) || StringUtils.isNotBlank(orderSB)) {
            StringBuilder qlSB = new StringBuilder(ql.length() + 100);
            qlSB.append(this.wrapQl(ql));
            if (StringUtils.isNotBlank(whereSB)) {
                qlSB.append(" where ").append(whereSB);
            }
            if (StringUtils.isNotBlank(orderSB)) {
                qlSB.append(" order by ").append(orderSB);
            }
            tempDTO.setQl(qlSB.toString());
        }
    }

    private TempDTO.PSDTO calculateSqlObj(String paramValue, int dataType, int match) {
        TempDTO.PSDTO psdto = new TempDTO.PSDTO();
        switch (JDBCType.valueOf(dataType)) {
            case INTEGER:
                psdto.setParam(Integer.valueOf(paramValue));
                break;
            case BIGINT:
                psdto.setParam(Long.valueOf(paramValue));
                break;
            case FLOAT:
                psdto.setParam(Float.valueOf(paramValue));
                break;
            case DOUBLE:
                psdto.setParam(Double.valueOf(paramValue));
                break;
            case DATE:
                //先转换成日期字符格式
                String dateFormat = DateFormatUtils.format(Long.valueOf(paramValue), "yyyy-MM-dd");
                psdto.setParam(Date.valueOf(dateFormat));
                break;
            case TIME:
                //先转换成时间字符格式
                String timeFormat = DateFormatUtils.format(Long.valueOf(paramValue), "HH:mm:ss");
                psdto.setParam(Time.valueOf(timeFormat));
                break;
            case TIMESTAMP:
                //先转换成日期时间字符格式
                String dataTimeFormat = DateFormatUtils.format(Long.valueOf(paramValue), "yyyy-MM-dd HH:mm:ss");
                psdto.setParam(Timestamp.valueOf(dataTimeFormat));
                break;
            default:
                if (match == SEARCH_MATCH.LIKE.val()) {
                    psdto.setParam("%" + paramValue + "%");
                } else {
                    psdto.setParam(paramValue);
                }
        }
        psdto.setParamType(dataType);
        return psdto;
    }
}

@Component("mySqlCompleteQlFunction")
class MySqlCompleteQlFunction extends CompleteQlFunction {

    @Override
    protected String wrapQl(String ql) {
        return String.format("select * from ( %s ) _wrap", ql);
    }

    @Override
    protected void wrapPagenator(TempDTO tempDTO, Integer offset, Integer limit) {
        String ql = tempDTO.getQl();
        List<TempDTO.PSDTO> pss = tempDTO.getPss();
        StringBuilder sb = new StringBuilder(ql.length() + 20);
        sb.append(ql);
        if (offset > 0) {
            sb.append(" limit ?,?");
            pss.add(new TempDTO.PSDTO(offset, Types.INTEGER));
            pss.add(new TempDTO.PSDTO(limit, Types.INTEGER));
        } else {
            sb.append(" limit ?");
            pss.add(new TempDTO.PSDTO(limit, Types.INTEGER));
        }
        tempDTO.setQl(sb.toString());
    }
}

@Component("oracleCompleteQlFunction")
class OracleCompleteQlFunction extends CompleteQlFunction {

    @Override
    protected String wrapQl(String ql) {
        return String.format("select * from ( %s )", ql);
    }

    @Override
    protected void wrapPagenator(TempDTO tempDTO, Integer offset, Integer limit) {
        String ql = tempDTO.getQl();
        List<TempDTO.PSDTO> pss = tempDTO.getPss();
        StringBuilder sb = new StringBuilder(ql.length() + 100);
        if (offset > 0) {
            sb.append("select * from ( select row_.*, rownum rownum_ from ( ");
        } else {
            sb.append("select * from ( ");
        }
        sb.append(ql);
        if (offset > 0) {
            sb.append(" ) row_ ) where rownum_ > ? and rownum_ <= ?");
            pss.add(new TempDTO.PSDTO(offset, Types.INTEGER));
            pss.add(new TempDTO.PSDTO(offset + limit, Types.INTEGER));
        } else {
            sb.append(" ) where rownum <= ?");
            pss.add(new TempDTO.PSDTO(limit, Types.INTEGER));
        }
        tempDTO.setQl(sb.toString());
    }
}
