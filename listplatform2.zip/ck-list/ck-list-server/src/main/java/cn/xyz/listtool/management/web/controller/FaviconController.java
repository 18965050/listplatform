package cn.xyz.listtool.management.web.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <pre>
 * 解决浏览器访问报 No handler found for GET /favicon.ico的问题
 * 注意: 仅配置 spring.mvc.favicon.enabled=false 没有作用,这只是不对 /favicon.ico 配置MappingHandler
 * 请参考: https://www.baeldung.com/spring-boot-favicon
 * </pre>
 *
 * @author lvchenggang.
 * @date 2019/12/13 15:55
 * @see
 * @since
 */
@RestController
public class FaviconController {

    @GetMapping("/favicon.ico")
    void returnNoFavicon() {
    }
}
