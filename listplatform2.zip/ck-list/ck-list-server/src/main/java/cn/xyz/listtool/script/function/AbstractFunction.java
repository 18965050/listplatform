package cn.xyz.listtool.script.function;

import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.dto.SpecDTO;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 抽象函数.
 *
 * @author lvchenggang.
 * @date 2020/3/12 17:24
 * @see
 * @since
 */
public abstract class AbstractFunction<P, R> {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 执行函数. 作为被其他funtion调用使用
     *
     * @param context
     * @param pipeLineDTO
     * @param param
     * @param logMap
     * @return
     */
    public abstract R innerExec(Map<String, Object> context, SpecDTO.PipeLineDTO pipeLineDTO, P param, Map<String, Object> logMap);

    /**
     * 执行函数. 作为pipeline中直接调用使用
     *
     * @param context
     * @param pipeLineDTO
     * @param param
     * @return
     */
    public R exec(Map<String, Object> context, SpecDTO.PipeLineDTO pipeLineDTO, P param) {
        Map<String, Map<String, Object>> logMap = (Map<String, Map<String, Object>>) context.get(Const.CONTEXT.LOG.val());
        Map<String, Object> pipelineLogMap = logMap.get(pipeLineDTO.getName());
        if (pipelineLogMap == null) {
            pipelineLogMap = new LinkedHashMap<>();
            logMap.put(pipeLineDTO.getName(), pipelineLogMap);
        }
        return this.innerExec(context, pipeLineDTO, param, pipelineLogMap);
    }

    protected String getName() {
        //防止同一个pipeline中脚本函数被多次调用
        return this.getClass().getSimpleName() + "-" + RandomStringUtils.randomAlphanumeric(6);
    }

}
