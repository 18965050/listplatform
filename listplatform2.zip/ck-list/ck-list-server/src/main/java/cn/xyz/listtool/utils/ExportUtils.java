package cn.xyz.listtool.utils;

import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.dto.ResultDTO;
import cn.xyz.listtool.dto.SpecDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static cn.xyz.listtool.constant.Const.PRE_LOCK_KEY;

/**
 * 数据导出
 *
 * @author lvchenggang.
 * @date 2019/12/20 11:38
 * @see
 * @since
 */
public class ExportUtils {

    public static String lockKey(Long listId) {
        return PRE_LOCK_KEY + listId;
    }

    public static List<SpecDTO.FieldDTO> getExportFields(ResultDTO resultDTO) {
        List<SpecDTO.FieldDTO> fieldDTOS = resultDTO.getSpec().getFields();
        return fieldDTOS.stream().filter(fieldDTO -> {
            SpecDTO.FieldDTO.Result result = fieldDTO.getResult();
            return result != null && (result.getExport() == null || result.getExport() == Const.EXPORT.YES.val());
        }).collect(Collectors.toList());
    }

    public static SXSSFSheet exportExcelHeader(SXSSFWorkbook workbook, ResultDTO resultDTO) {
        String title = resultDTO.getTitle();
        List<SpecDTO.FieldDTO> fieldDTOS = getExportFields(resultDTO);
        SXSSFSheet wbSheet = workbook.createSheet(title);
        //设置默认行宽
        wbSheet.setDefaultColumnWidth(20);

        //在第0行创建标题
        CellStyle titleCellStyle = workbook.createCellStyle();
        titleCellStyle.setAlignment(HorizontalAlignment.CENTER);//水平居中
        titleCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//垂直居中
        Font titleFont = workbook.createFont();
        titleFont.setBold(true);   //加粗
        titleFont.setFontHeightInPoints((short) 20);  //设置标题字体大小
        titleFont.setColor(Font.COLOR_RED);
        titleCellStyle.setFont(titleFont);

        SXSSFRow titleRow = wbSheet.createRow(0);
        titleRow.setHeightInPoints(30);//行高
        SXSSFCell titleCell = titleRow.createCell(0);
        titleCell.setCellValue(title);
        titleCell.setCellStyle(titleCellStyle);
        if (CollectionUtils.isNotEmpty(fieldDTOS)) {
            wbSheet.addMergedRegion(new CellRangeAddress(0, 0, 0, fieldDTOS.size()-1));
        }

        //在第1行创建表头
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);//水平居中
        headerCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//垂直居中
        Font headerFont = workbook.createFont();
        headerFont.setFontHeightInPoints((short) 16);
        headerFont.setBold(true);
        headerCellStyle.setFont(headerFont);
        SXSSFRow headerRow = wbSheet.createRow((int) 1);
        for (int i = 0; i < fieldDTOS.size(); i++) {
            SXSSFCell cellHead = headerRow.createCell(i);
            cellHead.setCellValue(fieldDTOS.get(i).getLabel());
            cellHead.setCellStyle(headerCellStyle);
        }
        return wbSheet;
    }

    public static void exportExcelData(SXSSFSheet wbSheet, int dataIndex, ResultDTO resultDTO, CellStyle dataCellStyle) {
        List<SpecDTO.FieldDTO> fieldDTOS = getExportFields(resultDTO);
        List<Map<String, ResultDTO.FieldValueDTO>> dataList = resultDTO.getList();
        if (CollectionUtils.isNotEmpty(dataList)) {
            for (int i = 0; i < dataList.size(); i++) {
                Map<String, ResultDTO.FieldValueDTO> dataMap = dataList.get(i);
                SXSSFRow dataRow = wbSheet.createRow(dataIndex + i);
                for (int j = 0; j < fieldDTOS.size(); j++) {
                    SXSSFCell cellData = dataRow.createCell(j);
                    String key = fieldDTOS.get(j).getKey();
                    ResultDTO.FieldValueDTO cellValue = dataMap.get(key);
                    //使用labelValue
                    if (cellValue != null && StringUtils.isNotBlank(cellValue.getLabelValue())) {
                        cellData.setCellValue(cellValue.getLabelValue());
                    } else {
                        cellData.setCellValue("");
                    }
                    cellData.setCellStyle(dataCellStyle);
                }
            }
        }
    }
}
