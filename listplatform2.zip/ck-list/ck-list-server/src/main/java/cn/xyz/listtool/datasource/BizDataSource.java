package cn.xyz.listtool.datasource;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * 业务数据源
 *
 * @author lvchenggang.
 * @date 2019/11/15 10:32
 * @see
 * @since
 */
public class BizDataSource {
    //给metrics使用
    private String dsName;

    private Integer dsType;

    private JdbcTemplate jdbcTemplate;

    public BizDataSource(String dsName, int dsType, JdbcTemplate jdbcTemplate) {
        this.dsName = dsName;
        this.dsType = dsType;
        this.jdbcTemplate = jdbcTemplate;
    }

    public String getDsName() {
        return dsName;
    }

    public void setDsName(String dsName) {
        this.dsName = dsName;
    }

    public Integer getDsType() {
        return dsType;
    }

    public void setDsType(Integer dsType) {
        this.dsType = dsType;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}
