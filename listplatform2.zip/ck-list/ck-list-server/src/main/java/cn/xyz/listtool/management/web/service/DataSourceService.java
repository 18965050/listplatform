package cn.xyz.listtool.management.web.service;

import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.JsonMapper;
import cn.xyz.listtool.aop.SupplyAudit;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.management.web.dto.DataSourceDTO;
import cn.xyz.listtool.repository.DataSourceRepository;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR;
import static cn.xyz.listtool.aop.SupplyAudit.OpType.ADD;
import static cn.xyz.listtool.aop.SupplyAudit.OpType.UPDATE;

/**
 * @author lvchenggang.
 * @date 2019/11/26 16:24
 * @see
 * @since
 */
@Service
public class DataSourceService {

    @Autowired
    private DataSourceRepository dsRepo;

    @Autowired
    private JsonMapper jsonMapper;

    public DataSourceDTO detail(Long dsId) {
        return this.dsRepo.selectByPrimaryKey(dsId);
    }

    @SupplyAudit(ADD)
    public DataSourceDTO add(DataSourceDTO dsDTO) {
        int i = this.dsRepo.add(dsDTO);
        if (i != 1) {
            throw new RuntimeException(String.format("添加数据源(dsName:%s)失败.", dsDTO.getDsName()));
        }
        return dsDTO;
    }

    @SupplyAudit(UPDATE)
    public DataSourceDTO update(DataSourceDTO dsDTO) {
        int i = this.dsRepo.update(dsDTO);
        if (i != 1) {
            throw new RuntimeException(String.format("修改数据源(dsId:%d,dsName:%s)失败.", dsDTO.getDsId(), dsDTO.getDsName()));
        }
        return dsDTO;
    }

    public String exportRows(List<Long> dsIds) {
        List<DataSourceDTO> dsDTOS = this.dsRepo.selectByDsIds(dsIds);
        StringBuilder sb = new StringBuilder("{\"" + Const.IMPORT_DATATYPE.DS.val() + "\":");
        sb.append(jsonMapper.toJson(dsDTOS));
        sb.append("}");
        return sb.toString();
    }

    public BaseResponseDTO<Void> importData(String json) {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        try {
            Map<String, List> map = jsonMapper.fromJson(json, Map.class);
            if (map.containsKey(Const.IMPORT_DATATYPE.DS.val())) {
                List<DataSourceDTO> dsDTOs = new ArrayList<>();
                map.get(Const.IMPORT_DATATYPE.DS.val()).forEach(dsMap -> {
                    dsDTOs.add(jsonMapper.fromJson(jsonMapper.toJson(dsMap), DataSourceDTO.class));
                });
                this.dsRepo.importData(dsDTOs);
            }
        } catch (Exception e) {
            baseResponseDTO.setRet(BIZ_ERROR.value());
            baseResponseDTO.addError(String.format("导入文件数据格式不正确或导入数据错误(errMsg:%s)", e.getMessage()));
        }
        return baseResponseDTO;
    }

}
