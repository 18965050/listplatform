package cn.xyz.listtool.repository.g.entity;

import java.util.Date;
import javax.annotation.Generated;

public class ListtoolListInfo {
    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.068+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_ID")
    private Long listId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.072+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.APP_ID")
    private Long appId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.072+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_NAME")
    private String listName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.073+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_DESC")
    private String listDesc;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.075+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.AUTH_TYPE")
    private Integer authType;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.075+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.AUTH_EXPR")
    private String authExpr;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.STATUS")
    private Integer status;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_ID")
    private Long createId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_ID")
    private Long modifyId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_NAME")
    private String createName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_NAME")
    private String modifyName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_TIME")
    private Date createTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_TIME")
    private Date modifyTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CONTEXT")
    private String context;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.DEBUG_PARAM")
    private String debugParam;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.071+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_ID")
    public Long getListId() {
        return listId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.072+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_ID")
    public void setListId(Long listId) {
        this.listId = listId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.072+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.APP_ID")
    public Long getAppId() {
        return appId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.072+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.APP_ID")
    public void setAppId(Long appId) {
        this.appId = appId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.072+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_NAME")
    public String getListName() {
        return listName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.072+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_NAME")
    public void setListName(String listName) {
        this.listName = listName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.073+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_DESC")
    public String getListDesc() {
        return listDesc;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.073+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.LIST_DESC")
    public void setListDesc(String listDesc) {
        this.listDesc = listDesc;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.075+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.AUTH_TYPE")
    public Integer getAuthType() {
        return authType;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.075+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.AUTH_TYPE")
    public void setAuthType(Integer authType) {
        this.authType = authType;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.075+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.AUTH_EXPR")
    public String getAuthExpr() {
        return authExpr;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.AUTH_EXPR")
    public void setAuthExpr(String authExpr) {
        this.authExpr = authExpr;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.STATUS")
    public Integer getStatus() {
        return status;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.STATUS")
    public void setStatus(Integer status) {
        this.status = status;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_ID")
    public Long getCreateId() {
        return createId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_ID")
    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_ID")
    public Long getModifyId() {
        return modifyId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_ID")
    public void setModifyId(Long modifyId) {
        this.modifyId = modifyId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_NAME")
    public String getCreateName() {
        return createName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.076+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_NAME")
    public void setCreateName(String createName) {
        this.createName = createName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_NAME")
    public String getModifyName() {
        return modifyName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_NAME")
    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_TIME")
    public Date getCreateTime() {
        return createTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CREATE_TIME")
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_TIME")
    public Date getModifyTime() {
        return modifyTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.MODIFY_TIME")
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CONTEXT")
    public String getContext() {
        return context;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.077+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.CONTEXT")
    public void setContext(String context) {
        this.context = context;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.078+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.DEBUG_PARAM")
    public String getDebugParam() {
        return debugParam;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.078+08:00", comments="Source field: listtool..LISTTOOL_LIST_INFO.DEBUG_PARAM")
    public void setDebugParam(String debugParam) {
        this.debugParam = debugParam;
    }
}