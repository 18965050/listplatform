package cn.xyz.listtool.management.web.controller;

import cn.xyz.chaos.mvc.web.api.BaseController;
import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.constant.Const;
import cn.xyz.listtool.datasource.DataSourceManager;
import cn.xyz.listtool.management.web.dto.DataSourceDTO;
import cn.xyz.listtool.management.web.service.DataSourceService;
import cn.xyz.listtool.utils.DownloadUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR;
import static cn.xyz.listtool.constant.Const.IMPORT_DATATYPE.DS;

/**
 * @author lvchenggang.
 * @date 2019/11/26 16:24
 * @see
 * @since
 */
@RestController
@RequestMapping("/management/datasource")
@RequiresPermissions({"list:datasource"})
public class DataSourceController extends BaseController {

    @Autowired
    private DataSourceService dsService;

    @Autowired
    private DataSourceManager dataSourceManager;

    @RequestMapping(path = "/detail", method = RequestMethod.GET)
    public BaseResponseDTO<DataSourceDTO> detail(@RequestParam("dsId") Long dsId) {
        return this.returnWithSuccess(this.dsService.detail(dsId));
    }

    @RequestMapping(path = "/add", method = RequestMethod.POST)
    public BaseResponseDTO<DataSourceDTO> add(@Validated(DataSourceDTO.GroupAdd.class) @RequestBody DataSourceDTO dsDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return this.returnWithCheckFail(bindingResult.getAllErrors());
        }
        dsDTO = dsService.add(dsDTO);
        if (Const.STATUS.VALID.val() == dsDTO.getStatus()) {
            this.dataSourceManager.save(dsDTO.getDsName(), dsDTO.getDsType());
        }
        return this.returnWithSuccess(dsDTO);
    }

    @RequestMapping(path = "/update", method = RequestMethod.POST)
    public BaseResponseDTO<DataSourceDTO> update(@Validated(DataSourceDTO.GroupModify.class) @RequestBody DataSourceDTO dsDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return this.returnWithCheckFail(bindingResult.getAllErrors());
        }
        dsDTO = dsService.update(dsDTO);
        if (Const.STATUS.INVALID.val() == dsDTO.getStatus()) {
            this.dataSourceManager.remove(dsDTO.getDsName());
        } else {
            this.dataSourceManager.save(dsDTO.getDsName(), dsDTO.getDsType());
        }
        this.dataSourceManager.save(dsDTO.getDsName(), dsDTO.getDsType());
        return this.returnWithSuccess(dsDTO);
    }

    @RequestMapping(path = "/changeStatus", method = RequestMethod.POST)
    public BaseResponseDTO<DataSourceDTO> changeStatus(@Validated(DataSourceDTO.GroupChangeStatus.class) @RequestBody DataSourceDTO dsDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return this.returnWithCheckFail(bindingResult.getAllErrors());
        }
        DataSourceDTO dsDTO1 = new DataSourceDTO();
        dsDTO1.setDsId(dsDTO.getDsId());
        dsDTO1.setStatus(dsDTO.getStatus());
        dsService.update(dsDTO1);
        dsDTO1 = this.dsService.detail(dsDTO.getDsId());
        if (Const.STATUS.INVALID.val() == dsDTO1.getStatus()) {
            this.dataSourceManager.remove(dsDTO1.getDsName());
        } else {
            this.dataSourceManager.save(dsDTO1.getDsName(), dsDTO1.getDsType());
        }
        return this.returnWithSuccess(dsDTO1);
    }

    @RequestMapping(path = "/exportRows", method = RequestMethod.GET)
    public void exportRows(HttpServletRequest request, HttpServletResponse response, @RequestParam("dsIds") List<Long> dsIds) throws UnsupportedEncodingException {
        String json = this.dsService.exportRows(dsIds);
        DownloadUtils.down(DS.fileName(), json.getBytes("UTF-8"), request, response);
    }

    @RequestMapping(path = "/importData", method = RequestMethod.POST)
    public BaseResponseDTO<Void> importData(@RequestParam("file") MultipartFile multipartFile) throws IOException {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        if (multipartFile == null || !(multipartFile.getBytes().length > 0)) {
            return returnWithFail(BIZ_ERROR.value(), Arrays.asList(new String[]{"导入文件为空"}));
        }
        String json = new String(multipartFile.getBytes(), "UTF-8");
        return this.dsService.importData(json);
    }

    @RequiresPermissions({"list:list"})
    @RequestMapping(path = "/getDatasources", method = RequestMethod.GET)
    public BaseResponseDTO<Set<String>> getDatasources() {
        return this.returnWithSuccess(this.dataSourceManager.getDsNames());
    }

}
