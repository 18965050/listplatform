/**
 * 服务化调用的一些公共方法
 *
 * @author lvchenggang.
 * @date 2020/5/20 13:58
 * @see
 * @since
 */
package cn.xyz.listtool.service;
