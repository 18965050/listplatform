package cn.xyz.listtool.repository;

import cn.xyz.listtool.management.web.dto.DataSourceDTO;
import cn.xyz.listtool.orika.MappingUtils;
import cn.xyz.listtool.repository.dao.ListtoolDatasourceInfoDAO;
import cn.xyz.listtool.repository.g.entity.ListtoolDatasourceInfo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static cn.xyz.listtool.repository.g.mapper.ListtoolDatasourceInfoDynamicSqlSupport.listtoolDatasourceInfo;
import static org.mybatis.dynamic.sql.SqlBuilder.isEqualTo;
import static org.mybatis.dynamic.sql.SqlBuilder.isIn;

/**
 * @author lvchenggang.
 * @date 2019/11/26 16:30
 * @see
 * @since
 */
@Repository
public class DataSourceRepository {

    @Autowired
    private ListtoolDatasourceInfoDAO dsDao;

    public DataSourceDTO selectByPrimaryKey(Long dsId) {
        ListtoolDatasourceInfo dsInfo = this.dsDao.selectByPrimaryKey(dsId);
        return MappingUtils.beanConvert(dsInfo, DataSourceDTO.class);
    }

    public int add(DataSourceDTO dsDTO) {
        ListtoolDatasourceInfo dsInfo = MappingUtils.beanConvert(dsDTO, ListtoolDatasourceInfo.class);
        return this.dsDao.insertSelective(dsInfo);
    }

    public int update(DataSourceDTO dsDTO) {
        ListtoolDatasourceInfo dsInfo = MappingUtils.beanConvert(dsDTO, ListtoolDatasourceInfo.class);
        return this.dsDao.updateByPrimaryKeySelective(dsInfo);
    }

    public List<DataSourceDTO> selectAllByStatus(Integer status) {
        List<ListtoolDatasourceInfo> dsList = this.dsDao.selectByExample().where(listtoolDatasourceInfo.status, isEqualTo(status)).orderBy(listtoolDatasourceInfo.dsId).build().execute();
        return MappingUtils.beanListConvert(dsList, DataSourceDTO.class);
    }

    public List<DataSourceDTO> selectByDsIds(List<Long> dsIds) {
        List<ListtoolDatasourceInfo> dsInfos = this.dsDao.selectByExample().where(listtoolDatasourceInfo.dsId, isIn(dsIds)).build().execute();
        return MappingUtils.beanListConvert(dsInfos, DataSourceDTO.class);
    }

    @Transactional
    public void importData(List<DataSourceDTO> dsDTOS) {
        if (CollectionUtils.isNotEmpty(dsDTOS)) {
            List<Long> dsIds = new ArrayList<>();
            List<ListtoolDatasourceInfo> dsInfos = MappingUtils.beanListConvert(dsDTOS, ListtoolDatasourceInfo.class);
            dsDTOS.forEach(dsDTO -> {
                dsIds.add(dsDTO.getDsId());
            });
            this.dsDao.deleteByDsIds(dsIds);
            this.dsDao.batchInsert(dsInfos);
        }
    }
}
