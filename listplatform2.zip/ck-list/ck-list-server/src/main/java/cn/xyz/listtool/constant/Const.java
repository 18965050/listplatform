package cn.xyz.listtool.constant;

import cn.xyz.listtool.ListConst;
import cn.xyz.listtool.script.function.ExecMappingFunction;
import cn.xyz.listtool.script.function.ExecQlFunction;
import cn.xyz.listtool.script.function.GenerateResFunction;
import cn.xyz.listtool.script.function.MergeTempResFunction;
import com.ctrip.framework.apollo.ConfigService;

import java.sql.JDBCType;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * 常量类
 *
 * @author lvchenggang.
 * @date 2019/11/15 10:33
 * @see
 * @since
 */
public class Const extends ListConst {

    public interface DATASOURCE {
        static int ORACLE = 0;
        static int MYSQL = 1;
    }

    public enum PAGING {
        NO(0, "不分页"), YES(1, "分页");

        private int val;
        private String desc;

        private PAGING(int val, String desc) {
            this.val = val;
            this.desc = desc;
        }

        public int val() {
            return this.val;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum STATUS {
        INVALID(0, "停用"), VALID(1, "启用");

        private int val;
        private String desc;

        private STATUS(int val, String desc) {
            this.val = val;
            this.desc = desc;
        }

        public int val() {
            return this.val;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum AUTH_TYPE {
        NONE(0, "/none/", "none"), MEDUSA(1, "/medusa/", "medusa"), CUSTOM(2, "/custom/", "custom");

        private int val;
        private String path;
        private String desc;

        private AUTH_TYPE(int val, String path, String desc) {
            this.val = val;
            this.path = path;
            this.desc = desc;
        }

        public int val() {
            return this.val;
        }

        public String path() {
            return this.path;
        }

        public String desc() {
            return this.desc;
        }

        public static String pathFromVal(int val) {
            for (AUTH_TYPE authType : AUTH_TYPE.values()) {
                if (authType.val() == val) {
                    return authType.path();
                }
            }
            throw new IllegalArgumentException(String.format("认证类型值(val:%d)不正确", val));
        }
    }

    public enum CONTEXT {
        QUERY("query", "列表请求部分"), SPEC("spec", "列表配置部分"), TEMPS("temps", "中间结果部分"), RESULT("result", "列表结果部分"),
        LOG("log", "日志"), SELF("__CONTEXT", "自身,用于脚本访问"), ID("id", "列表ID"), QL_PLACEHOLDER("qlPlaceHolder", "ql模板变量");

        private String val;
        private String desc;

        private CONTEXT(String val, String desc) {
            this.val = val;
            this.desc = desc;
        }

        public String val() {
            return this.val;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum PIPELINE_TYPE {
        SCRIPT("script", null, "原生脚本执行"),
        EXECMAPPING("execMapping", ExecMappingFunction.class, "字段映射执行"),
        EXECQL("execQl", ExecQlFunction.class, "ql语句执行"),
        MERGETEMPRES("mergeTempRes", MergeTempResFunction.class, "合并执行结果"),
        GENERATERES("generateRes", GenerateResFunction.class, "生成列表数据");

        private String val;
        private Class clz;
        private String desc;

        private PIPELINE_TYPE(String val, Class clz, String desc) {
            this.val = val;
            this.clz = clz;
            this.desc = desc;
        }

        public String val() {
            return this.val;
        }

        public Class clz() {
            return this.clz;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum SEARCH_MATCH {
        EQUAL(0, "精确匹配"), LIKE(1, "模糊匹配"), NOTEQUAL(2, "不等于匹配"), RANGE(3, "范围(连续)匹配"), IN(4, "范围(不连续)匹配");

        private int val;
        private String desc;

        private SEARCH_MATCH(int val, String desc) {
            this.val = val;
            this.desc = desc;
        }

        public int val() {
            return this.val;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum SEARCH_DATATYPE {
        INTEGER(JDBCType.INTEGER),
        BIGINT(JDBCType.BIGINT),
        FLOAT(JDBCType.FLOAT), DOUBLE(JDBCType.DOUBLE), STRING(JDBCType.VARCHAR),
        DATE(JDBCType.DATE), TIME(JDBCType.TIME), TIMESTAMP(JDBCType.TIMESTAMP);

        private int val;
        private String desc;

        private SEARCH_DATATYPE(JDBCType jdbcType) {
            this.val = jdbcType.getVendorTypeNumber();
            this.desc = jdbcType.getName();
        }

        public int val() {
            return this.val;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum ORDER {
        NO(0, "不排序"), YES(1, "排序");

        private int val;
        private String desc;

        private ORDER(int val, String desc) {
            this.val = val;
            this.desc = desc;
        }

        public int val() {
            return this.val;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum EXPORT {
        NO(0, "不导出"), YES(1, "导出");

        private int val;
        private String desc;

        private EXPORT(int val, String desc) {
            this.val = val;
            this.desc = desc;
        }

        public int val() {
            return this.val;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum ORDER_TYPE {
        ASC(0, "asc"), DESC(1, "desc");

        private int key;
        private String val;

        private ORDER_TYPE(int key, String val) {
            this.key = key;
            this.val = val;
        }

        public int key() {
            return this.key;
        }

        public String val() {
            return this.val;
        }
    }

    public enum FIELD_MAPPING {
        JSON("json://", "json字段映射"),
        QL("ql://", "ql字段映射"),
        DUBBO("dubbo://", "dubbo字段映射");

        private String val;
        private String desc;

        private FIELD_MAPPING(String val, String desc) {
            this.val = val;
            this.desc = desc;
        }

        public String val() {
            return this.val;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum FIELD_FORMAT {
        QL("ql://", "ql字段转换"), DUBBO("dubbo://", "ql字段转换");

        private String val;
        private String desc;

        private FIELD_FORMAT(String val, String desc) {
            this.val = val;
            this.desc = desc;
        }

        public String val() {
            return this.val;
        }

        public String desc() {
            return this.desc;
        }
    }

    public enum CACHE {
        LISTTOOL(1, "LISTTOOL:*"), LOCK(2, "EXPORT:LISTTOOL:*");

        private Integer type;
        private String key;

        private CACHE(Integer type, String key) {
            this.type = type;
            this.key = key;
        }

        public Integer type() {
            return type;
        }

        public String key() {
            return key;
        }

        public static String keyFromType(int type) {
            for (CACHE cache : CACHE.values()) {
                if (cache.type == type) {
                    return cache.key();
                }
            }
            throw new IllegalArgumentException(String.format("缓存类型(type:%d)不正确", type));
        }
    }

    public enum METRICS {
        DS(null, new String[]{"dsName"}, "数据源Metric"),
        QL_COUNT("ql.count", new String[]{"dsName", "pipelineName"}, "Ql统计分页信息Metric"),
        QL_EXEC("ql.exec", new String[]{"dsName", "pipelineName"}, "Ql统计分页信息Metric"),
        SEARCH_MAPPING("ql.search.mapping", new String[]{"dsName", "listFieldId"}, "查询字段映射Metric"),
        FIELD_FORMAT("ql.field.format", new String[]{"dsName", "listFieldId"}, "结果字段映射Metric");

        private String metric;
        private Set<String> tags;
        private String desc;

        private METRICS(String metric, String[] tags, String desc) {
            this.metric = metric;
            this.tags = new HashSet<>(Arrays.asList(tags));
            this.desc = desc;
        }

        public String metric() {
            return this.metric;
        }

        public Set<String> tags() {
            return this.tags;
        }

        public String desc() {
            return this.desc;
        }
    }


    public enum IMPORT_DATATYPE {
        DS("ds", "listtool_datasource_info.txt", "数据源数据导入"), APP("app", "listtool_app_info.txt", "业务应用数据导入"), LIST("list", "listtool_list_info.txt", "配置列表数据导入");

        private String val;
        private String fileName;
        private String desc;

        private IMPORT_DATATYPE(String val, String fileName, String desc) {
            this.val = val;
            this.fileName = fileName;
            this.desc = desc;
        }

        public String val() {
            return this.val;
        }

        public String fileName() {
            return this.fileName;
        }

        public String desc() {
            return this.desc;
        }
    }

    public static final String COMMON_SPLITTER = ",";

    public static final String PIPELINE_PARAM_VALUE_SPLITTER = "###";

    public static final String ALL_FIELDS = "_@_";

    public static final String URL_LIST_PREFIX = "/listtool";

    public static final String URL_MEDUSA_LIST_PATH = URL_LIST_PREFIX + "/medusa";

    public static final String URL_CUSTOM_LIST_PATH = URL_LIST_PREFIX + "/custom";

    public static final String URL_NONE_LIST_PATH = URL_LIST_PREFIX + "/none";

    public static final String CACHE_APP_NAME = "APP:";
    public static final String CACHE_LIST_NAME = "LIST:";
    public static final String CACHE_USER_NAME = "USER:";

    public static final Integer DUBBO_CALL_TIMEOUT = ConfigService.getConfig("XYZ.bootDubbo").getIntProperty("spring.dubbo.consumer.timeout", 30000);

    /**************************token*************************************/

    public static final Long VALID_TOKEN_MS = 5 * 60 * 1000L;

    /**************************export*************************************/
    public static final String PRE_LOCK_KEY = CACHE.LOCK.key().substring(0, CACHE.LOCK.key().length() - 1);
    public static final Long ERR_FILE_ID = -1L;
    public static final String FFS_TABLE = ConfigService.getConfig("XYZ.ffs").getProperty("ffs.tableName", "ins");
    public static final String DOWNLOAD_TOKEN = "downloadToken";
    public static final String DOWNLOAD_TOKEN_PWD = "downloadPwd";
}
