package cn.xyz.listtool.bootstrap;

import cn.xyz.chaos.common.metrics.MicrometerConfig;
import com.alibaba.dubbo.qos.common.Constants;
import com.alibaba.dubbo.spring.boot.annotation.EnableDubboConfiguration;
import com.alicp.jetcache.anno.config.EnableCreateCacheAnnotation;
import com.alicp.jetcache.anno.config.EnableMethodCache;
import com.ctrip.framework.apollo.ConfigService;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.web.servlet.WebMvcMetricsAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.gson.GsonAutoConfiguration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Bootstrap Class
 *
 * @author lvchenggang.
 * @date 2019/11/14 16:42
 * @see
 * @since
 */
@SpringBootApplication(exclude = {GsonAutoConfiguration.class, WebMvcMetricsAutoConfiguration.class, PrometheusMetricsExportAutoConfiguration.class}, scanBasePackages = "cn.xyz.listtool")
@MapperScan(basePackages = {"cn.xyz.listtool.repository"},
    annotationClass = cn.xyz.chaos.orm.mybatis.MyBatisRepository.class)
@EnableAspectJAutoProxy
@EnableDubboConfiguration
@EnableTransactionManagement
@EnableMethodCache(basePackages = "cn.xyz.listtool")
@EnableCreateCacheAnnotation
public class CkListApplication {

    public static void main(String[] args) {
        //让nashorn js脚本引擎支持es6语法
        System.setProperty("nashorn.args", "--language=es6");

        //dubbo-spring-booter不能配置qos port, 这个配置项是从dubbo配置文件读取的
        System.setProperty(Constants.QOS_PORT, ConfigService.getConfig("XYZ.bootDubbo").getProperty("dubbo.qos.port", "15170"));
        /**<pre>
         * SpringBoot中自带了Tomcat Metrics(TomcatMetricsAutoConfiguration),因此不需要配置tomcatContext
         * 同时,grafana中也没有配置tomcat的监控
         * </pre>
         */
        MicrometerConfig.config(ConfigService.getConfig("XYZ.auth").getProperty("app.name", "ck-list"));
        SpringApplication.run(CkListApplication.class, args);
    }
}
