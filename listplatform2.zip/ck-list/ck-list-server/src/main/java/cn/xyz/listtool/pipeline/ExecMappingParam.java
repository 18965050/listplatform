package cn.xyz.listtool.pipeline;

import java.util.Set;

/**
 * execMapping函数参数
 *
 * @author lvchenggang.
 * @date 2020/3/12 16:16
 * @see
 * @since
 */
public class ExecMappingParam {

    private String ds;
    /**
     * 允许转换的字段.如果为空,表示所有配置mapping的字段均进行映射转换
     */
    private Set<String> mappingFields;


    public ExecMappingParam(String ds, Set<String> mappingFields) {
        this.ds = ds;
        this.mappingFields = mappingFields;
    }

    public Set<String> getMappingFields() {
        return mappingFields;
    }

    public void setMappingFields(Set<String> mappingFields) {
        this.mappingFields = mappingFields;
    }

    public String getDs() {
        return ds;
    }

    public void setDs(String ds) {
        this.ds = ds;
    }
}
