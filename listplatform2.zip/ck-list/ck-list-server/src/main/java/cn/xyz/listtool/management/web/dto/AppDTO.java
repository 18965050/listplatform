package cn.xyz.listtool.management.web.dto;

import cn.xyz.io.admin.auth.api.base.dto.AuditDTO;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author lvchenggang.
 * @date 2019/11/27 15:19
 * @see
 * @since
 */
public class AppDTO extends AuditDTO {

    @NotNull(message = "id不能为空", groups = {GroupAdd.class, GroupModify.class, GroupChangeStatus.class})
    private Long appId;

    @NotBlank(message = "应用名称不能为空", groups = {GroupAdd.class, GroupModify.class})
    private String appName;

    private String appKey;

    private String appSecret;

    @NotNull(message = "状态不能为空", groups = {GroupAdd.class, GroupModify.class, GroupChangeStatus.class})
    private Integer status;


    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public interface GroupAdd {
    }


    public interface GroupModify {
    }

    public interface GroupChangeStatus {
    }
}
