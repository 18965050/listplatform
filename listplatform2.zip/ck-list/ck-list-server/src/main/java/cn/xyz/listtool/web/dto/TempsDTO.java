package cn.xyz.listtool.web.dto;

import cn.xyz.listtool.dto.PageDTO;
import cn.xyz.listtool.dto.ResultDTO;
import cn.xyz.listtool.dto.SpecDTO;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author lvchenggang.
 * @date 2020/3/2 11:29
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class TempsDTO implements Serializable {

    //当前执行的pipeline
    private SpecDTO.PipeLineDTO currentPipelineDTO;

    private Map<String, TempDTO> tempDTOMap = new HashMap<>();

    public SpecDTO.PipeLineDTO getCurrentPipelineDTO() {
        return currentPipelineDTO;
    }

    public void setCurrentPipelineDTO(SpecDTO.PipeLineDTO currentPipelineDTO) {
        this.currentPipelineDTO = currentPipelineDTO;
    }

    public Map<String, TempDTO> getTempDTOMap() {
        return tempDTOMap;
    }

    public void setTempDTOMap(Map<String, TempDTO> tempDTOMap) {
        this.tempDTOMap = tempDTOMap;
    }

    public static class TempDTO {

        /**
         * <pre>
         * 对DB查询来说,指的是PreparedStatment
         * </pre>
         */
        private String ql;

        /**
         * <pre>
         * 统计分页信息的QL.
         * </pre>
         */
        private String countQl;

        // 列表查询参数
        private List<PSDTO> pss;

        // 分页查询参数
        private List<PSDTO> countPss;

        /**
         * 分页统计信息
         */
        private PageDTO pagenator;

        private List<Map<String, ResultDTO.FieldValueDTO>> list;

        public String getQl() {
            return ql;
        }

        public void setQl(String ql) {
            this.ql = ql;
        }

        public String getCountQl() {
            return countQl;
        }

        public void setCountQl(String countQl) {
            this.countQl = countQl;
        }

        public List<PSDTO> getPss() {
            return pss;
        }

        public void setPss(List<PSDTO> pss) {
            this.pss = pss;
        }

        public List<PSDTO> getCountPss() {
            return countPss;
        }

        public void setCountPss(List<PSDTO> countPss) {
            this.countPss = countPss;
        }

        public PageDTO getPagenator() {
            return pagenator;
        }

        public void setPagenator(PageDTO pagenator) {
            this.pagenator = pagenator;
        }

        public List<Map<String, ResultDTO.FieldValueDTO>> getList() {
            return list;
        }

        public void setList(List<Map<String, ResultDTO.FieldValueDTO>> list) {
            this.list = list;
        }

        public static class PSDTO {
            // 参数值
            private Object param;

            // 参数类型. 参见java.sql.Type
            private Integer paramType;

            public PSDTO() {

            }

            public PSDTO(Object param, Integer paramType) {
                this.param = param;
                this.paramType = paramType;
            }

            public Object getParam() {
                return param;
            }

            public void setParam(Object param) {
                this.param = param;
            }

            public Integer getParamType() {
                return paramType;
            }

            public void setParamType(Integer paramType) {
                this.paramType = paramType;
            }
        }
    }
}
