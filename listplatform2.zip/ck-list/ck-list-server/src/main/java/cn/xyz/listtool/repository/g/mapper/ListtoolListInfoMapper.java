package cn.xyz.listtool.repository.g.mapper;

import static cn.xyz.listtool.repository.g.mapper.ListtoolListInfoDynamicSqlSupport.*;
import static org.mybatis.dynamic.sql.SqlBuilder.*;

import cn.xyz.chaos.orm.mybatis.MyBatisRepository;
import cn.xyz.listtool.repository.g.entity.ListtoolListInfo;
import java.util.List;
import java.util.function.Function;
import javax.annotation.Generated;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.dynamic.sql.SqlBuilder;
import org.mybatis.dynamic.sql.delete.DeleteDSL;
import org.mybatis.dynamic.sql.delete.MyBatis3DeleteModelAdapter;
import org.mybatis.dynamic.sql.delete.render.DeleteStatementProvider;
import org.mybatis.dynamic.sql.insert.render.InsertStatementProvider;
import org.mybatis.dynamic.sql.render.RenderingStrategy;
import org.mybatis.dynamic.sql.select.MyBatis3SelectModelAdapter;
import org.mybatis.dynamic.sql.select.QueryExpressionDSL;
import org.mybatis.dynamic.sql.select.SelectDSL;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.update.MyBatis3UpdateModelAdapter;
import org.mybatis.dynamic.sql.update.UpdateDSL;
import org.mybatis.dynamic.sql.update.render.UpdateStatementProvider;
import org.mybatis.dynamic.sql.util.SqlProviderAdapter;

@Mapper
@MyBatisRepository
public interface ListtoolListInfoMapper {
    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.086+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    long count(SelectStatementProvider selectStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.087+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    @DeleteProvider(type=SqlProviderAdapter.class, method="delete")
    int delete(DeleteStatementProvider deleteStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.088+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    @InsertProvider(type=SqlProviderAdapter.class, method="insert")
    int insert(InsertStatementProvider<ListtoolListInfo> insertStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.089+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @ResultMap("ListtoolListInfoResult")
    ListtoolListInfo selectOne(SelectStatementProvider selectStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.089+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @ResultMap("ListtoolListInfoResult")
    List<ListtoolListInfo> selectManyWithRowbounds(SelectStatementProvider selectStatement, RowBounds rowBounds);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.091+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default Function<SelectStatementProvider, List<ListtoolListInfo>> selectManyWithRowbounds(RowBounds rowBounds) {
        return selectStatement -> selectManyWithRowbounds(selectStatement, rowBounds);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.089+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    @SelectProvider(type=SqlProviderAdapter.class, method="select")
    @Results(id="ListtoolListInfoResult", value = {
        @Result(column="LIST_ID", property="listId", jdbcType=JdbcType.BIGINT, id=true),
        @Result(column="APP_ID", property="appId", jdbcType=JdbcType.BIGINT),
        @Result(column="LIST_NAME", property="listName", jdbcType=JdbcType.VARCHAR),
        @Result(column="LIST_DESC", property="listDesc", jdbcType=JdbcType.VARCHAR),
        @Result(column="AUTH_TYPE", property="authType", jdbcType=JdbcType.TINYINT),
        @Result(column="AUTH_EXPR", property="authExpr", jdbcType=JdbcType.VARCHAR),
        @Result(column="STATUS", property="status", jdbcType=JdbcType.TINYINT),
        @Result(column="CREATE_ID", property="createId", jdbcType=JdbcType.BIGINT),
        @Result(column="MODIFY_ID", property="modifyId", jdbcType=JdbcType.BIGINT),
        @Result(column="CREATE_NAME", property="createName", jdbcType=JdbcType.VARCHAR),
        @Result(column="MODIFY_NAME", property="modifyName", jdbcType=JdbcType.VARCHAR),
        @Result(column="CREATE_TIME", property="createTime", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="MODIFY_TIME", property="modifyTime", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="CONTEXT", property="context", jdbcType=JdbcType.LONGVARCHAR),
        @Result(column="DEBUG_PARAM", property="debugParam", jdbcType=JdbcType.LONGVARCHAR)
    })
    List<ListtoolListInfo> selectMany(SelectStatementProvider selectStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.092+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    @UpdateProvider(type=SqlProviderAdapter.class, method="update")
    int update(UpdateStatementProvider updateStatement);

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.092+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<Long>> countByExample() {
        return SelectDSL.selectWithMapper(this::count, SqlBuilder.count())
                .from(listtoolListInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.093+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default DeleteDSL<MyBatis3DeleteModelAdapter<Integer>> deleteByExample() {
        return DeleteDSL.deleteFromWithMapper(this::delete, listtoolListInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.094+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default int deleteByPrimaryKey(Long listId_) {
        return DeleteDSL.deleteFromWithMapper(this::delete, listtoolListInfo)
                .where(listId, isEqualTo(listId_))
                .build()
                .execute();
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.095+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default int insert(ListtoolListInfo record) {
        return insert(SqlBuilder.insert(record)
                .into(listtoolListInfo)
                .map(listId).toProperty("listId")
                .map(appId).toProperty("appId")
                .map(listName).toProperty("listName")
                .map(listDesc).toProperty("listDesc")
                .map(authType).toProperty("authType")
                .map(authExpr).toProperty("authExpr")
                .map(status).toProperty("status")
                .map(createId).toProperty("createId")
                .map(modifyId).toProperty("modifyId")
                .map(createName).toProperty("createName")
                .map(modifyName).toProperty("modifyName")
                .map(createTime).toProperty("createTime")
                .map(modifyTime).toProperty("modifyTime")
                .map(context).toProperty("context")
                .map(debugParam).toProperty("debugParam")
                .build()
                .render(RenderingStrategy.MYBATIS3));
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.098+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default int insertSelective(ListtoolListInfo record) {
        return insert(SqlBuilder.insert(record)
                .into(listtoolListInfo)
                .map(listId).toPropertyWhenPresent("listId", record::getListId)
                .map(appId).toPropertyWhenPresent("appId", record::getAppId)
                .map(listName).toPropertyWhenPresent("listName", record::getListName)
                .map(listDesc).toPropertyWhenPresent("listDesc", record::getListDesc)
                .map(authType).toPropertyWhenPresent("authType", record::getAuthType)
                .map(authExpr).toPropertyWhenPresent("authExpr", record::getAuthExpr)
                .map(status).toPropertyWhenPresent("status", record::getStatus)
                .map(createId).toPropertyWhenPresent("createId", record::getCreateId)
                .map(modifyId).toPropertyWhenPresent("modifyId", record::getModifyId)
                .map(createName).toPropertyWhenPresent("createName", record::getCreateName)
                .map(modifyName).toPropertyWhenPresent("modifyName", record::getModifyName)
                .map(createTime).toPropertyWhenPresent("createTime", record::getCreateTime)
                .map(modifyTime).toPropertyWhenPresent("modifyTime", record::getModifyTime)
                .map(context).toPropertyWhenPresent("context", record::getContext)
                .map(debugParam).toPropertyWhenPresent("debugParam", record::getDebugParam)
                .build()
                .render(RenderingStrategy.MYBATIS3));
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.099+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolListInfo>>> selectByExample(RowBounds rowBounds) {
        return SelectDSL.selectWithMapper(selectManyWithRowbounds(rowBounds), listId, appId, listName, listDesc, authType, authExpr, status, createId, modifyId, createName, modifyName, createTime, modifyTime, context, debugParam)
                .from(listtoolListInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.099+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolListInfo>>> selectByExample() {
        return SelectDSL.selectWithMapper(this::selectMany, listId, appId, listName, listDesc, authType, authExpr, status, createId, modifyId, createName, modifyName, createTime, modifyTime, context, debugParam)
                .from(listtoolListInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.1+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolListInfo>>> selectDistinctByExample(RowBounds rowBounds) {
        return SelectDSL.selectDistinctWithMapper(selectManyWithRowbounds(rowBounds), listId, appId, listName, listDesc, authType, authExpr, status, createId, modifyId, createName, modifyName, createTime, modifyTime, context, debugParam)
                .from(listtoolListInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.1+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default QueryExpressionDSL<MyBatis3SelectModelAdapter<List<ListtoolListInfo>>> selectDistinctByExample() {
        return SelectDSL.selectDistinctWithMapper(this::selectMany, listId, appId, listName, listDesc, authType, authExpr, status, createId, modifyId, createName, modifyName, createTime, modifyTime, context, debugParam)
                .from(listtoolListInfo);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.101+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default ListtoolListInfo selectByPrimaryKey(Long listId_) {
        return SelectDSL.selectWithMapper(this::selectOne, listId, appId, listName, listDesc, authType, authExpr, status, createId, modifyId, createName, modifyName, createTime, modifyTime, context, debugParam)
                .from(listtoolListInfo)
                .where(listId, isEqualTo(listId_))
                .build()
                .execute();
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.102+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default UpdateDSL<MyBatis3UpdateModelAdapter<Integer>> updateByExample(ListtoolListInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolListInfo)
                .set(listId).equalTo(record::getListId)
                .set(appId).equalTo(record::getAppId)
                .set(listName).equalTo(record::getListName)
                .set(listDesc).equalTo(record::getListDesc)
                .set(authType).equalTo(record::getAuthType)
                .set(authExpr).equalTo(record::getAuthExpr)
                .set(status).equalTo(record::getStatus)
                .set(createId).equalTo(record::getCreateId)
                .set(modifyId).equalTo(record::getModifyId)
                .set(createName).equalTo(record::getCreateName)
                .set(modifyName).equalTo(record::getModifyName)
                .set(createTime).equalTo(record::getCreateTime)
                .set(modifyTime).equalTo(record::getModifyTime)
                .set(context).equalTo(record::getContext)
                .set(debugParam).equalTo(record::getDebugParam);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.102+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default UpdateDSL<MyBatis3UpdateModelAdapter<Integer>> updateByExampleSelective(ListtoolListInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolListInfo)
                .set(listId).equalToWhenPresent(record::getListId)
                .set(appId).equalToWhenPresent(record::getAppId)
                .set(listName).equalToWhenPresent(record::getListName)
                .set(listDesc).equalToWhenPresent(record::getListDesc)
                .set(authType).equalToWhenPresent(record::getAuthType)
                .set(authExpr).equalToWhenPresent(record::getAuthExpr)
                .set(status).equalToWhenPresent(record::getStatus)
                .set(createId).equalToWhenPresent(record::getCreateId)
                .set(modifyId).equalToWhenPresent(record::getModifyId)
                .set(createName).equalToWhenPresent(record::getCreateName)
                .set(modifyName).equalToWhenPresent(record::getModifyName)
                .set(createTime).equalToWhenPresent(record::getCreateTime)
                .set(modifyTime).equalToWhenPresent(record::getModifyTime)
                .set(context).equalToWhenPresent(record::getContext)
                .set(debugParam).equalToWhenPresent(record::getDebugParam);
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.103+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default int updateByPrimaryKey(ListtoolListInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolListInfo)
                .set(appId).equalTo(record::getAppId)
                .set(listName).equalTo(record::getListName)
                .set(listDesc).equalTo(record::getListDesc)
                .set(authType).equalTo(record::getAuthType)
                .set(authExpr).equalTo(record::getAuthExpr)
                .set(status).equalTo(record::getStatus)
                .set(createId).equalTo(record::getCreateId)
                .set(modifyId).equalTo(record::getModifyId)
                .set(createName).equalTo(record::getCreateName)
                .set(modifyName).equalTo(record::getModifyName)
                .set(createTime).equalTo(record::getCreateTime)
                .set(modifyTime).equalTo(record::getModifyTime)
                .set(context).equalTo(record::getContext)
                .set(debugParam).equalTo(record::getDebugParam)
                .where(listId, isEqualTo(record::getListId))
                .build()
                .execute();
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-20T15:59:11.104+08:00", comments="Source Table: listtool..LISTTOOL_LIST_INFO")
    default int updateByPrimaryKeySelective(ListtoolListInfo record) {
        return UpdateDSL.updateWithMapper(this::update, listtoolListInfo)
                .set(appId).equalToWhenPresent(record::getAppId)
                .set(listName).equalToWhenPresent(record::getListName)
                .set(listDesc).equalToWhenPresent(record::getListDesc)
                .set(authType).equalToWhenPresent(record::getAuthType)
                .set(authExpr).equalToWhenPresent(record::getAuthExpr)
                .set(status).equalToWhenPresent(record::getStatus)
                .set(createId).equalToWhenPresent(record::getCreateId)
                .set(modifyId).equalToWhenPresent(record::getModifyId)
                .set(createName).equalToWhenPresent(record::getCreateName)
                .set(modifyName).equalToWhenPresent(record::getModifyName)
                .set(createTime).equalToWhenPresent(record::getCreateTime)
                .set(modifyTime).equalToWhenPresent(record::getModifyTime)
                .set(context).equalToWhenPresent(record::getContext)
                .set(debugParam).equalToWhenPresent(record::getDebugParam)
                .where(listId, isEqualTo(record::getListId))
                .build()
                .execute();
    }
}