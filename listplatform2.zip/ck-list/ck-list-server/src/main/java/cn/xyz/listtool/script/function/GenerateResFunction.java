package cn.xyz.listtool.script.function;

import cn.xyz.listtool.dto.QueryDTO;
import cn.xyz.listtool.dto.ResultDTO;
import cn.xyz.listtool.dto.SpecDTO;
import cn.xyz.listtool.web.dto.TempsDTO;
import cn.xyz.listtool.web.dto.TempsDTO.TempDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static cn.xyz.listtool.ListConst.LIST_OPER.EXEC_YES;
import static cn.xyz.listtool.ListConst.LIST_OPER.EXPORT_YES;
import static cn.xyz.listtool.constant.Const.CONTEXT;


/**
 * @author lvchenggang.
 * @date 2019/11/21 15:03
 * @see
 * @since
 */
@Component
public class GenerateResFunction extends AbstractFunction<Void, Void> {

    @Override
    public Void innerExec(Map<String, Object> context, SpecDTO.PipeLineDTO pipeLineDTO, Void param, Map<String, Object> logMap) {
        ResultDTO resultDTO = new ResultDTO();
        QueryDTO queryDTO = (QueryDTO) context.get(CONTEXT.QUERY.val());
        // (1)设置QueryDTO
        resultDTO.setQuery(queryDTO);
        // (2) 设置SpecDTO, 去除不必要的数据
        SpecDTO specDTO = (SpecDTO) context.get(CONTEXT.SPEC.val());
        specDTO.setPagenator(null);
        specDTO.setPipelines(null);
        resultDTO.setSpec(specDTO);
        //导出数据情况下需要填写导出数据总数
        Integer exportVal = queryDTO.getOper().get(EXPORT_YES.key());
        Integer execVal = queryDTO.getOper().get(EXEC_YES.key());
        if (exportVal != null && EXPORT_YES.val() == exportVal) {
            TempsDTO tempsDTO = (TempsDTO) context.get(CONTEXT.TEMPS.val());
            Map<String, TempDTO> tempDTOMap = tempsDTO.getTempDTOMap();
            if (MapUtils.isNotEmpty(tempDTOMap)) {
                tempDTOMap.forEach((plName, tempDTO) -> {
                    if (tempDTO.getPagenator() != null) {
                        resultDTO.setPagenator(tempDTO.getPagenator());
                    }
                });
            }
        } else if (execVal != null && EXEC_YES.val() == execVal) {
            // (3)设置返回数据
            TempsDTO tempsDTO = (TempsDTO) context.get(CONTEXT.TEMPS.val());
            Map<String, TempDTO> tempDTOMap = tempsDTO.getTempDTOMap();
            List<List<Map<String, ResultDTO.FieldValueDTO>>> dataList = new ArrayList<>();
            //(3.1) 结果数据合并
            for (String key : tempDTOMap.keySet()) {
                dataList.add(tempDTOMap.get(key).getList());
            }
            if (CollectionUtils.isNotEmpty(dataList)) {
                List<Map<String, ResultDTO.FieldValueDTO>> resList = new ArrayList<>(dataList.get(0));
                if (dataList.size() > 1) {
                    // 先确保每个查询返回的数据集合长度相同
                    int length = dataList.get(0).size();
                    for (int i = 1; i < dataList.size(); i++) {
                        if (dataList.get(i).size() != length) {
                            String errInfo = "多个列表查询结果集返回的记录数不一致";
                            logger.error(errInfo);
                            throw new RuntimeException(errInfo);
                        }
                    }
                    // 合并结果集
                    for (int i = 1; i < dataList.size(); i++) {
                        List<Map<String, ResultDTO.FieldValueDTO>> tempDataList = dataList.get(i);
                        for (int j = 0; j < resList.size(); j++) {
                            Map<String, ResultDTO.FieldValueDTO> rowMap = resList.get(j);
                            rowMap.putAll(tempDataList.get(j));
                        }
                    }
                }
                if (CollectionUtils.isNotEmpty(resList)) {
                    // (3.2) 结果数据整理
                    List<String> resultKeys = specDTO.getFields().stream().filter(fieldDTO -> {
                        return fieldDTO.getResult() != null;
                    }).map(fieldDTO -> {
                        return fieldDTO.getKey();
                    }).collect(Collectors.toList());

                    resList.forEach(fieldValueDTOMap -> {
                        Collection<String> removedKeys = CollectionUtils.subtract(fieldValueDTOMap.keySet(), resultKeys);
                        if (CollectionUtils.isNotEmpty(removedKeys)) {
                            for (String removedKey : removedKeys) {
                                fieldValueDTOMap.remove(removedKey);
                            }
                        }
                        Collection<String> paddingKeys = CollectionUtils.subtract(resultKeys, fieldValueDTOMap.keySet());
                        if (CollectionUtils.isNotEmpty(paddingKeys)) {
                            for (String paddingKey : paddingKeys) {
                                ResultDTO.FieldValueDTO fieldValueDTO = new ResultDTO.FieldValueDTO(null, "");
                                fieldValueDTOMap.put(paddingKey, fieldValueDTO);
                            }
                        }
                    });
                }
                resultDTO.setList(resList);

                // (4)设置Pagenator
                for (String key : tempDTOMap.keySet()) {
                    // 每个TempDTO的分页信息应该相同,随便取哪个即可
                    resultDTO.setPagenator(tempDTOMap.get(key).getPagenator());
                    break;
                }
            }
        }
        context.put(CONTEXT.RESULT.val(), resultDTO);
        logMap.put(this.getName(), resultDTO);
        return null;
    }

}
