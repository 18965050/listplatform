package cn.xyz.listtool.script.function;

import cn.xyz.chaos.common.utils.SpringContextUtils;
import cn.xyz.listtool.api.ScriptProvider;
import cn.xyz.listtool.dto.SpecDTO;
import cn.xyz.listtool.pipeline.ExecMappingParam;
import cn.xyz.listtool.pipeline.ExecQlParam;
import cn.xyz.listtool.pipeline.MergeTempResParam;
import cn.xyz.listtool.web.dto.TempsDTO;
import cn.xyz.listtool.web.dto.TempsDTO.TempDTO;
import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.utils.ReferenceConfigCache;
import com.alibaba.dubbo.rpc.cluster.support.FailoverCluster;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import static cn.xyz.listtool.constant.Const.CONTEXT;
import static cn.xyz.listtool.constant.Const.DUBBO_CALL_TIMEOUT;

/**
 * @author lvchenggang.
 * @date 2019/11/18 13:50
 * @see
 * @since
 */
public class FunctionUtils {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public static SpecDTO.PipeLineDTO getCurrentPipeline(Map<String, Object> context) {
        TempsDTO tempsDTO = (TempsDTO) context.get(CONTEXT.TEMPS.val());
        SpecDTO.PipeLineDTO pipelineDTO = tempsDTO.getCurrentPipelineDTO();
        if (pipelineDTO == null || StringUtils.isBlank(pipelineDTO.getName())) {
            throw new RuntimeException("当前pipeline不存在或pipelineName为空");
        } else {
            return pipelineDTO;
        }
    }

    /**
     * 执行field mapping
     *
     * @param context
     */
    public static void execMapping(Map<String, Object> context, ExecMappingParam execMappingParam) {
        SpecDTO.PipeLineDTO pipelineDTO = getCurrentPipeline(context);
        ExecMappingFunction execMappingFunction = SpringContextUtils.getBean(ExecMappingFunction.class);
        execMappingFunction.exec(context, pipelineDTO, execMappingParam);
    }

    /**
     * 执行ql语句
     *
     * @param context
     */
    public static TempDTO execQl(Map<String, Object> context, ExecQlParam execQlParam) {
        SpecDTO.PipeLineDTO pipelineDTO = getCurrentPipeline(context);
        ExecQlFunction execQlFunction = SpringContextUtils.getBean(ExecQlFunction.class);
        return execQlFunction.exec(context, pipelineDTO, execQlParam);
    }

    /**
     * 合并pipeline执行结果到另一个pipeline中
     *
     * @param context
     * @param jsonMergeParam
     */
    public static void mergeTempRes(Map<String, Object> context, MergeTempResParam mergeResultParam) {
        SpecDTO.PipeLineDTO pipelineDTO = getCurrentPipeline(context);
        MergeTempResFunction mergeTempResFunction = SpringContextUtils.getBean(MergeTempResFunction.class);
        mergeTempResFunction.exec(context, pipelineDTO, mergeResultParam);
    }


    public static void generateRes(Map<String, Object> context) {
        SpecDTO.PipeLineDTO pipelineDTO = getCurrentPipeline(context);
        GenerateResFunction generateResFunction = SpringContextUtils.getBean(GenerateResFunction.class);
        generateResFunction.exec(context, pipelineDTO, null);
    }

    public static Object dubboCall(String groupName, String serviceName, Map<String, Object> context) {
        ApplicationConfig applicationConfig = SpringContextUtils.getBean(ApplicationConfig.class);
        RegistryConfig registryConfig = SpringContextUtils.getBean(RegistryConfig.class);
        ReferenceConfig<ScriptProvider> reference = new ReferenceConfig<ScriptProvider>();
        reference.setApplication(applicationConfig);
        reference.setRegistry(registryConfig); // 多个注册中心可以用setRegistries()
        reference.setInterface(ScriptProvider.class);
        reference.setTimeout(DUBBO_CALL_TIMEOUT);
        reference.setCluster(FailoverCluster.NAME);

        // 设置分组
        reference.setGroup(groupName);
        reference.setCheck(false);
        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        ScriptProvider service = cache.get(reference);
        return service.call(serviceName, context);
    }

}
