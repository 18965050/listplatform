package cn.xyz.listtool.pipeline;

import cn.xyz.listtool.constant.Const;

import java.util.Set;

/**
 * completeQl函数参数
 *
 * @author lvchenggang.
 * @date 2020/3/12 14:30
 * @see
 * @since
 */
public class CompleteQlParam {
    /**
     * 原始ql语句
     */
    private String ql;

    /**
     * Datasource名称
     */
    private String ds;

    /**
     * 允许的检索条件
     */
    private Set<String> queries;

    /**
     * 允许的搜索条件
     */
    private Set<String> orders;

    /**
     * 是否分页
     */
    private Integer paging;

    public CompleteQlParam() {
        this(null, null, null, null, Const.PAGING.YES.val());
    }

    public CompleteQlParam(String ql, String ds, Set<String> queries, Set<String> orders, Integer paging) {
        this.ql = ql;
        this.ds = ds;
        this.queries = queries;
        this.orders = orders;
        this.paging = paging;
    }

    public String getQl() {
        return ql;
    }

    public void setQl(String ql) {
        this.ql = ql;
    }

    public String getDs() {
        return ds;
    }

    public void setDs(String ds) {
        this.ds = ds;
    }

    public Set<String> getQueries() {
        return queries;
    }

    public void setQueries(Set<String> queries) {
        this.queries = queries;
    }

    public Set<String> getOrders() {
        return orders;
    }

    public void setOrders(Set<String> orders) {
        this.orders = orders;
    }

    public Integer getPaging() {
        return paging;
    }

    public void setPaging(Integer paging) {
        this.paging = paging;
    }
}
