package cn.xyz.listtool.aop;

import java.lang.annotation.*;

/**
 * @author lvchenggang.
 * @date 2019/12/4 11:24
 * @see
 * @since
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SupplyAudit {

    public enum OpType {ADD, UPDATE}


    OpType value() default OpType.ADD;
}
