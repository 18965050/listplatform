package cn.xyz.listtool.config.webmvc;

import cn.xyz.listtool.auth.AuthChecker;
import cn.xyz.listtool.management.web.dto.AppDTO;
import cn.xyz.listtool.repository.AppRepository;
import org.apache.shiro.authz.AuthorizationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static cn.xyz.listtool.constant.Const.PARAM_TOKEN;

/**
 * 自定义鉴权拦截器
 *
 * @author lvchenggang.
 * @date 2019/12/10 14:17
 * @see
 * @since
 */
@Component("customAuthInterceptor")
public class CustomAuthInterceptor extends BaseAuthInterceptor {

    @Autowired
    private AppRepository appRepo;

    @Autowired
    private AuthChecker authChecker;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        super.preHandle(request, response, handler);
        String token = request.getParameter(PARAM_TOKEN);
        Long appId = this.getListDTOThreadLocal().get().getAppId();
        AppDTO appDTO = appRepo.selectByPrimaryKey(appId);
        boolean pass = this.authChecker.tokenCheck(token, appDTO);
        if (!pass) {
            throw new AuthorizationException("鉴权失败");
        }
        return true;
    }
}
