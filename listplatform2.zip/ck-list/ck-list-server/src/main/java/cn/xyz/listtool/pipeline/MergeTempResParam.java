package cn.xyz.listtool.pipeline;

import java.util.List;

/**
 * mergeResult函数参数
 *
 * @author lvchenggang.
 * @date 2020/3/13 9:02
 * @see
 * @since
 */
public class MergeTempResParam {
    /**
     * 源名称
     */
    private String source;

    /**
     * 目标名称
     */
    private String target;

    /**
     * 关联的参数
     */
    private List<String> relateFields;

    public MergeTempResParam(String source, String target, List<String> relateFields) {
        this.source = source;
        this.target = target;
        this.relateFields = relateFields;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public List<String> getRelateFields() {
        return relateFields;
    }

    public void setRelateFields(List<String> relateFields) {
        this.relateFields = relateFields;
    }
}
