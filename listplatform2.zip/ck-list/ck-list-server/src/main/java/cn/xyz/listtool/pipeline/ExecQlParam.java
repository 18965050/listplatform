package cn.xyz.listtool.pipeline;

import cn.xyz.listtool.constant.Const;

import java.util.Set;

/**
 * execQl的函数参数
 *
 * @author lvchenggang.
 * @date 2020/3/12 14:49
 * @see
 * @since
 */
public class ExecQlParam {
    /**
     * 数据源
     */
    private String ds;

    /**
     * ql语句模板
     */
    private String ql;

    /**
     * 执行脚本. 比如获取模板参数等等
     */
    private String placeHolder;

    /**
     * 是否分页
     */
    private Integer paging;

    /**
     * 允许的检索条件
     */
    private Set<String> queries;

    /**
     * 允许的搜索条件
     */
    private Set<String> orders;

    public ExecQlParam() {
        this(null, null, null, Const.PAGING.YES.val(), null, null);
    }

    public ExecQlParam(String ds, String ql, String placeHolder, Integer paging, Set<String> queries, Set<String> orders) {
        this.ds = ds;
        this.ql = ql;
        this.placeHolder = placeHolder;
        this.paging = paging;
        this.queries = queries;
        this.orders = orders;
    }


    public String getDs() {
        return ds;
    }

    public void setDs(String ds) {
        this.ds = ds;
    }

    public String getQl() {
        return ql;
    }

    public void setQl(String ql) {
        this.ql = ql;
    }

    public String getPlaceHolder() {
        return placeHolder;
    }

    public void setPlaceHolder(String placeHolder) {
        this.placeHolder = placeHolder;
    }

    public Integer getPaging() {
        return paging;
    }

    public void setPaging(Integer paging) {
        this.paging = paging;
    }

    public Set<String> getQueries() {
        return queries;
    }

    public void setQueries(Set<String> queries) {
        this.queries = queries;
    }

    public Set<String> getOrders() {
        return orders;
    }

    public void setOrders(Set<String> orders) {
        this.orders = orders;
    }
}
