package cn.xyz.listtool.repository.dao;

import cn.xyz.chaos.orm.mybatis.MyBatisRepository;
import cn.xyz.listtool.repository.g.entity.ListtoolAppInfo;
import cn.xyz.listtool.repository.g.entity.ListtoolListInfo;
import cn.xyz.listtool.repository.g.mapper.ListtoolAppInfoMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
@MyBatisRepository
public interface ListtoolAppInfoDAO extends ListtoolAppInfoMapper {

    @Delete("<script>" +
        "DELETE FROM LISTTOOL_APP_INFO WHERE APP_ID IN " +
        "<foreach collection='appIds' item='appId' open='(' close=')' separator=','>" +
        "#{appId}" +
        "</foreach>" +
        "</script>")
    public void deleteByAppIds(@Param("appIds") List<Long> appIds);

    @Insert("<script>" +
        "INSERT INTO LISTTOOL_APP_INFO(APP_ID,APP_NAME,APP_KEY,APP_SECRET,STATUS,CREATE_ID,MODIFY_ID,CREATE_NAME,MODIFY_NAME,CREATE_TIME,MODIFY_TIME) VALUES " +
        "<foreach collection='appDTOs' item='appDTO' separator=','>" +
        "(#{appDTO.appId},#{appDTO.appName},#{appDTO.appKey},#{appDTO.appSecret},#{appDTO.status},#{appDTO.createId},#{appDTO.modifyId},#{appDTO.createName},#{appDTO.modifyName},#{appDTO.createTime},#{appDTO.modifyTime} )" +
        "</foreach>" +
        "</script>")
    public void batchInsert(@Param("appDTOs") List<ListtoolAppInfo> apps);
}
