package cn.xyz.listtool.repository.g.entity;

import java.util.Date;
import javax.annotation.Generated;

public class ListtoolDatasourceInfo {
    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.087+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_ID")
    private Long dsId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.092+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_NAME")
    private String dsName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.092+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_TYPE")
    private Integer dsType;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.092+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_DESC")
    private String dsDesc;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.STATUS")
    private Integer status;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_ID")
    private Long createId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_ID")
    private Long modifyId;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_NAME")
    private String createName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_NAME")
    private String modifyName;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_TIME")
    private Date createTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_TIME")
    private Date modifyTime;

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.091+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_ID")
    public Long getDsId() {
        return dsId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.092+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_ID")
    public void setDsId(Long dsId) {
        this.dsId = dsId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.092+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_NAME")
    public String getDsName() {
        return dsName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.092+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_NAME")
    public void setDsName(String dsName) {
        this.dsName = dsName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.092+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_TYPE")
    public Integer getDsType() {
        return dsType;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.092+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_TYPE")
    public void setDsType(Integer dsType) {
        this.dsType = dsType;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.092+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_DESC")
    public String getDsDesc() {
        return dsDesc;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.DS_DESC")
    public void setDsDesc(String dsDesc) {
        this.dsDesc = dsDesc;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.STATUS")
    public Integer getStatus() {
        return status;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.STATUS")
    public void setStatus(Integer status) {
        this.status = status;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_ID")
    public Long getCreateId() {
        return createId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_ID")
    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_ID")
    public Long getModifyId() {
        return modifyId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_ID")
    public void setModifyId(Long modifyId) {
        this.modifyId = modifyId;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.093+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_NAME")
    public String getCreateName() {
        return createName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_NAME")
    public void setCreateName(String createName) {
        this.createName = createName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_NAME")
    public String getModifyName() {
        return modifyName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_NAME")
    public void setModifyName(String modifyName) {
        this.modifyName = modifyName;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_TIME")
    public Date getCreateTime() {
        return createTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.CREATE_TIME")
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_TIME")
    public Date getModifyTime() {
        return modifyTime;
    }

    @Generated(value="org.mybatis.generator.api.MyBatisGenerator", date="2020-03-27T16:44:50.094+08:00", comments="Source field: listtool..LISTTOOL_DATASOURCE_INFO.MODIFY_TIME")
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}