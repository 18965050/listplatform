package cn.xyz.listtool.dubbo;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.ConfigService;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * <pre>
 * dubbo ApplicationConfig工厂类
 * </pre>
 *
 * @author lvchenggang
 */
@Component
public class ApplicationConfigFactoryBean implements FactoryBean<ApplicationConfig>, InitializingBean {

    private ApplicationConfig applicationConfig;

    @Override
    public void afterPropertiesSet() throws Exception {
        this.applicationConfig = new ApplicationConfig();
        Config config = ConfigService.getConfig("XYZ.bootDubbo");
        applicationConfig.setName(config.getProperty("spring.dubbo.application.name", "ck-list"));
        applicationConfig.setOwner(config.getProperty("spring.dubbo.application.owner", "lvchenggang"));
    }

    @Override
    public ApplicationConfig getObject() throws Exception {
        return applicationConfig;
    }

    @Override
    public Class<?> getObjectType() {
        return ApplicationConfig.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

}
