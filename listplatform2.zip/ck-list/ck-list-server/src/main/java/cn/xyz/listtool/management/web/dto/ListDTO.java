package cn.xyz.listtool.management.web.dto;

import cn.xyz.io.admin.auth.api.base.dto.AuditDTO;
import cn.xyz.listtool.dto.QueryDTO;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author lvchenggang.
 * @date 2019/11/28 9:30
 * @see
 * @since
 */
public class ListDTO extends AuditDTO {

    @NotNull(message = "id不能为空", groups = {GroupAdd.class, GroupModify.class, GroupChangeStatus.class})
    private Long listId;

    @NotNull(message = "应用ID不能为空", groups = {GroupAdd.class, GroupModify.class})
    private Long appId;

    @NotBlank(message = "列表名称不能为空", groups = {GroupAdd.class, GroupModify.class})
    private String listName;

    private String listDesc;

    @NotNull(message = "认证类型不能为空", groups = {GroupAdd.class, GroupModify.class})
    private Integer authType;

    private String authExpr;


    private String context;

    private String debugParam;

    @NotNull(message = "状态不能为空", groups = {GroupAdd.class, GroupModify.class, GroupChangeStatus.class})
    private Integer status;

    /**
     * for debug
     */
    private QueryDTO queryDTO;

    public Long getListId() {
        return listId;
    }

    public void setListId(Long listId) {
        this.listId = listId;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public String getListName() {
        return listName;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }

    public String getListDesc() {
        return listDesc;
    }

    public void setListDesc(String listDesc) {
        this.listDesc = listDesc;
    }

    public Integer getAuthType() {
        return authType;
    }

    public void setAuthType(Integer authType) {
        this.authType = authType;
    }

    public String getAuthExpr() {
        return authExpr;
    }

    public void setAuthExpr(String authExpr) {
        this.authExpr = authExpr;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getDebugParam() {
        return debugParam;
    }

    public void setDebugParam(String debugParam) {
        this.debugParam = debugParam;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public QueryDTO getQueryDTO() {
        return queryDTO;
    }

    public void setQueryDTO(QueryDTO queryDTO) {
        this.queryDTO = queryDTO;
    }

    public interface GroupAdd {
    }


    public interface GroupModify {
    }

    public interface GroupChangeStatus {
    }
}
