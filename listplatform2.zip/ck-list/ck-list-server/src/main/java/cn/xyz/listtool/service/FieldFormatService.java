package cn.xyz.listtool.service;

import cn.xyz.listtool.api.FormatContext;
import cn.xyz.listtool.dto.ResultDTO;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.tuple.Pair;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Map;

/**
 * Field Format的一些公共方法
 *
 * @author lvchenggang.
 * @date 2020/5/20 13:58
 * @see
 * @since
 */
public class FieldFormatService {

    public Pair<Object, String> formatDate(FormatContext context, Map<String, ResultDTO.FieldValueDTO> row) {
        Object fieldValue = row.get(context.getFieldKey()).getValue();
        Pair<Object, String> pair = Pair.of(fieldValue, "");
        String formatPattern = "yyyy-MM-dd";
        if (MapUtils.isNotEmpty(context.getExtras()) && context.getExtras().get("datePattern") != null) {
            formatPattern = (String) context.getExtras().get("datePattern");
        }
        if (fieldValue != null) {
            if (fieldValue instanceof Timestamp) {
                Timestamp timestamp = (Timestamp) fieldValue;
                String labelValue = DateFormatUtils.format(timestamp.getTime(), formatPattern);
                pair = Pair.of(fieldValue, labelValue);
            } else if (fieldValue instanceof Date) {
                Date date = (Date) fieldValue;
                String labelValue = DateFormatUtils.format(date.getTime(), formatPattern);
                pair = Pair.of(fieldValue, labelValue);
            } else if (fieldValue instanceof Time) {
                Time time = (Time) fieldValue;
                String labelValue = DateFormatUtils.format(time.getTime(), formatPattern);
                pair = Pair.of(fieldValue, labelValue);
            }
        }
        return pair;
    }
}
