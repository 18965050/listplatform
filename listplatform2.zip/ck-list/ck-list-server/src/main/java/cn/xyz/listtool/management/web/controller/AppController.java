package cn.xyz.listtool.management.web.controller;

import cn.xyz.chaos.mvc.web.api.BaseController;
import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.management.web.dto.AppDTO;
import cn.xyz.listtool.management.web.service.AppService;
import cn.xyz.listtool.utils.DownloadUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR;
import static cn.xyz.listtool.constant.Const.IMPORT_DATATYPE.APP;

/**
 * @author lvchenggang.
 * @date 2019/11/27 15:14
 * @see
 * @since
 */
@RestController
@RequestMapping("/management/app")
@RequiresPermissions({"list:app"})
public class AppController extends BaseController {

    @Autowired
    private AppService appService;

    @RequestMapping(path = "/detail", method = RequestMethod.GET)
    public BaseResponseDTO<AppDTO> detail(@RequestParam("appId") Long appId) {
        return this.returnWithSuccess(this.appService.detail(appId));
    }

    @RequestMapping(path = "/add", method = RequestMethod.POST)
    public BaseResponseDTO<AppDTO> add(@Validated(AppDTO.GroupAdd.class) @RequestBody AppDTO appDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return this.returnWithCheckFail(bindingResult.getAllErrors());
        }
        return this.returnWithSuccess(appService.add(appDTO));
    }

    @RequestMapping(path = "/update", method = RequestMethod.POST)
    public BaseResponseDTO<AppDTO> update(@Validated(AppDTO.GroupModify.class) @RequestBody AppDTO appDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return this.returnWithCheckFail(bindingResult.getAllErrors());
        }
        return this.returnWithSuccess(appService.update(appDTO));
    }

    @RequestMapping(path = "/changeStatus", method = RequestMethod.POST)
    public BaseResponseDTO<AppDTO> changeStatus(@Validated(AppDTO.GroupChangeStatus.class) @RequestBody AppDTO appDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return this.returnWithCheckFail(bindingResult.getAllErrors());
        }
        AppDTO appDTO1 = new AppDTO();
        appDTO1.setAppId(appDTO.getAppId());
        appDTO1.setStatus(appDTO.getStatus());
        return this.returnWithSuccess(appService.update(appDTO1));
    }

    @RequiresPermissions({"list:list"})
    @RequestMapping(path = "/getAppIds", method = RequestMethod.GET)
    public BaseResponseDTO<Map<Long, String>> getAppIds() {
        return this.returnWithSuccess(appService.getAppIds());
    }

    @RequestMapping(path = "/exportRows", method = RequestMethod.GET)
    public void exportRows(HttpServletRequest request, HttpServletResponse response, @RequestParam("appIds") List<Long> appIds) throws UnsupportedEncodingException {
        String json = this.appService.exportRows(appIds);
        DownloadUtils.down(APP.fileName(), json.getBytes("UTF-8"), request, response);
    }

    @RequestMapping(path = "/importData", method = RequestMethod.POST)
    public BaseResponseDTO<Void> importData(@RequestParam("file") MultipartFile multipartFile) throws IOException {
        BaseResponseDTO baseResponseDTO = new BaseResponseDTO();
        if (multipartFile == null || !(multipartFile.getBytes().length > 0)) {
            return returnWithFail(BIZ_ERROR.value(), Arrays.asList(new String[]{"导入文件为空"}));
        }
        String json = new String(multipartFile.getBytes(), "UTF-8");
        return this.appService.importData(json);
    }
}
