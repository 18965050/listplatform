package cn.xyz.listtool;

import cn.xyz.listtool.dto.QueryDTO;

/**
 * 列表请求DTO
 *
 * @author lvchenggang.
 * @date 2020/3/31 15:20
 * @see
 * @since
 */
public class ListReqDTO {

    /**
     * 请求URL,必填
     */
    private String reqUrl = "http://list.xyz.cn/api/listtool/server";

    /**
     * 连接超时,选填
     */
    private Integer httpConnTimeout = 3000;

    /**
     * 数据响应超时,选填
     */
    private Integer httpSoTimeout = 60000;

    /**
     * 列表ID,必填
     */
    private Long listId;

    /**
     * 查询对象,前端传入
     */
    private QueryDTO queryDTO;

    /**
     * 应用的appKey,必填
     */
    private String appKey;

    /**
     * 应用的appSecret,必填
     */
    private String appSecret;

    /**
     * 用户ID, 用于medusa鉴权时,必填
     */
    private Long userId;

    public String getReqUrl() {
        return reqUrl;
    }

    public void setReqUrl(String reqUrl) {
        this.reqUrl = reqUrl;
    }

    public Integer getHttpConnTimeout() {
        return httpConnTimeout;
    }

    public void setHttpConnTimeout(Integer httpConnTimeout) {
        this.httpConnTimeout = httpConnTimeout;
    }

    public Integer getHttpSoTimeout() {
        return httpSoTimeout;
    }

    public void setHttpSoTimeout(Integer httpSoTimeout) {
        this.httpSoTimeout = httpSoTimeout;
    }

    public Long getListId() {
        return listId;
    }

    public void setListId(Long listId) {
        this.listId = listId;
    }

    public QueryDTO getQueryDTO() {
        return queryDTO;
    }

    public void setQueryDTO(QueryDTO queryDTO) {
        this.queryDTO = queryDTO;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
