package cn.xyz.listtool.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * context中的spec部分
 * note: jackjson objectmapper进行json反序列化时要求内部类为<b>static</b>
 * </pre>
 *
 * @author lvchenggang.
 * @date 2019/11/14 18:10
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class SpecDTO implements Serializable {

    private List<PipeLineDTO> pipelines;

    private PageDTO pagenator;

    private List<FunctionDTO> functions;

    private List<FieldDTO> fields;

    public List<PipeLineDTO> getPipelines() {
        return pipelines;
    }

    public void setPipelines(List<PipeLineDTO> pipelines) {
        this.pipelines = pipelines;
    }

    public PageDTO getPagenator() {
        return pagenator;
    }

    public void setPagenator(PageDTO pagenator) {
        this.pagenator = pagenator;
    }

    public List<FunctionDTO> getFunctions() {
        return functions;
    }

    public void setFunctions(List<FunctionDTO> functions) {
        this.functions = functions;
    }

    public List<FieldDTO> getFields() {
        return fields;
    }

    public void setFields(List<FieldDTO> fields) {
        this.fields = fields;
    }

    @SuppressWarnings("serial")
    public static class PipeLineDTO implements Serializable {
        /**
         * 名称
         */
        private String name;

        /**
         * 类型
         */
        private String type;

        /**
         * 数据
         */
        private Object data;

        /**
         * 排序
         */
        private Integer index;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public Object getData() {
            return data;
        }

        public void setData(Object data) {
            this.data = data;
        }

        public Integer getIndex() {
            return index;
        }

        public void setIndex(Integer index) {
            this.index = index;
        }
    }

    @SuppressWarnings("serial")
    public static class FunctionDTO implements Serializable {
        /**
         * 组件实例名称
         */
        private String key;

        /**
         * <pre>
         * 组件类型. export 或custom.
         * 如果是custom,表示前端自定义组件
         * </pre>
         */
        private String comType;

        private Integer index;

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getComType() {
            return comType;
        }

        public void setComType(String comType) {
            this.comType = comType;
        }

        public Integer getIndex() {
            return index;
        }

        public void setIndex(Integer index) {
            this.index = index;
        }
    }

    @SuppressWarnings("serial")
    public static class FieldDTO implements Serializable{
        private String key;

        private String label;

        private String remark;

        /**
         * json格式字符串,用于搜索和结果字段
         */
        private String mapping;

        private Search search;

        private Result result;

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getMapping() {
            return mapping;
        }

        public void setMapping(String mapping) {
            this.mapping = mapping;
        }

        public Search getSearch() {
            return search;
        }

        public void setSearch(Search search) {
            this.search = search;
        }

        public Result getResult() {
            return result;
        }

        public void setResult(Result result) {
            this.result = result;
        }

        @SuppressWarnings("serial")
        public static class Search implements Serializable{
            /**
             * <pre>
             * 0: 精确
             * 1: 模糊
             * 2: 不等于
             * 3: 范围(连续)
             * 4: 范围(不连续)
             * </pre>
             */
            private Map<Integer, String> match;

            /**
             * <pre>
             * 这个属性后端不使用, 是给前端元素渲染使用的.目前定义的有:
             * input: 文本框(默认)
             * select: 下拉框
             * datePicker: 日期控件
             * timePicker: 时间控件
             * </pre>
             */
            private String eleType;

            /**
             * 参考 {@link java.sql.JDBCType}
             */
            private Integer dataType;

            private Integer index;

            public Map<Integer, String> getMatch() {
                return match;
            }

            public void setMatch(Map<Integer, String> match) {
                this.match = match;
            }

            public String getEleType() {
                return eleType;
            }

            public void setEleType(String eleType) {
                this.eleType = eleType;
            }

            public Integer getDataType() {
                return dataType;
            }

            public void setDataType(Integer dataType) {
                this.dataType = dataType;
            }

            public Integer getIndex() {
                return index;
            }

            public void setIndex(Integer index) {
                this.index = index;
            }
        }

        @SuppressWarnings("serial")
        public static class Result implements Serializable{

            /**
             * <pre>
             * 0:不参与排序
             * 1:参与排序
             * </pre>
             */
            private Integer order;

            /**
             * 用于列表字段值的二次转换.常用于子查询语句等. 支持 ql:// 和 json: //格式
             */
            private String format;

            /**
             * 是否导出字段
             * <pre>
             * 0:不导出
             * 1:导出
             * </pre>
             */
            private Integer export;

            private Integer index;

            public Result() {
                this(0);
            }

            public Result(Integer order) {
                this.order = order;
            }

            public Integer getOrder() {
                return order;
            }

            public void setOrder(Integer order) {
                this.order = order;
            }

            public String getFormat() {
                return format;
            }

            public void setFormat(String format) {
                this.format = format;
            }

            public Integer getExport() {
                return export;
            }

            public void setExport(Integer export) {
                this.export = export;
            }

            public Integer getIndex() {
                return index;
            }

            public void setIndex(Integer index) {
                this.index = index;
            }
        }
    }
}
