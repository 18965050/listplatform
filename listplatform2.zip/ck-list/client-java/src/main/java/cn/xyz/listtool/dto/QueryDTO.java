package cn.xyz.listtool.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * context中的query部分
 *
 * @author lvchenggang.
 * @date 2019/11/14 17:54
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class QueryDTO implements Serializable {

    @SuppressWarnings("serial")
    public static class ParamDTO implements Serializable{
        /**
         * 检索值
         */
        private String value;

        /**
         * 参考 {@link cn.xyz.listtool.dto.SpecDTO.FieldDTO.Search#match}
         */
        private Integer match;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public Integer getMatch() {
            return match;
        }

        public void setMatch(Integer match) {
            this.match = match;
        }
    }

    /**
     * <pre>
     * 搜索字段
     * key: 字段名
     * value: ParamDTO, 其中多个值以:::分隔
     * </pre>
     */
    private Map<String, ParamDTO> param = new HashMap<>();

    /**
     * 排序字段
     */
    private Map<String, Integer> order = new HashMap<>();

    /**
     * ql替换
     */
    private Map<String, Object> placeHolder = new HashMap<>();

    /**
     * 分页
     */
    private PageDTO pagenator;

    /**
     * <pre>
     * 执行的操作
     * exec: 列表查询
     * export: 数据导出
     * </pre>
     */
    private Map<String, Integer> oper = new HashMap<>();

    public Map<String, ParamDTO> getParam() {
        return param;
    }

    public void setParam(Map<String, ParamDTO> param) {
        this.param = param;
    }

    public Map<String, Integer> getOrder() {
        return order;
    }

    public void setOrder(Map<String, Integer> order) {
        this.order = order;
    }

    public Map<String, Object> getPlaceHolder() {
        return placeHolder;
    }

    public void setPlaceHolder(Map<String, Object> placeHolder) {
        this.placeHolder = placeHolder;
    }

    public PageDTO getPagenator() {
        return pagenator;
    }

    public void setPagenator(PageDTO pagenator) {
        this.pagenator = pagenator;
    }

    public Map<String, Integer> getOper() {
        return oper;
    }

    public void setOper(Map<String, Integer> oper) {
        this.oper = oper;
    }
}
