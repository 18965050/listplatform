package cn.xyz.listtool.api;

import java.io.Serializable;
import java.util.Map;

/**
 * @author lvchenggang.
 * @date 2020/5/13 10:35
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class DubboContext implements Serializable {

    private String service;

    private String groupName;

    private Map<String, Object> extras;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Map<String, Object> getExtras() {
        return extras;
    }

    public void setExtras(Map<String, Object> extras) {
        this.extras = extras;
    }
}
