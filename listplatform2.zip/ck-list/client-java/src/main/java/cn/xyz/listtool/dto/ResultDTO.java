package cn.xyz.listtool.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * context中的result部分
 *
 * @author lvchenggang.
 * @date 2019/11/14 20:47
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class ResultDTO implements Serializable {

    @SuppressWarnings("serial")
    public static class FieldValueDTO implements Serializable {
        //实际值
        private Object value;

        //字面值
        private String labelValue;

        //默认构造函数, 给json反序列化使用
        public FieldValueDTO() {
        }

        public FieldValueDTO(Object value, String labelValue) {
            this.value = value;
            this.labelValue = labelValue;
        }

        public Object getValue() {
            return value;
        }

        public void setValue(Object value) {
            this.value = value;
        }

        public String getLabelValue() {
            return labelValue;
        }

        public void setLabelValue(String labelValue) {
            this.labelValue = labelValue;
        }
    }

    private String title;

    private QueryDTO query;

    /**
     * 不包含pipelines和pagenator部分
     */
    private SpecDTO spec;

    private PageDTO pagenator;

    /**
     * 列表返回数据
     */
    private List<Map<String, FieldValueDTO>> list;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public QueryDTO getQuery() {
        return query;
    }

    public void setQuery(QueryDTO query) {
        this.query = query;
    }

    public SpecDTO getSpec() {
        return spec;
    }

    public void setSpec(SpecDTO spec) {
        this.spec = spec;
    }

    public PageDTO getPagenator() {
        return pagenator;
    }

    public void setPagenator(PageDTO pagenator) {
        this.pagenator = pagenator;
    }

    public List<Map<String, FieldValueDTO>> getList() {
        return list;
    }

    public void setList(List<Map<String, FieldValueDTO>> list) {
        this.list = list;
    }
}
