package cn.xyz.listtool.api.impl;

import cn.xyz.chaos.mvc.web.api.BizException;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Method;

/**
 * @author lvchenggang.
 * @date 2020/5/13 13:20
 * @see
 * @since
 */
public class InvokeUtils {

    /**
     * <pre>
     * 由于不能从param准确的推导出反射真正的数据类型, 比如:
     * param的数据类型是HashMap, 但反射需要找到的数据类型是Map
     * 因此需要将paramType传入
     * </pre>
     *
     * @param service
     * @param params
     * @param paraTypes
     * @param <R>
     * @return
     * @throws RuntimeException
     */
    public static <R> R invoke(String service, Object[] params, Class[] paramTypes) throws RuntimeException {
        if (StringUtils.isBlank(service)) {
            throw new IllegalArgumentException("service未配置");
        }
        String[] serviceArr = service.split("#");
        if (serviceArr.length != 2) {
            throw new IllegalArgumentException(String.format("service(%s)格式不正确. 格式为:className#methodName", service));
        }
        try {
            Class<?> serviceClass = Class.forName(serviceArr[0]);
            Object instance = serviceClass.newInstance();
            Method method = serviceClass.getDeclaredMethod(serviceArr[1], paramTypes);
            return (R) method.invoke(instance, params);
        } catch (Exception e) {
            throw new BizException(String.format("服务调用抛出异常(service:%s)", service), e);
        }
    }
}
