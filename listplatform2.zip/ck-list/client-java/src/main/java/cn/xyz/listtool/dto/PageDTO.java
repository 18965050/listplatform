package cn.xyz.listtool.dto;

import java.io.Serializable;

/**
 * @author lvchenggang.
 * @date 2019/11/14 17:48
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class PageDTO implements Serializable {

    private Integer pageIndex;

    private Integer pageSize;

    private Integer pageCount;

    private Integer totalCount;

    public PageDTO() {
        this(1);
    }

    public PageDTO(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageCount() {
        return pageCount;
    }

    public void setPageCount(Integer pageCount) {
        this.pageCount = pageCount;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }
}
