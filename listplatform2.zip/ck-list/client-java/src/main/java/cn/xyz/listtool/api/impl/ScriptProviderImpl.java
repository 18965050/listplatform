package cn.xyz.listtool.api.impl;

import cn.xyz.listtool.api.ScriptProvider;

import java.util.Map;

/**
 * @author lvchenggang.
 * @date 2020/5/13 13:47
 * @see
 * @since
 */
public class ScriptProviderImpl implements ScriptProvider {

    @Override
    public Object call(String service, Map context) {
        return InvokeUtils.invoke(service, new Object[]{context}, new Class[]{Map.class});
    }
}
