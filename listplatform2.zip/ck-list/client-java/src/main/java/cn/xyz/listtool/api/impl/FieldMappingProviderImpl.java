package cn.xyz.listtool.api.impl;

import cn.xyz.listtool.api.FieldMappingProvider;
import cn.xyz.listtool.api.MappingContext;

/**
 * FieldMappingProvider 服务实现
 *
 * @author lvchenggang.
 * @date 2020/5/13 11:50
 * @see
 * @since
 */
public class FieldMappingProviderImpl implements FieldMappingProvider {
    @Override
    public String mappingField(MappingContext context) {
        return InvokeUtils.invoke(context.getService(), new Object[]{context}, new Class[]{MappingContext.class});
    }
}
