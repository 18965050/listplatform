package cn.xyz.listtool;

/**
 * 常量类
 *
 * @author lvchenggang.
 * @date 2020/2/4 14:35
 * @see
 * @since
 */
public class ListConst {

    public enum LIST_OPER {
        EXEC_NO("exec", 0), EXEC_YES("exec", 1), EXPORT_NO("export", 0), EXPORT_YES("export", 1);

        private String key;
        private int val;

        private LIST_OPER(String key, int val) {
            this.key = key;
            this.val = val;
        }

        public String key() {
            return this.key;
        }

        public int val() {
            return this.val;
        }
    }

    public static final String PARAM_VALUE_SPLITTER = ":::";

    public static final String PARAM_TOKEN = "token";

    public static final String EXPORT_TOKEN = "exportToken";

}
