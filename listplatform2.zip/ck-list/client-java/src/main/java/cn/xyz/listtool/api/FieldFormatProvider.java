package cn.xyz.listtool.api;

import cn.xyz.listtool.dto.ResultDTO;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Map;

/**
 * 字段转换API
 *
 * @author lvchenggang.
 * @date 2020/4/24 9:40
 * @see
 * @since
 */
public interface FieldFormatProvider {

    Pair<Object, String> formatField(FormatContext context, Map<String, ResultDTO.FieldValueDTO> row);
}
