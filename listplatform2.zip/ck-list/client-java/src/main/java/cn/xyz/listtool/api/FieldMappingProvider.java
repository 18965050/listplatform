package cn.xyz.listtool.api;

/**
 * 字段映射API
 *
 * @author lvchenggang.
 * @date 2020/4/24 15:54
 * @see
 * @since
 */
public interface FieldMappingProvider {

    /**
     * 字段映射, 返回结果需为JSON map的数据格式
     *
     * @param listId
     * @param fieldName
     * @return
     */
    String mappingField(MappingContext mappingContext);
}
