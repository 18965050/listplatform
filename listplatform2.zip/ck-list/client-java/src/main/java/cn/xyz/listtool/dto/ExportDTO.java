package cn.xyz.listtool.dto;

import java.io.Serializable;

/**
 * @author lvchenggang.
 * @date 2020/5/22 14:08
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class ExportDTO implements Serializable {

    private String exportToken;

    private Integer totalCount;

    private String downloadUrl;

    public String getExportToken() {
        return exportToken;
    }

    public void setExportToken(String exportToken) {
        this.exportToken = exportToken;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }
}
