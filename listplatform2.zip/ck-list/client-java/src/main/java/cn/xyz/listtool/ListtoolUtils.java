package cn.xyz.listtool;

import cn.xyz.chaos.common.utils.encrypt.EncryptorUtils;
import cn.xyz.chaos.mvc.web.api.BaseResponseDTO;
import cn.xyz.listtool.dto.ExportDTO;
import cn.xyz.listtool.dto.QueryDTO;
import cn.xyz.listtool.dto.ResultDTO;
import cn.xyz.listtool.dto.ServerQueryDTO;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.apache.http.util.EntityUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.Charset;

import static cn.xyz.chaos.common.utils.encrypt.Encryptor.ALGORITHM.PBEWithMD5AndDES;
import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.BIZ_ERROR;
import static cn.xyz.chaos.mvc.web.api.BaseResponseDTO.DEFAULT_RESPONSE_RESULT.SYSTEM_ERROR;
import static cn.xyz.listtool.ListConst.*;
import static cn.xyz.listtool.ListConst.LIST_OPER.EXPORT_YES;

/**
 * 请求后端列表工具类
 *
 * @author lvchenggang.
 * @date 2020/2/3 17:00
 * @see
 * @since
 */
public class ListtoolUtils {

    private static JsonMapper jsonMapper = new JsonMapper(null, JsonInclude.Include.ALWAYS);

    public static <T> BaseResponseDTO<T> request(HttpServletRequest httpReq, HttpServletResponse httpRes, ListReqDTO reqDTO) {
        String oriReqUrl = reqDTO.getReqUrl();
        String appKey = reqDTO.getAppKey();
        String appSecret = reqDTO.getAppSecret();
        Long listId = reqDTO.getListId();
        QueryDTO queryDTO = reqDTO.getQueryDTO();
        ServerQueryDTO serverQueryDTO = new ServerQueryDTO();
        serverQueryDTO.setQueryDTO(queryDTO);
        serverQueryDTO.setUserId(reqDTO.getUserId());
        String expotToken = httpReq.getParameter(EXPORT_TOKEN);
        if (StringUtils.isNotBlank(expotToken)) {
            serverQueryDTO.setExportToken(expotToken);
        }
        Integer httpConnTimeout = reqDTO.getHttpConnTimeout();
        Integer httpSoTimeout = reqDTO.getHttpSoTimeout();
        BaseResponseDTO<T> baseResponseDTO = new BaseResponseDTO<>();
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(httpSoTimeout).setConnectTimeout(httpConnTimeout).build();// 设置请求和传输超时时间
        String reqUrl = "";
        if (StringUtils.isBlank(appKey) || StringUtils.isBlank(appSecret)) {
            baseResponseDTO.setRet(BIZ_ERROR.value());
            baseResponseDTO.addError("appKey和appSecret不能为空");
            return baseResponseDTO;
        }
        String token = EncryptorUtils.encrypt(appKey + PARAM_VALUE_SPLITTER + System.currentTimeMillis(), appSecret, PBEWithMD5AndDES);
        reqUrl = String.format("%s/%d?%s=%s", oriReqUrl, listId, PARAM_TOKEN, token);

        boolean isExport = queryDTO != null && MapUtils.isNotEmpty(queryDTO.getOper()) && queryDTO.getOper().get(EXPORT_YES.key()) != null && EXPORT_YES.val() == queryDTO.getOper().get(EXPORT_YES.key()) ? true : false;
        //允许POST请求可以redirect
        CloseableHttpClient httpclient = HttpClientBuilder.create().setRedirectStrategy(new LaxRedirectStrategy()).build();
        HttpPost httpPost = new HttpPost(reqUrl);
        httpPost.setConfig(requestConfig);
        httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");
        String postBody = jsonMapper.toJson(serverQueryDTO);
        try {
            StringEntity se = new StringEntity(postBody, Charset.forName("UTF-8"));
            httpPost.setEntity(se);
            CloseableHttpResponse response = httpclient.execute(httpPost);
            String resData = EntityUtils.toString(response.getEntity(), Charset.forName("UTF-8"));
            //列表查询
            if (!isExport) {
                baseResponseDTO = jsonMapper.fromJson(resData, BaseResponseDTO.class);
                //还需要对baseResponseDTO.data再次反序列化
                if (baseResponseDTO.getData() != null) {
                    ResultDTO resultDTO = jsonMapper.fromJson(jsonMapper.toJson(baseResponseDTO.getData()), ResultDTO.class);
                    baseResponseDTO.setData((T) resultDTO);
                }
            } else {
                baseResponseDTO = jsonMapper.fromJson(resData, BaseResponseDTO.class);
                //还需要对baseResponseDTO.data再次反序列化
                if (baseResponseDTO.getData() != null) {
                    ExportDTO exportDTO = jsonMapper.fromJson(jsonMapper.toJson(baseResponseDTO.getData()), ExportDTO.class);
                    baseResponseDTO.setData((T) exportDTO);
                }
            }
        } catch (Exception e) {
            baseResponseDTO.setRet(SYSTEM_ERROR.value());
            baseResponseDTO.addError(e.getMessage());
        }

        return baseResponseDTO;
    }
}
