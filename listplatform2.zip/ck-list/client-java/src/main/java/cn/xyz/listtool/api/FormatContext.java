package cn.xyz.listtool.api;

/**
 * {@link FieldFormatProvider}参数
 * @author lvchenggang.
 * @date 2020/5/13 9:16
 * @see
 * @since
 */
public class FormatContext extends DubboContext {

    private Long listId;

    private String fieldKey;

    public Long getListId() {
        return listId;
    }

    public void setListId(Long listId) {
        this.listId = listId;
    }

    public String getFieldKey() {
        return fieldKey;
    }

    public void setFieldKey(String fieldKey) {
        this.fieldKey = fieldKey;
    }

}
