package cn.xyz.listtool.api;

import java.util.Map;

/**
 * 脚本调用API
 *
 * @author lvchenggang.
 * @date 2020/4/26 10:29
 * @see
 * @since
 */
public interface ScriptProvider<T> {

    T call(String service, Map<String, Object> context);
}
