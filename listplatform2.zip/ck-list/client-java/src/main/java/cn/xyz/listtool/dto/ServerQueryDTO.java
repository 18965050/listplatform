package cn.xyz.listtool.dto;

import java.io.Serializable;

/**
 * 给ListtoolUtils使用的queryDTO
 *
 * @author lvchenggang.
 * @date 2020/5/7 20:00
 * @see
 * @since
 */
@SuppressWarnings("serial")
public class ServerQueryDTO implements Serializable {
    private QueryDTO queryDTO;

    private Long userId;

    //数据导出token
    private String exportToken;

    public QueryDTO getQueryDTO() {
        return queryDTO;
    }

    public void setQueryDTO(QueryDTO queryDTO) {
        this.queryDTO = queryDTO;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getExportToken() {
        return exportToken;
    }

    public void setExportToken(String exportToken) {
        this.exportToken = exportToken;
    }
}
