package cn.xyz.listtool.api.impl;

import cn.xyz.listtool.api.FieldFormatProvider;
import cn.xyz.listtool.api.FormatContext;
import cn.xyz.listtool.dto.ResultDTO;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Map;

/**
 * FieldFormatProvider 服务实现
 *
 * @author lvchenggang.
 * @date 2020/5/13 9:18
 * @see
 * @since
 */
public class FieldFormatProviderImpl implements FieldFormatProvider {

    @Override
    public Pair<Object, String> formatField(FormatContext context, Map<String, ResultDTO.FieldValueDTO> row) {
        return InvokeUtils.invoke(context.getService(), new Object[]{context, row}, new Class[]{FormatContext.class, Map.class});
    }
}
